define("page/component/pages/camera-scan-code/camera-scan-code.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'camera',
      path: 'page/component/pages/camera-scan-code/camera-scan-code'
    };
  },


  data: {
    result: {}
  },
  onReady: function onReady() {
    wx.showModal({
      title: '提示',
      content: '将摄像头对准一维码即可扫描',
      showCancel: false
    });
  },
  scanCode: function scanCode(e) {
    console.log('scanCode:', e);
    this.setData({
      result: e.detail
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  error: function error(e) {
    console.log(e.detail);
  }
});
});