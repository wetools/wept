define("page/component/pages/live-player/live-player.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'live-player',
      path: 'page/component/pages/live-player/live-player'
    };
  },

  data: {
    videoSrc: ""
  },
  onReady: function onReady(res) {
    this.ctx = wx.createLivePlayerContext('player');
  },
  handleScanQRCode: function handleScanQRCode() {
    var _this = this;

    wx.scanCode({
      complete: function complete(res) {
        var result = res.result;

        _this.setData({
          videoSrc: result
        });
      }
    });
  },
  handleLivePlayerStateChange: function handleLivePlayerStateChange(e) {
    console.log('live-player code:', e.detail.code);
  },
  handleLivePlayerError: function handleLivePlayerError(e) {
    console.error('live-player error:', e.detail.errMsg);
  },
  handlePlay: function handlePlay() {
    this.ctx.play({
      success: function success(res) {
        console.log('play success');
      },
      fail: function fail(res) {
        console.log('play fail');
      }
    });
  },
  handlePause: function handlePause() {
    this.ctx.pause({
      success: function success(res) {
        console.log('pause success');
      },
      fail: function fail(res) {
        console.log('pause fail');
      }
    });
  },
  handleStop: function handleStop() {
    this.ctx.stop({
      success: function success(res) {
        console.log('stop success');
      },
      fail: function fail(res) {
        console.log('stop fail');
      }
    });
  },
  handleResume: function handleResume() {
    this.ctx.resume({
      success: function success(res) {
        console.log('resume success');
      },
      fail: function fail(res) {
        console.log('resume fail');
      }
    });
  },
  handleMute: function handleMute() {
    this.ctx.mute({
      success: function success(res) {
        console.log('mute success');
      },
      fail: function fail(res) {
        console.log('mute fail');
      }
    });
  },
  handleVideoSrcInput: function handleVideoSrcInput(e) {
    this.setData({
      videoSrc: e.detail.value
    });
  }
});
});