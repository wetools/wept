define("page/component/pages/ad/ad.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var info = wx.getSystemInfoSync();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'ad',
      path: 'page/component/pages/ad/ad'
    };
  },


  data: {
    platform: info.platform
  }
});
});