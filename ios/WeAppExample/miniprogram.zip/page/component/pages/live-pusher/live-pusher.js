define("page/component/pages/live-pusher/live-pusher.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'live-pusher',
      path: 'page/component/pages/live-pusher/live-pusher'
    };
  },

  data: {
    videoSrc: ''
  },
  onReady: function onReady(res) {
    this.ctx = wx.createLivePusherContext('pusher');
  },
  handleLivePusherStateChange: function handleLivePusherStateChange(e) {
    console.log('live-pusher code:', e.detail.code);
  },
  handleLivePusherError: function handleLivePusherError(e) {
    console.error('live-pusher error:', e.detail.errMsg);
  },
  handleStart: function handleStart() {
    this.ctx.start({
      success: function success(res) {
        console.log('start success');
      },
      fail: function fail(res) {
        console.log('start fail');
      }
    });
  },
  handleScanQRCode: function handleScanQRCode() {
    var _this = this;

    wx.scanCode({
      complete: function complete(res) {
        var result = res.result;

        _this.setData({
          videoSrc: result
        });
      }
    });
  },
  handlePause: function handlePause() {
    this.ctx.pause({
      success: function success(res) {
        console.log('pause success');
      },
      fail: function fail(res) {
        console.log('pause fail');
      }
    });
  },
  handleStop: function handleStop() {
    this.ctx.stop({
      success: function success(res) {
        console.log('stop success');
      },
      fail: function fail(res) {
        console.log('stop fail');
      }
    });
  },
  handleResume: function handleResume() {
    this.ctx.resume({
      success: function success(res) {
        console.log('resume success');
      },
      fail: function fail(res) {
        console.log('resume fail');
      }
    });
  },
  handleSwitchCamera: function handleSwitchCamera() {
    this.ctx.switchCamera({
      success: function success(res) {
        console.log('switch camera success');
      },
      fail: function fail(res) {
        console.log('switch camera fail');
      }
    });
  },
  handleVideoSrcInput: function handleVideoSrcInput(e) {
    this.setData({
      videoSrc: e.detail.value
    });
  }
});
});