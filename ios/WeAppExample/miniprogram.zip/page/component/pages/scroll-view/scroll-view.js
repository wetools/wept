define("page/component/pages/scroll-view/scroll-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var order = ['demo1', 'demo2', 'demo3'];

Page({
  onLoad: function onLoad() {
    this.animate('#scroll-sample-object1', [{
      borderRadius: '0',
      offset: 0
    }, {
      borderRadius: '25%',
      offset: .5
    }, {
      borderRadius: '50%',
      offset: 1
    }], 2000, {
      scrollSource: '#scroll-view_D',
      timeRange: 2000,
      startScrollOffset: 0,
      endScrollOffset: 150
    });

    this.animate('#scroll-sample-object2', [{
      opacity: 1,
      offset: 0
    }, {
      opacity: .5,
      offset: .5
    }, {
      opacity: .3,
      offset: 1
    }], 2000, {
      scrollSource: '#scroll-view_D',
      timeRange: 2000,
      startScrollOffset: 150,
      endScrollOffset: 300
    });

    this.animate('#scroll-sample-object3', [{
      background: "white",
      offset: 0
    }, {
      background: "yellow",
      offset: 1
    }], 2000, {
      scrollSource: '#scroll-view_D',
      timeRange: 2000,
      startScrollOffset: 300,
      endScrollOffset: 400
    });
  },
  onPulling: function onPulling(e) {
    console.log('onPulling:', e);
  },
  onRefresh: function onRefresh() {
    var _this = this;

    if (this._freshing) return;
    this._freshing = true;
    setTimeout(function () {
      _this.setData({
        triggered: false
      });
      _this._freshing = false;
    }, 3000);
  },
  onRestore: function onRestore(e) {
    console.log('onRestore:', e);
  },
  onAbort: function onAbort(e) {
    console.log('onAbort', e);
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'scroll-view',
      path: 'page/component/pages/scroll-view/scroll-view'
    };
  },


  data: {
    toView: 'green',
    triggered: false
  },

  upper: function upper(e) {
    console.log(e);
  },
  lower: function lower(e) {
    console.log(e);
  },
  scroll: function scroll(e) {
    console.log(e);
  },
  scrollToTop: function scrollToTop() {
    this.setAction({
      scrollTop: 0
    });
  },
  tap: function tap() {
    for (var i = 0; i < order.length; ++i) {
      if (order[i] === this.data.toView) {
        this.setData({
          toView: order[i + 1],
          scrollTop: (i + 1) * 200
        });
        break;
      }
    }
  },
  tapMove: function tapMove() {
    this.setData({
      scrollTop: this.data.scrollTop + 10
    });
  }
});
});