define("page/component/pages/movable-view/movable-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'movable-view',
      path: 'page/component/pages/movable-view/movable-view'
    };
  },


  data: {
    x: 0,
    y: 0,
    scale: 2
  },

  tap: function tap() {
    this.setData({
      x: 30,
      y: 30
    });
  },
  tap2: function tap2() {
    this.setData({
      scale: 3
    });
  },
  onChange: function onChange(e) {
    console.log(e.detail);
  },
  onScale: function onScale(e) {
    console.log(e.detail);
  }
});
});