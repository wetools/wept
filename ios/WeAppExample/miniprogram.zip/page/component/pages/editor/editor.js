define("page/component/pages/editor/editor.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'editor',
      path: 'page/component/pages/editor/editor'
    };
  },

  data: {
    formats: {},
    readOnly: false,
    placeholder: '开始输入...',
    editorHeight: 300,
    keyboardHeight: 0,
    isIOS: false,
    safeHeight: 0,
    toolBarHeight: 50
  },
  readOnlyChange: function readOnlyChange() {
    this.setData({
      readOnly: !this.data.readOnly
    });
  },
  onLoad: function onLoad() {
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        platform = _wx$getSystemInfoSync.platform,
        safeArea = _wx$getSystemInfoSync.safeArea,
        model = _wx$getSystemInfoSync.model,
        screenHeight = _wx$getSystemInfoSync.screenHeight;

    var safeHeight = void 0;
    if (safeArea) {
      safeHeight = screenHeight - safeArea.bottom;
    } else {
      safeHeight = 32;
    }
    this._safeHeight = safeHeight;
    var isIOS = platform === 'ios';
    this.setData({ isIOS: isIOS, safeHeight: safeHeight, toolBarHeight: isIOS ? safeHeight + 50 : 50 });
    var that = this;
    this.updatePosition(0);
    var keyboardHeight = 0;
    wx.onKeyboardHeightChange(function (res) {
      if (res.height === keyboardHeight) {
        return;
      }
      var duration = res.height > 0 ? res.duration * 1000 : 0;
      keyboardHeight = res.height;
      setTimeout(function () {
        wx.pageScrollTo({
          scrollTop: 0,
          success: function success() {
            that.updatePosition(keyboardHeight);
            that.editorCtx.scrollIntoView();
          }
        });
      }, duration);
    });
  },
  updatePosition: function updatePosition(keyboardHeight) {
    var toolbarHeight = 50;

    var _wx$getSystemInfoSync2 = wx.getSystemInfoSync(),
        windowHeight = _wx$getSystemInfoSync2.windowHeight,
        platform = _wx$getSystemInfoSync2.platform;

    var editorHeight = keyboardHeight > 0 ? windowHeight - keyboardHeight - toolbarHeight : windowHeight;
    if (keyboardHeight === 0) {
      this.setData({
        editorHeight: editorHeight, keyboardHeight: keyboardHeight,
        toolBarHeight: this.data.isIOS ? 50 + this._safeHeight : 50,
        safeHeight: this._safeHeight
      });
    } else {
      this.setData({ editorHeight: editorHeight, keyboardHeight: keyboardHeight,
        toolBarHeight: 50,
        safeHeight: 0
      });
    }
  },
  calNavigationBarAndStatusBar: function calNavigationBarAndStatusBar() {
    var systemInfo = wx.getSystemInfoSync();
    var statusBarHeight = systemInfo.statusBarHeight,
        platform = systemInfo.platform;

    var isIOS = platform === 'ios';
    var navigationBarHeight = isIOS ? 44 : 48;
    return statusBarHeight + navigationBarHeight;
  },
  onEditorReady: function onEditorReady() {
    var that = this;
    wx.createSelectorQuery().select('#editor').context(function (res) {
      that.editorCtx = res.context;
    }).exec();
  },
  blur: function blur() {
    this.editorCtx.blur();
  },
  format: function format(e) {
    var _e$target$dataset = e.target.dataset,
        name = _e$target$dataset.name,
        value = _e$target$dataset.value;

    if (!name) return;
    // console.log('format', name, value)
    this.editorCtx.format(name, value);
  },
  onStatusChange: function onStatusChange(e) {
    var formats = e.detail;
    this.setData({ formats: formats });
  },
  insertDivider: function insertDivider() {
    this.editorCtx.insertDivider({
      success: function success() {
        console.log('insert divider success');
      }
    });
  },
  clear: function clear() {
    this.editorCtx.clear({
      success: function success(res) {
        console.log("clear success");
      }
    });
  },
  removeFormat: function removeFormat() {
    this.editorCtx.removeFormat();
  },
  insertDate: function insertDate() {
    var date = new Date();
    var formatDate = date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getDate();
    this.editorCtx.insertText({
      text: formatDate
    });
  },
  insertImage: function insertImage() {
    var that = this;
    wx.chooseImage({
      count: 1,
      success: function success(res) {
        that.editorCtx.insertImage({
          src: res.tempFilePaths[0],
          data: {
            id: 'abcd',
            role: 'god'
          },
          width: '80%',
          success: function success() {
            console.log('insert image success');
          }
        });
      }
    });
  }
});
});