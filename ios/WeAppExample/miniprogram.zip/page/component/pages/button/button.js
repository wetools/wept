define("page/component/pages/button/button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var types = ['default', 'primary', 'warn'];
var pageObject = _defineProperty({
  data: {
    defaultSize: 'default',
    primarySize: 'default',
    warnSize: 'default',
    disabled: false,
    plain: false,
    loading: false
  },

  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'button',
      path: 'page/component/pages/button/button'
    };
  },
  setDisabled: function setDisabled() {
    this.setData({
      disabled: !this.data.disabled
    });
  },
  setPlain: function setPlain() {
    this.setData({
      plain: !this.data.plain
    });
  },
  setLoading: function setLoading() {
    this.setData({
      loading: !this.data.loading
    });
  },
  handleContact: function handleContact(e) {
    console.log(e.detail);
  },
  handleGetPhoneNumber: function handleGetPhoneNumber(e) {
    console.log(e.detail);
  },
  handleGetUserInfo: function handleGetUserInfo(e) {
    console.log(e.detail);
  },
  handleOpenSetting: function handleOpenSetting(e) {
    console.log(e.detail.authSetting);
  }
}, 'handleGetUserInfo', function handleGetUserInfo(e) {
  console.log(e.detail.userInfo);
});

for (var i = 0; i < types.length; ++i) {
  (function (type) {
    pageObject[type] = function () {
      var key = type + 'Size';
      var changedData = {};
      changedData[key] = this.data[key] === 'default' ? 'mini' : 'default';
      this.setData(changedData);
    };
  })(types[i]);
}

Page(pageObject);
});