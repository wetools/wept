define("page/component/pages/image/image.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'image',
      path: 'page/component/pages/image/image'
    };
  },
  onLoad: function onLoad() {
    var _this = this;

    wx.cloud.getTempFileURL({
      fileList: [{
        fileID: 'cloud://release-b86096.7265-release-b86096-1258211818/开发者社区.webp',
        maxAge: 60 * 60
      }]
    }).then(function (res) {
      console.log(res);
      _this.setData({
        webpImageUrl: res.fileList[0].tempFileURL
      });
    }).catch(function (error) {
      console.log('CLOUD：image 临时链接获取失败');
    });
  },

  data: {
    imageUrl: 'cloud://release-b86096.7265-release-b86096-1258211818/demo.jpg',
    webpImageURL: ''
  }
});
});