define("page/component/pages/canvas/canvas.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _util = require('../../../../util/util');

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'canvas',
      path: 'page/component/pages/canvas/canvas'
    };
  },

  data: {
    canIUse: true
  },
  onReady: function onReady() {

    // 解决基础库小于 2.7.0 的兼容问题
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        SDKVersion = _wx$getSystemInfoSync.SDKVersion;

    if ((0, _util.compareVersion)(SDKVersion, '2.7.0') < 0) {
      console.log('123');
      this.setData({
        canIUse: false
      });
    } else {
      // canvas
      this.position = {
        x: 150,
        y: 150,
        vx: 2,
        vy: 2
      };

      this.drawBall();
      this.interval = setInterval(this.drawBall, 17);
    }
  },
  init: function init(res) {
    var _this = this;

    var width = res[0].width;
    var height = res[0].height;

    var canvas = res[0].node;
    var ctx = canvas.getContext('2d');

    var dpr = wx.getSystemInfoSync().pixelRatio;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    var renderLoop = function renderLoop() {
      _this.render(canvas, ctx);
      canvas.requestAnimationFrame(renderLoop);
    };
    canvas.requestAnimationFrame(renderLoop);

    var img = canvas.createImage();
    img.onload = function () {
      _this._img = img;
    };
    img.src = './car.png';
  },
  render: function render(canvas, ctx) {
    ctx.clearRect(0, 0, 305, 305);
    this.drawBall2D(ctx);
    this.drawCar(ctx);
  },
  drawBall: function drawBall() {
    var p = this.position;
    p.x += p.vx;
    p.y += p.vy;
    if (p.x >= 300) {
      p.vx = -2;
    }
    if (p.x <= 7) {
      p.vx = 2;
    }
    if (p.y >= 300) {
      p.vy = -2;
    }
    if (p.y <= 7) {
      p.vy = 2;
    }

    var context = wx.createCanvasContext('canvas');

    function ball(x, y) {
      context.beginPath(0);
      context.arc(x, y, 5, 0, Math.PI * 2);
      context.setFillStyle('#1aad19');
      context.setStrokeStyle('rgba(1,1,1,0)');
      context.fill();
      context.stroke();
    }

    ball(p.x, 150);
    ball(150, p.y);
    ball(300 - p.x, 150);
    ball(150, 300 - p.y);
    ball(p.x, p.y);
    ball(300 - p.x, 300 - p.y);
    ball(p.x, 300 - p.y);
    ball(300 - p.x, p.y);
    context.draw();
  },
  onUnload: function onUnload() {
    clearInterval(this.interval);
  }
});
});