define("page/component/pages/canvas-2d/canvas-2d.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _util = require('../../../../util/util');

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'canvas',
      path: 'page/component/pages/canvas-2d/canvas-2d'
    };
  },

  data: {
    canIUse: true
  },
  onReady: function onReady() {

    // 解决基础库小于 2.7.0 的兼容问题
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        SDKVersion = _wx$getSystemInfoSync.SDKVersion;

    console.log(SDKVersion);
    if ((0, _util.compareVersion)(SDKVersion, '2.7.0') < 0) {
      console.log('123');
      this.setData({
        canIUse: false
      });
    } else {
      // canvas2D
      this.position2D = {
        x: 150,
        y: 150,
        vx: 2,
        vy: 2
      };
      this.x = -100;
      wx.createSelectorQuery().select('#canvas2D').fields({
        node: true,
        size: true
      }).exec(this.init.bind(this));
    }
  },
  init: function init(res) {
    var _this = this;

    var width = res[0].width;
    var height = res[0].height;

    var canvas = res[0].node;
    // 不支持2d
    if (!canvas) {
      this.setData({
        canIUse: false
      });
      return;
    }
    var ctx = canvas.getContext('2d');

    var dpr = wx.getSystemInfoSync().pixelRatio;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    var renderLoop = function renderLoop() {
      _this.render(canvas, ctx);
      canvas.requestAnimationFrame(renderLoop);
    };
    canvas.requestAnimationFrame(renderLoop);

    var img = canvas.createImage();
    img.onload = function () {
      _this._img = img;
    };
    img.src = './car.png';
  },
  render: function render(canvas, ctx) {
    ctx.clearRect(0, 0, 305, 305);
    this.drawBall2D(ctx);
    this.drawCar(ctx);
  },
  drawBall2D: function drawBall2D(ctx) {
    var p = this.position2D;
    p.x += p.vx;
    p.y += p.vy;
    if (p.x >= 300) {
      p.vx = -2;
    }
    if (p.x <= 7) {
      p.vx = 2;
    }
    if (p.y >= 300) {
      p.vy = -2;
    }
    if (p.y <= 7) {
      p.vy = 2;
    }

    function ball(x, y) {
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#1aad19';
      ctx.strokeStyle = 'rgba(1,1,1,0)';
      ctx.fill();
      ctx.stroke();
    }

    ball(p.x, 150);
    ball(150, p.y);
    ball(300 - p.x, 150);
    ball(150, 300 - p.y);
    ball(p.x, p.y);
    ball(300 - p.x, 300 - p.y);
    ball(p.x, 300 - p.y);
    ball(300 - p.x, p.y);
  },
  drawCar: function drawCar(ctx) {
    if (!this._img) return;
    if (this.x > 350) {
      this.x = -100;
    }
    ctx.drawImage(this._img, this.x++, 150 - 25, 100, 50);
    ctx.restore();
  },
  onUnload: function onUnload() {
    // clearInterval(this.interval)
  }
});
});