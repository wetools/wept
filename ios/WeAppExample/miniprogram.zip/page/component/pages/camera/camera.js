define("page/component/pages/camera/camera.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var vs = '\n  attribute vec3 aPos;\n  attribute vec2 aVertexTextureCoord;\n  varying highp vec2 vTextureCoord;\n\n  void main(void){\n    gl_Position = vec4(aPos, 1);\n    vTextureCoord = aVertexTextureCoord;\n  }\n';

var fs = '\n  varying highp vec2 vTextureCoord;\n  uniform sampler2D uSampler;\n\n  void main(void) {\n    gl_FragColor = texture2D(uSampler, vTextureCoord);\n  }\n';

var vertex = [-1, -1, 0.0, 1, -1, 0.0, 1, 1, 0.0, -1, 1, 0.0];

var vertexIndice = [0, 1, 2, 0, 2, 3];

var texCoords = [0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0];
function createShader(gl, src, type) {
  var shader = gl.createShader(type);
  gl.shaderSource(shader, src);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error('Error compiling shader: ' + gl.getShaderInfoLog(shader));
  }
  return shader;
}

var buffers = {};

function createRenderer(canvas, width, height) {
  var gl = canvas.getContext("webgl");
  if (!gl) {
    console.error('Unable to get webgl context.');
    return;
  }

  var info = wx.getSystemInfoSync();
  gl.canvas.width = info.pixelRatio * width;
  gl.canvas.height = info.pixelRatio * height;
  gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);

  var vertexShader = createShader(gl, vs, gl.VERTEX_SHADER);
  var fragmentShader = createShader(gl, fs, gl.FRAGMENT_SHADER);

  var program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error('Unable to initialize the shader program.');
    return;
  }

  gl.useProgram(program);

  var texture = gl.createTexture();
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.bindTexture(gl.TEXTURE_2D, null);

  buffers.vertexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertex), gl.STATIC_DRAW);

  buffers.vertexIndiceBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.vertexIndiceBuffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(vertexIndice), gl.STATIC_DRAW);

  var aVertexPosition = gl.getAttribLocation(program, 'aPos');
  gl.vertexAttribPointer(aVertexPosition, 3, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(aVertexPosition);

  buffers.trianglesTexCoordBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.trianglesTexCoordBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(texCoords), gl.STATIC_DRAW);

  var vertexTexCoordAttribute = gl.getAttribLocation(program, "aVertexTextureCoord");
  gl.enableVertexAttribArray(vertexTexCoordAttribute);
  gl.vertexAttribPointer(vertexTexCoordAttribute, 2, gl.FLOAT, false, 0, 0);

  var samplerUniform = gl.getUniformLocation(program, 'uSampler');
  gl.uniform1i(samplerUniform, 0);

  return function (arrayBuffer, width, height) {
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, arrayBuffer);
    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
  };
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'camera',
      path: 'page/component/pages/camera/camera'
    };
  },


  data: {
    src: '',
    videoSrc: '',
    position: 'back',
    mode: 'scanCode',
    result: {},
    frameWidth: 0,
    frameHeight: 0,
    width: 288,
    height: 358,
    showCanvas: false
  },

  onReady: function onReady() {
    this.ctx = wx.createCameraContext();
    // const selector = wx.createSelectorQuery();
    // selector.select('#webgl')
    // .node(this.init)
    // .exec()
  },
  init: function init(res) {
    var _this = this;

    if (this.listener) {
      this.listener.stop();
    }
    var canvas = res.node;
    var render = createRenderer(canvas, this.data.width, this.data.height);

    // if (!render || typeof render !== 'function') return

    this.listener = this.ctx.onCameraFrame(function (frame) {

      render(new Uint8Array(frame.data), frame.width, frame.height);

      var _data = _this.data,
          frameWidth = _data.frameWidth,
          frameHeight = _data.frameHeight;


      if (frameWidth === frame.width && frameHeight == frame.height) return;
      _this.setData({
        frameWidth: frame.width,
        frameHeight: frame.height

      });
    });
    this.listener.start();
  },
  takePhoto: function takePhoto() {
    var _this2 = this;

    this.ctx.takePhoto({
      quality: 'high',
      success: function success(res) {
        _this2.setData({
          src: res.tempImagePath
        });
      }
    });
  },
  startRecord: function startRecord() {
    this.ctx.startRecord({
      success: function success() {
        console.log('startRecord');
      }
    });
  },
  stopRecord: function stopRecord() {
    var _this3 = this;

    this.ctx.stopRecord({
      success: function success(res) {
        _this3.setData({
          src: res.tempThumbPath,
          videoSrc: res.tempVideoPath
        });
      }
    });
  },
  togglePosition: function togglePosition() {
    this.setData({
      position: this.data.position === 'front' ? 'back' : 'front'
    });
  },
  error: function error(e) {
    console.log(e.detail);
  },
  handleShowCanvas: function handleShowCanvas() {
    var _this4 = this;

    var that = this;

    this.setData({
      showCanvas: !this.data.showCanvas
    }, function () {
      if (_this4.data.showCanvas) {
        var selector = wx.createSelectorQuery();
        selector.select('#webgl').node(_this4.init).exec();
      }
    });
  }
});
});