define("page/weui/example/emoji/emoji.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

var _util = require('../../../../util/util');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'emoji',
      path: 'page/weui/example/emoji/emoji'
    };
  },

  data: {
    lineHeight: 24,
    functionShow: false,
    emojiShow: false,
    comment: '',
    focus: false,
    cursor: 0,
    _keyboardShow: false,
    emojiSource: 'https://res.wx.qq.com/op_res/eROMsLpnNC10dC40vzF8qviz63ic7ATlbGg20lr5pYykOwHRbLZFUhgg23RtVorX',
    // parsedComment: []
    historyList: [],
    layoutHeight: '0px',
    safeHeight: 0,
    keyboardHeight: 0,
    isIOS: false,
    canIUse: true
  },

  onLoad: function onLoad() {
    var system = wx.getSystemInfoSync();
    var isIOS = system.platform === 'ios';

    this.safeHeight = system.screenHeight - system.safeArea.bottom;
    var layoutHeight = wx.getSystemInfoSync().windowHeight - this.safeHeight / 2;
    this.setData({
      isIOS: isIOS,
      safeHeight: this.safeHeight,
      layoutHeight: layoutHeight

    });
    var emojiInstance = this.selectComponent('.mp-emoji');
    this.emojiNames = emojiInstance.getEmojiNames();
    this.parseEmoji = emojiInstance.parseEmoji;
  },
  onReady: function onReady() {
    // 解决基础库小于 2.9.2 的兼容问题
    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        SDKVersion = _wx$getSystemInfoSync.SDKVersion;

    if ((0, _util.compareVersion)(SDKVersion, '2.9.1') < 0) {
      this.setData({
        canIUse: false
      });
    }
  },
  onkeyboardHeightChange: function onkeyboardHeightChange(e) {
    var height = e.detail.height;

    if (height === 0) {
      this.data._keyboardShow = false;

      this.setData({
        safeHeight: this.safeHeight,
        keyboardHeight: height
      });
    } else {
      this.data._keyboardShow = true;
      this.setData({
        safeHeight: 0,
        functionShow: false,
        emojiShow: false,
        keyboardHeight: height
      });
    }
  },
  hideAllPanel: function hideAllPanel() {
    this.setData({
      functionShow: false,
      emojiShow: false
    });
  },
  showEmoji: function showEmoji() {
    this.setData({
      functionShow: false,
      emojiShow: this.data._keyboardShow || !this.data.emojiShow
    });
  },
  showFunction: function showFunction() {
    this.setData({
      functionShow: this.data._keyboardShow || !this.data.functionShow,
      emojiShow: false
    });
  },
  chooseImage: function chooseImage() {},
  onFocus: function onFocus() {
    this.data._keyboardShow = true;

    this.hideAllPanel();
  },
  onBlur: function onBlur(e) {
    this.data._keyboardShow = false;
    this.data.cursor = e.detail.cursor || 0;
  },
  onInput: function onInput(e) {
    var value = e.detail.value;
    this.data.comment = value;
  },
  onConfirm: function onConfirm() {
    this.onsend();
  },
  insertEmoji: function insertEmoji(evt) {
    var emotionName = evt.detail.emotionName;
    var _data = this.data,
        cursor = _data.cursor,
        comment = _data.comment;

    var newComment = comment.slice(0, cursor) + emotionName + comment.slice(cursor);
    this.setData({
      comment: newComment,
      cursor: cursor + emotionName.length
    });
  },
  onsend: function onsend() {
    var comment = this.data.comment;
    var parsedComment = {
      emoji: this.parseEmoji(this.data.comment),
      id: 'emoji_' + this.data.historyList.length
    };
    this.setData({
      historyList: [].concat(_toConsumableArray(this.data.historyList), [parsedComment]),
      comment: '',
      emojiShow: false
    });
  },
  deleteEmoji: function deleteEmoji() {
    var pos = this.data.cursor;
    var comment = this.data.comment;
    var result = '';
    var cursor = 0;

    var emojiLen = 6;
    var startPos = pos - emojiLen;
    if (startPos < 0) {
      startPos = 0;
      emojiLen = pos;
    }
    var str = comment.slice(startPos, pos);
    var matchs = str.match(/\[([\u4e00-\u9fa5\w]+)\]$/g);
    // 删除表情
    if (matchs) {
      var rawName = matchs[0];
      var left = emojiLen - rawName.length;
      if (this.emojiNames.indexOf(rawName) >= 0) {
        var replace = str.replace(rawName, '');
        result = comment.slice(0, startPos) + replace + comment.slice(pos);
        cursor = startPos + left;
      }
      // 删除字符
    } else {
      var endPos = pos - 1;
      if (endPos < 0) endPos = 0;
      var prefix = comment.slice(0, endPos);
      var suffix = comment.slice(pos);
      result = prefix + suffix;
      cursor = endPos;
    }
    this.setData({
      comment: result,
      cursor: cursor
    });
  }
});
});