define("page/weui/example/dialog/dialog.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'dialog',
            path: 'page/weui/example/dialog/dialog'
        };
    },

    data: {
        dialogShow: false,
        showOneButtonDialog: false,
        buttons: [{ text: '取消' }, { text: '确定' }],
        oneButton: [{ text: '确定' }]
    },
    openConfirm: function openConfirm() {
        this.setData({
            dialogShow: true
        });
    },
    tapDialogButton: function tapDialogButton(e) {
        this.setData({
            dialogShow: false,
            showOneButtonDialog: false
        });
    },
    tapOneDialogButton: function tapOneDialogButton(e) {
        this.setData({
            showOneButtonDialog: true
        });
    }
});
});