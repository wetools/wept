define("page/weui/example/select-text/select-text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'select-text',
      path: 'page/weui/example/select-text/select-text'
    };
  },

  data: {
    arr: [{
      value: '长按，上侧复制',
      placement: 'top'
    }, {
      value: '长按，右侧复制',
      placement: 'right'
    }, {
      value: '长按，左侧复制',
      placement: 'left'
    }, {
      value: '长按，下侧复制',
      placement: 'bottom'
    }]
  },

  onLoad: function onLoad() {},
  onCopy: function onCopy(e) {
    console.log('onCopy', e);
  },
  handleTouchStart: function handleTouchStart(e) {
    console.log('@@ touchstart', e);
  },
  handleTap: function handleTap(e) {
    console.log('@@ tap', e);
    this.setData({
      evt: e
    });
  }
});
});