define("page/weui/example/loading/loading.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'loading',
      path: 'page/weui/example/loading/loading'
    };
  },

  data: {
    tips: '请稍后',
    show: true,
    animated: true
  },
  onShow: function onShow() {
    var _this = this;

    this.timer = setInterval(function () {
      _this.setData({
        show: !_this.data.show
      });
    }, 2000);
  },
  close: function close() {
    this.setData({
      animated: !this.data.animated
    });
  },
  onUnload: function onUnload() {
    clearInterval(this.timer);
  }
});
});