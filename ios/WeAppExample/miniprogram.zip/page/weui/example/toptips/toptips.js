define("page/weui/example/toptips/toptips.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'toptips',
      path: 'page/weui/example/toptips/toptips'
    };
  },

  data: {
    value: '',
    showTopTips: false,
    message: '请输入文本',
    type: 'info'
  },
  bindInputValue: function bindInputValue(e) {
    this.setData({
      value: e.detail.value
    });
  },
  bindConfirmTap: function bindConfirmTap() {
    if (this.data.value) {
      this.setData({
        showTopTips: true,
        message: this.data.value,
        type: 'success'
      });
    } else {
      this.setData({
        showTopTips: true,
        type: 'error'
      });
    }
  }
});
});