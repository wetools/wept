define("page/weui/example/tabs/webview.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _Page;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// miniprogram/page/weui/example/tabs/webview.js
Page((_Page = {

  /**
   * 页面的初始数据
   */
  onLoad: function onLoad(option) {
    // const { query } = option;
    // this.setData({
    //   src: query.url
    // })
  },
  data: {
    src: 'https://developers.weixin.qq.com/community/business'
  }

}, _defineProperty(_Page, 'onLoad', function onLoad(options) {}), _defineProperty(_Page, 'onReady', function onReady() {}), _defineProperty(_Page, 'onShow', function onShow() {}), _defineProperty(_Page, 'onHide', function onHide() {}), _defineProperty(_Page, 'onUnload', function onUnload() {}), _defineProperty(_Page, 'onPullDownRefresh', function onPullDownRefresh() {}), _defineProperty(_Page, 'onReachBottom', function onReachBottom() {}), _defineProperty(_Page, 'onShareAppMessage', function onShareAppMessage() {
  return {
    title: 'webview',
    path: 'page/weui/example/webview/webview'
  };
}), _Page));
});