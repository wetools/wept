define("page/weui/example/progress/progress.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

function _next() {
    var that = this;
    if (this.data.progress >= 100) {
        this.setData({
            disabled: false
        });
        return true;
    }
    this.setData({
        progress: ++this.data.progress
    });
    setTimeout(function () {
        _next.call(that);
    }, 20);
}

Page({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'progress',
            path: 'page/weui/example/progress/progress'
        };
    },

    data: {
        progress: 0,
        disabled: false
    },
    upload: function upload() {
        if (this.data.disabled) return;

        this.setData({
            progress: 0,
            disabled: true
        });
        _next.call(this);
    }
});
});