define("page/weui/example/wxml-to-canvas/demo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var wxml = function wxml(url) {
  return '<view class="container">\n  <image class="img" mode="aspectFit" src="' + url + '"></image>\n  <text class="title">\n    \u5FAE\u4FE1\u5F00\u653E\u793E\u533A\u7B80\u4ECB\uFF08\u89C6\u9891\uFF09\n  </text>\n  <text class="desc">\n    \u5FAE\u4FE1\u5F00\u653E\u793E\u533A\uFF0C\u662F\u4E00\u4E2A\u4E3A\u4F7F\u7528\u8005\u63D0\u4F9B\u4EA4\u6D41\u3001\u670D\u52A1\u7684\u5E73\u53F0\u3002\n  </text>\n</view>\n';
};

var style = {

  img: {
    width: 200,
    height: 120
  },
  container: {
    height: 200,
    width: 200,
    flexDirection: 'column'
  },
  title: {
    height: 20,
    width: 200,
    color: '#15c15f',
    margin: 4

  },
  desc: {
    fontSize: 13,
    height: 40,
    width: 200,
    color: '#4c4c4c',
    margin: 4
  }
};

module.exports = {
  wxml: wxml,
  style: style
};
});