define("page/weui/example/layeredpresentation/layeredpresentation.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

Page({
  data: {
    hide1: false,
    hide2: false,
    theme: 'light'
  },
  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  onClick: function onClick(e) {
    this.setData(_defineProperty({}, e.target.dataset.set, true));
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '分层展现',
      path: 'page/weui/example/layeredpresentation/layeredpresentation'
    };
  }
});
});