define("page/weui/example/gallery/gallery.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'gallery',
            path: 'page/weui/example/gallery/gallery'
        };
    },

    data: {
        imgUrls: ['http://desk-fd.zol-img.com.cn/g5/M00/02/05/ChMkJ1bKyZmIWCwZABEwe5zfvyMAALIQABa1z4AETCT730.jpg', 'http://desk-fd.zol-img.com.cn/g5/M00/02/05/ChMkJ1bKyZmIWCwZABEwe5zfvyMAALIQABa1z4AETCT730.jpg', 'http://desk-fd.zol-img.com.cn/g5/M00/02/05/ChMkJ1bKyZmIWCwZABEwe5zfvyMAALIQABa1z4AETCT730.jpg'],
        show: true
    },
    change: function change(e) {
        console.log('current index has changed', e.detail);
    },
    delete: function _delete(e) {
        console.log('delete', e.detail);
    },
    hide: function hide() {
        var _this = this;

        console.log('component hide');
        setTimeout(function () {
            console.log('component show');
            _this.setData({
                show: true
            });
        }, 1000);
    }
});
});