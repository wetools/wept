define("page/weui/example/telescopic/telescopic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  data: {},
  onLoad: function onLoad() {
    // wx.showModal({
    //   content: '暂不支持该功能，可在windows版微信（2.9.5及以上版本）中拖动窗口大小查看效果',
    //   showCancel: false,
    //   confirmText: '我知道了'
    // })
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '左右伸缩',
      path: 'page/weui/example/telescopic/telescopic'
    };
  }
});
});