define("page/weui/example/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _CustomPage = require('../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: '扩展能力',
            path: 'page/weui/example/index'
        };
    },

    data: {
        list: [{
            id: 'form',
            name: '表单',
            open: false,
            pages: ['cell', 'slideview', 'form', 'uploader']
        }, {
            id: 'widget',
            name: '基础组件',
            open: false,
            pages: ['article', 'icons', 'badge', 'flex', 'footer', 'gallery', 'grid', 'loadmore', 'loading', 'panel', 'preview']
        }],
        extendedList: [{
            id: 'extended',
            name: '扩展组件',
            open: false,
            pages: ['emoji', 'video-swiper', 'index-list', 'recycle-view', 'sticky', 'tabs', 'vtabs', 'barrage', 'select-text', 'wxml-to-canvas']
        }]
    },
    kindToggle: function kindToggle(e) {
        var id = e.currentTarget.id,
            list = this.data.list;
        for (var i = 0, len = list.length; i < len; ++i) {
            if (list[i].id == id) {
                list[i].open = !list[i].open;
            } else {
                list[i].open = false;
            }
        }
        // const extendedList = this.data.extendedList.map((item) => ({...item, open: false}))
        this.setData({
            list: list
            // extendedList,

        });
    },
    kindExtenedListToggle: function kindExtenedListToggle(e) {
        var id = e.currentTarget.id;
        var extendedList = this.data.extendedList;
        for (var i = 0, len = extendedList.length; i < len; ++i) {
            if (extendedList[i].id == id) {
                extendedList[i].open = !extendedList[i].open;
            } else {
                extenedList[i].open = false;
            }
        }
        var list = this.data.list.map(function (item) {
            return _extends({}, item, { open: false });
        });
        this.setData({
            extendedList: extendedList,
            list: list
        });
    },
    themeToggle: function themeToggle() {
        var App = getApp();

        if (App.themeChanged) {
            if (App.globalData.theme === 'light') {
                App.themeChanged('dark');
            } else {
                App.themeChanged('light');
            }
        }
    }
});
});