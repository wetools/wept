define("page/weui/example/video-swiper/video-swiper.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var urls = ['https://res.wx.qq.com/wxaliveplayer/htdocs/video14e1eea.mov', 'https://res.wx.qq.com/wxaliveplayer/htdocs/video24e1eeb.mov', 'https://res.wx.qq.com/wxaliveplayer/htdocs/video34e1eeb.mov', 'https://res.wx.qq.com/wxaliveplayer/htdocs/video44e1eeb.mov', 'https://res.wx.qq.com/wxaliveplayer/htdocs/video54e1eeb.mov'];


(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'video-swiper',
      path: 'page/weui/example/video-swiper/video-swiper'
    };
  },

  data: {
    videoList: []
  },
  onLoad: function onLoad() {

    var videoList = urls.map(function (item, index) {
      return {
        id: index,
        url: item,
        objectFit: 'contain'
      };
    });
    this.setData({
      videoList: videoList
    });
  },
  onReady: function onReady() {},
  onShow: function onShow() {},
  onHide: function onHide() {},
  onUnload: function onUnload() {},
  onPlay: function onPlay(e) {},
  onPause: function onPause(e) {
    //  console.log('pause', e.detail.activeId)
  },
  onEnded: function onEnded(e) {},
  onError: function onError(e) {},
  onWaiting: function onWaiting(e) {},
  onTimeUpdate: function onTimeUpdate(e) {},
  onProgress: function onProgress(e) {},
  onLoadedMetaData: function onLoadedMetaData(e) {
    console.log('LoadedMetaData', e);
  }
});
});