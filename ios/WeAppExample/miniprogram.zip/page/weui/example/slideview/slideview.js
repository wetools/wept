define("page/weui/example/slideview/slideview.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var base64 = require("../images/base64");


(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'sliderview',
      path: 'page/weui/example/sliderview/sliderview'
    };
  },

  onLoad: function onLoad() {
    this.setData({
      icon: base64.icon20,
      slideButtons: [{
        text: '普通',
        src: global.isDemo ? '/page/weui/example/cell/icon_love.svg' : '/example/cell/icon_love.svg' // icon的路径
      }, {
        text: '普通',
        extClass: 'test',
        src: global.isDemo ? '/page/weui/example/cell/icon_star.svg' : '/example/cell/icon_star.svg' // icon的路径
      }, {
        type: 'warn',
        text: '警示',
        extClass: 'test',
        src: global.isDemo ? '/page/weui/example/cell/icon_del.svg' : '/example/cell/icon_del.svg' // icon的路径
      }]
    });
  },
  slideButtonTap: function slideButtonTap(e) {
    console.log('slide button tap', e.detail);
  }
});
});