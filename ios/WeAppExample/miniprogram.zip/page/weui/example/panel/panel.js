define("page/weui/example/panel/panel.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var base64 = require("../images/base64");

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'panel',
            path: 'page/weui/example/panel/panel'
        };
    },

    onLoad: function onLoad() {
        this.setData({
            icon20: base64.icon20,
            icon60: base64.icon60
        });
    }
});
});