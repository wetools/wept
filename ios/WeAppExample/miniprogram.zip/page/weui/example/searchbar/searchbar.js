define("page/weui/example/searchbar/searchbar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _CustomPage2.default)({
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: 'searchbar',
            path: 'page/weui/example/searchbar/searchbar'
        };
    },

    data: {
        inputShowed: false,
        inputVal: "",
        i: 0
    },
    onLoad: function onLoad() {
        this.setData({
            search: this.search.bind(this)
        });
    },

    search: function search(value) {
        var _this = this;

        return new Promise(function (resolve, reject) {
            if (_this.data.i % 2 === 0) {
                setTimeout(function () {
                    resolve([{ text: '搜索结果', value: 1 }, { text: '搜索结果2', value: 2 }]);
                }, 200);
            } else {
                setTimeout(function () {
                    resolve([]);
                }, 200);
            }
            _this.setData({
                i: _this.data.i + 1
            });
        });
    },
    selectResult: function selectResult(e) {
        console.log('select result', e.detail);
    }
});
});