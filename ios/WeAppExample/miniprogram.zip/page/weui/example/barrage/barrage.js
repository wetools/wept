define("page/weui/example/barrage/barrage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _CustomPage = require('../../base/CustomPage');

var _CustomPage2 = _interopRequireDefault(_CustomPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _require = require('./utils'),
    mockData = _require.mockData;

(0, _CustomPage2.default)({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'barrage',
      path: 'page/weui/example/barrage/barrage'
    };
  },

  data: {
    src: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
    toggle: true,
    barrageValue: '',
    showBarrage: false
  },
  onReady: function onReady() {
    this.addBarrage();
  },
  addBarrage: function addBarrage() {
    var barrageComp = this.selectComponent('.barrage');
    this.barrage = barrageComp.getBarrageInstance({
      font: 'bold 16px sans-serif', // 字体
      duration: 15, // 弹幕时间 （移动 2000px 所需时长）
      lineHeight: 2, // 弹幕行高
      mode: 'overlap', // 弹幕重叠 overlap 不重叠 separate
      padding: [10, 10, 10, 10], // 弹幕区四周
      range: [0, 1],
      tunnelShow: false
    });
    // this.barrage.open()
    // const data = mockData(100)
    // this.barrage.addData(data)
    // this.timer = setInterval(() => {
    //   const data = mockData(100);
    //   this.barrage.addData(data);
    // }, 2000)
  },
  fullscreenchange: function fullscreenchange() {
    var _this = this;

    this.setData({
      toggle: false
    });
    setTimeout(function () {
      if (_this.barrage) _this.barrage.close();
      _this.setData({ toggle: true });
      _this.addBarrage();
    }, 1000);
  },
  handleOpenClick: function handleOpenClick() {
    var _this2 = this;

    this.setData({
      showBarrage: true
    });
    this.barrage.open();
    var data = mockData(3);
    this.barrage.addData(data);
    this.timer = setInterval(function () {
      var data = mockData(5);
      _this2.barrage.addData(data);
    }, 2000);
  },
  handleCloseClick: function handleCloseClick() {
    this.barrage.close();
    this.setData({
      showBarrage: false
    });
  },
  handleInput: function handleInput(e) {
    this.setData({
      barrageValue: e.detail.value
    });
  },
  handleAddClick: function handleAddClick() {
    var data = mockData(1, [this.data.barrageValue]);
    this.barrage.addData(data);
    this.setData({
      barrageValue: ''
    });
  },
  handleTunnelShowClick: function handleTunnelShowClick() {
    this.barrage.showTunnel();
  },
  handleTunnelHideClick: function handleTunnelHideClick() {
    this.barrage.hideTunnel();
  }
});
});