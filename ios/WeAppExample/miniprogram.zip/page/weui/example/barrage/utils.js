define("page/weui/example/barrage/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var msgs = ['666666', '保护', '妈妈我上电视了！！', '我要上电视！！', '老板晚上好', '前方高能预警', '主播迟到了~~~', '干的漂亮', '广东人民发来贺电'];

var color = ['red', 'rgb(0, 255, 0)', '#0000FF'];

var getRandom = function getRandom() {
  var max = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 10;
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  return Math.floor(Math.random() * (max - min) + min);
};

var mockData = function mockData(num) {
  var message = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : msgs;

  var data = [];
  for (var i = 0; i < num; i++) {
    var msgId = getRandom(message.length);
    var colorId = getRandom(color.length);
    data.push({
      content: message[msgId],
      color: color[colorId]
    });
  }
  return data;
};

module.exports = {
  mockData: mockData
};
});