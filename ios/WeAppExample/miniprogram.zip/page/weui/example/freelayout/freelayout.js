define("page/weui/example/freelayout/freelayout.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  data: {
    theme: 'light'
  },
  onLoad: function onLoad() {
    var _this = this;

    this.setData({
      theme: wx.getSystemInfoSync().theme || 'light'
    });

    if (wx.onThemeChange) {
      wx.onThemeChange(function (_ref) {
        var theme = _ref.theme;

        _this.setData({ theme: theme });
      });
    }
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '自由布局',
      path: 'page/weui/example/freelayout/freelayout'
    };
  }
});
});