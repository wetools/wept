define("page/weui/base/CustomPage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _theme = require('./behaviors/theme');

var _theme2 = _interopRequireDefault(_theme);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CustomPage = function CustomPage(options) {
	return Page(Object.assign({}, options, {
		behaviors: [_theme2.default].concat(options.behaviors || []),
		onLoad: function onLoad(query) {
			var app = getApp();
			if (this.themeChanged) {
				this.themeChanged(app.globalData.theme);
				app.watchThemeChange && app.watchThemeChange(this.themeChanged);
				options.onLoad && options.onLoad.call(this, query);
			}
		},
		onUnload: function onUnload() {
			var app = getApp();
			if (this.themeChanged) {
				app.unWatchThemeChange && app.unWatchThemeChange(this.themeChanged);
				options.onUnload && options.onUnload.call(this);
			}
		}
	}));
};

exports.default = CustomPage;
});