define("page/weui/components/select-text/select-text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    space: {
      type: String,
      value: ''
    },
    decode: {
      type: Boolean,
      value: false
    },
    placement: {
      type: String,
      value: 'top'
    },
    showCopyBtn: {
      type: Boolean,
      value: false
    },
    value: {
      type: String,
      value: ''
    }
  },
  observers: {
    onDocumentTap: function onDocumentTap() {
      this.setData({
        showToolTip: false
      });
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    showToolTip: false
  },

  /**
   * 组件的方法列表
   */
  methods: {
    handleLongPress: function handleLongPress() {
      if (!this.data.showCopyBtn) return;
      this.setData({
        showToolTip: true
      });
    },
    handleCopy: function handleCopy() {
      this.setData({
        showToolTip: false
      });
      wx.setClipboardData({
        data: this.data.value
      });
      this.triggerEvent('copy', {});
    },

    stopPropagation: function stopPropagation(e) {}
  }
});
});