define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var config = require('./config');
var themeListeners = [];
global.isDemo = true;
App({
  onLaunch: function onLaunch(opts, data) {
    var that = this;
    var canIUseSetBackgroundFetchToken = wx.canIUse('setBackgroundFetchToken');
    if (canIUseSetBackgroundFetchToken) {
      wx.setBackgroundFetchToken({
        token: 'getBackgroundFetchToken'
      });
    }
    if (wx.getBackgroundFetchData) {
      wx.getBackgroundFetchData({
        fetchType: 'pre',
        success: function success(res) {
          that.globalData.backgroundFetchData = res;
          console.log('读取预拉取数据成功');
        },
        fail: function fail() {
          console.log('读取预拉取数据失败');
          wx.showToast({
            title: '无缓存数据',
            icon: 'none'
          });
        },
        complete: function complete() {
          console.log('结束读取');
        }
      });
    }
    console.log('App Launch', opts);
    if (data && data.path) {
      wx.navigateTo({
        url: data.path
      });
    }
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力');
    } else {
      wx.cloud.init({
        env: config.envId,
        traceUser: true
      });
    }
  },
  onShow: function onShow(opts) {
    console.log('App Show', opts);
    // console.log(wx.getSystemInfoSync())
  },
  onHide: function onHide() {
    console.log('App Hide');
  },
  onThemeChange: function onThemeChange(_ref) {
    var theme = _ref.theme;

    this.globalData.theme = theme;
    themeListeners.forEach(function (listener) {
      listener(theme);
    });
  },
  watchThemeChange: function watchThemeChange(listener) {
    if (themeListeners.indexOf(listener) < 0) {
      themeListeners.push(listener);
    }
  },
  unWatchThemeChange: function unWatchThemeChange(listener) {
    var index = themeListeners.indexOf(listener);
    if (index > -1) {
      themeListeners.splice(index, 1);
    }
  },

  globalData: {
    theme: wx.getSystemInfoSync().theme,
    hasLogin: false,
    openid: null,
    iconTabbar: '/page/weui/example/images/icon_tabbar.png'
  },
  // lazy loading openid
  getUserOpenId: function getUserOpenId(callback) {
    var self = this;

    if (self.globalData.openid) {
      callback(null, self.globalData.openid);
    } else {
      wx.login({
        success: function success(data) {
          wx.cloud.callFunction({
            name: 'login',
            data: {
              action: 'openid'
            },
            success: function success(res) {
              console.log('拉取openid成功', res);
              self.globalData.openid = res.result.openid;
              callback(null, self.globalData.openid);
            },
            fail: function fail(err) {
              console.log('拉取用户openid失败，将无法正常使用开放接口等服务', res);
              callback(res);
            }
          });
        },
        fail: function fail(err) {
          console.log('wx.login 接口调用失败，将无法正常使用开放接口等服务', err);
          callback(err);
        }
      });
    }
  },

  // 通过云函数获取用户 openid，支持回调或 Promise
  getUserOpenIdViaCloud: function getUserOpenIdViaCloud() {
    var _this = this;

    return wx.cloud.callFunction({
      name: 'wxContext',
      data: {}
    }).then(function (res) {
      _this.globalData.openid = res.result.openid;
      return res.result.openid;
    });
  }
});
});