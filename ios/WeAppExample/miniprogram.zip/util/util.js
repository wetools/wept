define("util/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

function formatTime(time) {
  if (typeof time !== 'number' || time < 0) {
    return time;
  }

  var hour = parseInt(time / 3600, 10);
  time %= 3600;
  var minute = parseInt(time / 60, 10);
  time = parseInt(time % 60, 10);
  var second = time;

  return [hour, minute, second].map(function (n) {
    n = n.toString();
    return n[1] ? n : '0' + n;
  }).join(':');
}

function formatLocation(longitude, latitude) {
  if (typeof longitude === 'string' && typeof latitude === 'string') {
    longitude = parseFloat(longitude);
    latitude = parseFloat(latitude);
  }

  longitude = longitude.toFixed(2);
  latitude = latitude.toFixed(2);

  return {
    longitude: longitude.toString().split('.'),
    latitude: latitude.toString().split('.')
  };
}

function fib(n) {
  if (n < 1) return 0;
  if (n <= 2) return 1;
  return fib(n - 1) + fib(n - 2);
}

function formatLeadingZeroNumber(n) {
  var digitNum = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

  n = n.toString();
  var needNum = Math.max(digitNum - n.length, 0);
  return new Array(needNum).fill(0).join('') + n;
}

function formatDateTime(date) {
  var withMs = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  var ms = date.getMilliseconds();

  var ret = [year, month, day].map(function (value) {
    return formatLeadingZeroNumber(value, 2);
  }).join('-') + ' ' + [hour, minute, second].map(function (value) {
    return formatLeadingZeroNumber(value, 2);
  }).join(':');
  if (withMs) {
    ret += '.' + formatLeadingZeroNumber(ms, 3);
  }
  return ret;
}

function compareVersion(v1, v2) {
  v1 = v1.split('.');
  v2 = v2.split('.');
  var len = Math.max(v1.length, v2.length);

  while (v1.length < len) {
    v1.push('0');
  }
  while (v2.length < len) {
    v2.push('0');
  }

  for (var i = 0; i < len; i++) {
    var num1 = parseInt(v1[i], 10);
    var num2 = parseInt(v2[i], 10);

    if (num1 > num2) {
      return 1;
    } else if (num1 < num2) {
      return -1;
    }
  }

  return 0;
}

module.exports = {
  formatTime: formatTime,
  formatLocation: formatLocation,
  fib: fib,
  formatDateTime: formatDateTime,
  compareVersion: compareVersion
};
});