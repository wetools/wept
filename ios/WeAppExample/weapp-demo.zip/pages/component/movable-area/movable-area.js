define("pages/component/movable-area/movable-area.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
"use strict";

// pages/component/movable-area/movable-area.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    range: [true, false],
    scaleArea: false
  },

  handleChange: function handleChange(e) {
    var data = this.data;
    if (e.detail.value == 0) {
      data[e.target.id] = true;
    } else {
      data[e.target.id] = false;
    }
    this.setData(data);
  }
});
});