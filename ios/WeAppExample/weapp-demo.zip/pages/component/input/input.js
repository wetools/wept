define("pages/component/input/input.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/input/input.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    type: 0,
    password: 0,
    placeholder: '请输入',
    placeholderStyle: 0,
    placeholderClass: 0,
    disabled: 0,
    maxlength: 140,
    cursorSpacing: 0,
    focus: 0,
    confirmType: 4,
    confirmHold: 0,
    cursor: 0,
    selectionStart: -1,
    selectionEnd: -1,
    adjustPosition: 1,
    range: [false, true],
    typeRange: ['text', 'number', 'idcard', 'digit'],
    placeholderStyleRange: ['-', 'color: red;', 'color: yellow;', 'color: blue;'],
    placeholderClassRange: ['-', 'p_red', 'p_yellow', 'p_blue'],
    confirmTypeRange: ['send', 'search', 'next', 'go', 'done']
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  bindinputFn: function bindinputFn(e) {
    console.log('键盘输入时触发:' + JSON.stringify(e.detail));
  },
  bindfocusFn: function bindfocusFn(e) {
    console.log('输入框聚焦时触发:' + JSON.stringify(e.detail));
  },
  bindblurFn: function bindblurFn(e) {
    console.log('输入框失去焦点时触发:' + JSON.stringify(e.detail));
  },
  bindconfirmFn: function bindconfirmFn(e) {
    console.log('点击完成按钮时触发:' + JSON.stringify(e.detail));
  },
  bindkeyboardFn: function bindkeyboardFn(e) {
    console.log('键盘高度发生变化的时候触发此事件:' + JSON.stringify(e.detail));
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});