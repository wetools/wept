define("pages/component/audio/audio.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/audio/audio.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: 'myAudio',
    loop: 0,
    controls: 1,
    poster: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000003rsKF44GyaSk.jpg?max_age=2592000',
    name: '此时此刻',
    author: '许巍',
    src: 'http://ws.stream.qqmusic.qq.com/M500001VfvsJ21xFqb.mp3?guid=ffffffff82def4af4b12b3cd9337d5e7&uin=346897220&vkey=6292F51E1E384E06DCBDC9AB7C49FD713D632D313AC4858BACB8DDD29067D3C601481D36E62053BF8DFEAF74C0A5CCFADD6471160CAF3E6A&fromtag=46',
    range: [false, true]
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  binderrorFn: function binderrorFn(e) {
    console.log('当发生错误时触发 error 事件' + JSON.stringify(e.detail));
  },
  bindplayFn: function bindplayFn(e) {
    console.log('当开始/继续播放时触发play事件' + JSON.stringify(e.detail));
  },
  bindpauseFn: function bindpauseFn(e) {
    console.log('当暂停播放时触发 pause 事件' + JSON.stringify(e.detail));
  },
  bindtimeupdateFn: function bindtimeupdateFn(e) {
    console.log('当播放进度改变时触发 timeupdate 事件' + JSON.stringify(e.detail));
  },
  bindendedFn: function bindendedFn(e) {
    console.log('当播放到末尾时触发 ended 事件' + JSON.stringify(e.detail));
  },

  audioPlay: function audioPlay() {
    this.audioCtx.play();
  },
  audioPause: function audioPause() {
    this.audioCtx.pause();
  },
  audio14: function audio14() {
    this.audioCtx.seek(14);
  },
  audioStart: function audioStart() {
    this.audioCtx.seek(0);
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {
    // 使用 wx.createAudioContext 获取 audio 上下文 context
    this.audioCtx = wx.createAudioContext('myAudio');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});