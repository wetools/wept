define("pages/component/video/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/video/video.js
function getRandomColor() {
  var rgb = [];
  for (var i = 0; i < 3; ++i) {
    var color = Math.floor(Math.random() * 256).toString(16);
    color = color.length == 1 ? '0' + color : color;
    rgb.push(color);
  }
  return '#' + rgb.join('');
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src: '',
    duration: 0,
    controls: 1,
    danmuList: [{
      text: '第 1s 出现的弹幕',
      color: '#ff0000',
      time: 1
    }, {
      text: '第 3s 出现的弹幕',
      color: '#ff00ff',
      time: 3
    }],
    danmuBtn: 0,
    enableDanmu: 0,
    autoplay: 0,
    loop: 0,
    muted: 0,
    initialTime: 0,
    direction: 0,
    showProgress: 1,
    showFullscreenBtn: 1,
    showPlayBtn: 1,
    showCenterPlayBtn: 1,
    enableProgressGesture: 1,
    objectFit: 0,
    poster: '',
    showMuteBtn: 0,
    title: '',
    playBtnPosition: 0,
    enablePlayGesture: 0,
    autoPauseIfNavigate: 1,
    autoPauseIfOpenNative: 1,
    vslideGesture: 0,
    vslideGestureInFullscreen: 1,
    range: [false, true],
    directionRange: [0, 90, -90],
    objectFitRange: ['contain', 'fill', 'cover'],
    playBtnPositionRange: ['bottom', 'center']
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  binderrorFn: function binderrorFn(e) {
    console.log('当发生错误时触发 error 事件' + JSON.stringify(e.detail));
  },
  bindplayFn: function bindplayFn(e) {
    console.log('当开始/继续播放时触发play事件' + JSON.stringify(e.detail));
  },
  bindpauseFn: function bindpauseFn(e) {
    console.log('当暂停播放时触发 pause 事件' + JSON.stringify(e.detail));
  },
  bindtimeupdateFn: function bindtimeupdateFn(e) {
    // console.log('当播放进度改变时触发 timeupdate 事件' + JSON.stringify(e.detail))
  },
  bindendedFn: function bindendedFn(e) {
    console.log('当播放到末尾时触发 ended 事件' + JSON.stringify(e.detail));
  },
  bindfullscreenchangeFn: function bindfullscreenchangeFn(e) {
    console.log('视频进入和退出全屏时触发' + JSON.stringify(e.detail));
  },
  bindwaitingFn: function bindwaitingFn(e) {
    console.log('视频出现缓冲时触发	' + JSON.stringify(e.detail));
  },
  bindprogressFn: function bindprogressFn(e) {
    console.log('加载进度变化时触发，只支持一段加载	' + JSON.stringify(e.detail));
  },

  bindInputBlur: function bindInputBlur(e) {
    this.inputValue = e.detail.value;
  },
  bindButtonTap: function bindButtonTap() {
    var that = this;
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      camera: ['front', 'back'],
      success: function success(res) {
        that.setData({
          src: res.tempFilePath
        });
      }
    });
  },
  bindSendDanmu: function bindSendDanmu() {
    this.videoContext.sendDanmu({
      text: this.inputValue,
      color: getRandomColor()
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {
    this.videoContext = wx.createVideoContext('myVideo');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});