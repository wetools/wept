define("pages/component/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/index.js
Page({

  /**
   * Page initial data
   */
  data: {
    categories: [{
      title: "视图容器",
      display: false,
      components: [{
        title: 'movable-view（不支持）',
        page: '/pages/component/movable-view/movable-view'
      }, {
        title: 'cover-image（不支持）',
        page: '/pages/component/cover-image/cover-image'
      }, {
        title: 'cover-view（不支持）',
        page: '/pages/component/cover-view/cover-view'
      }, {
        title: 'movable-area（不支持）',
        page: '/pages/component/movable-area/movable-area'
      }, {
        title: 'scroll-view',
        page: '/pages/component/scroll-view/scroll-view'
      }, {
        title: 'swiper',
        page: '/pages/component/swiper/swiper'
      }, {
        title: 'view',
        page: '/pages/component/view/view'
      }]
    }, {
      title: "基础内容",
      display: false,
      components: [{
        title: 'icon',
        page: '/pages/component/icon/icon'
      }, {
        title: 'progress',
        page: '/pages/component/progress/progress'
      }, {
        title: 'rich-text',
        page: '/pages/component/rich-text/rich-text'
      }, {
        title: 'text',
        page: '/pages/component/text/text'
      }]
    }, {
      title: "表单组件",
      display: false,
      components: [{
        title: 'button',
        page: '/pages/component/button/button'
      }, {
        title: 'checkbox',
        page: '/pages/component/checkbox/checkbox'
      }, {
        title: 'editor（不支持）',
        page: '/pages/component/editor/editor'
      }, {
        title: 'form',
        page: '/pages/component/form/form'
      }, {
        title: 'input',
        page: '/pages/component/input/input'
      }, {
        title: 'label',
        page: '/pages/component/label/label'
      }, {
        title: 'picker',
        page: '/pages/component/picker/picker'
      }, {
        title: 'picker-view',
        page: '/pages/component/picker-view/picker-view'
      }, {
        title: 'radio',
        page: '/pages/component/radio/radio'
      }, {
        title: 'slider',
        page: '/pages/component/slider/slider'
      }, {
        title: 'switch',
        page: '/pages/component/switch/switch'
      }, {
        title: 'textarea',
        page: '/pages/component/textarea/textarea'
      }]
    }, {
      title: "导航",
      display: false,
      components: [{
        title: 'functional-page-navigator（需要指定场景，不支持）',
        page: ''
      }, {
        title: 'navigator',
        page: '/pages/component/navigator/navigator'
      }]
    }, {
      title: "媒体组件",
      display: false,
      components: [{
        title: 'audio',
        page: '/pages/component/audio/audio'
      }, {
        title: 'camera（不支持）',
        page: '/pages/component/camera/camera'
      }, {
        title: 'image',
        page: '/pages/component/image/image'
      }, {
        title: 'live-player （需要指定场景，不支持）',
        page: ''
      }, {
        title: 'live-pusher （需要指定场景，不支持）',
        page: ''
      }, {
        title: 'video',
        page: '/pages/component/video/video'
      }]
    }, {
      title: "地图",
      display: false,
      components: [{
        title: 'map',
        page: '/pages/component/map/map'
      }]
    }, {
      title: "画布",
      display: false,
      components: [{
        title: 'canvas',
        page: '/pages/component/canvas/canvas'
      }]
    }, {
      title: "开放能力",
      display: false,
      components: [{
        title: 'ad （需要指定场景，不支持）',
        page: ''
      }, {
        title: 'official-account （需要指定场景，不支持）',
        page: ''
      }, {
        title: 'open-data（不支持）',
        page: '/pages/component/open-data/open-data'
      }, {
        title: 'web-view',
        page: '/pages/component/web-view/web-view'
      }]
    }]
  },
  toggleCategory: function toggleCategory(e) {
    var categories = this.data.categories.map(function (category) {
      if (category.title === e.target.id) {
        category.display = !category.display;
      }

      return category;
    });
    this.setData({ categories: categories });
  },
  onReady: function onReady() {
    // wx.navigateTo({
    //   url: '/pages/component/map/map',
    // })
  },
  onShareAppMessage: function onShareAppMessage(e) {
    console.log('from = ' + e.from);
    console.log('target = ' + e.target);
    console.log('webViewUrl = ' + e.webViewUrl);

    return {
      title: '自定义分享',
      path: '/pages/component/button/button'
      // imageUrl: 'http://'
    };
  }
});
});