define("pages/component/canvas/canvas.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/canvas/canvas.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: '',
    canvasId: 'myCanvas',
    disableScroll: 0,
    range: [false, true]
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  bindtouchstartFn: function bindtouchstartFn(e) {
    console.log('手指触摸动作开始:');
  },
  bindtouchmoveFn: function bindtouchmoveFn(e) {
    console.log('手指触摸动作开始:');
  },
  bindtouchendFn: function bindtouchendFn(e) {
    console.log('手指触摸动作结束:');
  },
  bindtouchcancelFn: function bindtouchcancelFn(e) {
    console.log('手指触摸动作被打断，如来电提醒，弹窗:');
  },
  bindlongtapFn: function bindlongtapFn(e) {
    console.log('手指长按 500ms 之后触发，触发了长按事件后进行移动不会触发屏幕的滚动:');
  },
  binderrorFn: function binderrorFn(e) {
    console.log('当发生错误时触发 error 事件:' + JSON.stringify(e.detail));
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady(e) {
    var context = wx.createCanvasContext('myCanvas');

    context.setStrokeStyle("#00ff00");
    context.setLineWidth(5);
    context.rect(0, 0, 300, 200);
    context.stroke();
    context.setStrokeStyle("#ff0000");
    context.setLineWidth(2);
    context.moveTo(160, 100);
    context.arc(100, 100, 60, 0, 2 * Math.PI, true);
    context.moveTo(140, 100);
    context.arc(100, 100, 40, 0, Math.PI, false);
    context.moveTo(85, 80);
    context.arc(80, 80, 5, 0, 2 * Math.PI, true);
    context.moveTo(125, 80);
    context.arc(120, 80, 5, 0, 2 * Math.PI, true);
    context.stroke();
    context.draw();
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});