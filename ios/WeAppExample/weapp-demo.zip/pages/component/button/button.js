define("pages/component/button/button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

Page({
  data: {},
  formSubmit: function formSubmit() {
    wx.showToast({
      title: 'submit'
    });
  },
  formReset: function formReset() {
    wx.showToast({
      title: 'reset'
    });
  },
  getContact: function getContact(e) {
    wx.showModal({
      title: 'Contact',
      content: JSON.stringify(e.detail, null, 2)
    });
  },
  getuserinfo: function getuserinfo(e) {
    wx.showModal({
      title: 'userInfo',
      content: JSON.stringify(e.detail, null, 2)
    });
  },
  getPhoneNumber: function getPhoneNumber(e) {
    wx.showModal({
      title: 'getPhoneNumber',
      content: JSON.stringify(e.detail, null, 2)
    });
  },

  getOpenSetting: function getOpenSetting(e) {
    wx.showModal({
      title: 'getOpenSetting',
      content: JSON.stringify(e.detail, null, 2)
    });
  }
});
});