define("pages/component/editor/editor.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/editor/editor.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    readOnly: 0,
    placeholder: '开始输入...',
    showImgSize: 1,
    showImgToolbar: 1,
    showImgResize: 1,
    range: [false, true],
    content: '',
    content_html: '',
    nodes: [{
      name: 'div',
      attrs: {
        class: 'div_class',
        style: 'line-height: 60px; color: red;'
      },
      children: [{
        type: 'text',
        text: 'RichText组件'
      }]
    }]
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  insertImgFn: function insertImgFn() {
    this.editorCtx.insertImage({
      src: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1543767268337&di=5a3bbfaeb30149b2afd33a3c7aaa4ead&imgtype=0&src=http%3A%2F%2Fimg02.tooopen.com%2Fimages%2F20151031%2Ftooopen_sy_147004931368.jpg',
      success: function success() {
        console.log('insert image success');
      }
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},
  bindreadyFn: function bindreadyFn() {
    var _this = this;

    console.log('编辑器初始化完成时触发');
    wx.createSelectorQuery().select('#editor').context(function (res) {
      _this.editorCtx = res.context;
    }).exec();
  },
  bindfocusFn: function bindfocusFn(e) {
    console.log('编辑器聚焦时触发，' + JSON.stringify(e.detail));
  },
  bindblurFn: function bindblurFn(e) {
    console.log('编辑器失去焦点时触发，' + JSON.stringify(e.detail));
  },
  bindinputFn: function bindinputFn(e) {
    console.log('编辑器内容改变时触发, ' + JSON.stringify(e.detail));
    this.setData({
      content: e.detail
    });
  },
  bindstatuschangeFn: function bindstatuschangeFn(e) {
    console.log('通过 Context 方法改变编辑器内样式时触发，返回选区已设置的样式,');
  },

  // 显示结果
  clickShowText: function clickShowText(e) {
    this.setData({
      nodes: this.data.content.html ? this.data.content.html : '',
      content_html: this.data.content.html ? this.data.content.html : ''
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});