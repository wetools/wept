define("pages/component/picker-view/picker-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/picker-view/picker-view.js
var date = new Date();
var years = [];
var months = [];
var days = [];

for (var i = 1990; i <= date.getFullYear(); i++) {
  years.push(i);
}

for (var _i = 1; _i <= 12; _i++) {
  months.push(_i);
}

for (var _i2 = 1; _i2 <= 31; _i2++) {
  days.push(_i2);
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    years: years,
    year: date.getFullYear(),
    months: months,
    month: 2,
    days: days,
    day: 2,
    value: [9999, 1, 1],
    indicatorStyle: 2,
    indicatorClass: 1,
    maskStyle: 1,
    maskClass: 3,
    indicatorStyleRange: ['-', 'height: 30px;', 'height: 40px;', 'height: 50px;'],
    indicatorClassRange: ['-', 'iClass-1', 'iClass-2', 'iClass-3'],
    maskStyleRange: ['-', ' background: rgba(255, 0, 0, 0.1);', 'background: rgba(89, 0, 255, 0.1);', 'background: rgba(0, 0, 0, 0.1);'],
    maskClassRange: ['-', 'mClass-1', 'mClass-2', 'mClass-3']
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  bindChange: function bindChange(e) {
    console.log('滚动选择时触发change事件，' + JSON.stringify(e.detail));
    var val = e.detail.value;
    this.setData({
      year: this.data.years[val[0]],
      month: this.data.months[val[1]],
      day: this.data.days[val[2]]
    });
  },
  bindpickstartFn: function bindpickstartFn(e) {
    console.log('当滚动选择开始时候触发事件,' + JSON.stringify(e.detail));
  },
  bindpickendFn: function bindpickendFn(e) {
    console.log('当滚动选择结束时候触发事件,' + JSON.stringify(e.detail));
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});