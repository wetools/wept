define("pages/component/slider/slider.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var _util = require('../../../utils/util.js');

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } } // pages/server/slider.js


Page({

  /**
   * 页面的初始数据
   */
  data: {
    min: 0,
    max: 100,
    step: 1,
    disabled: 0,
    value: 0,
    color: 0,
    selectedColor: 0,
    activeColor: 0,
    backgroundColor: 0,
    blockSize: 16,
    blockColor: 0,
    showValue: 0,
    range: [false, true],
    colorRange: ['#e9e9e9'].concat(_toConsumableArray(_util.colorArray)),
    selectedColorRange: ['#1aad19'].concat(_toConsumableArray(_util.colorArray)),
    activeColorRange: ['#1aad19'].concat(_toConsumableArray(_util.colorArray)),
    backgroundColorRange: ['#e9e9e9'].concat(_toConsumableArray(_util.colorArray)),
    blockSizeRange: [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28],
    blockColorRange: ['#ffffff'].concat(_toConsumableArray(_util.colorArray))
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  bindchangeFn: function bindchangeFn(e) {
    console.log('完成一次拖动后触发的事件:' + JSON.stringify(e.detail));
  },
  bindchangingFn: function bindchangingFn(e) {
    console.log('拖动过程中触发的事件:' + JSON.stringify(e.detail));
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});