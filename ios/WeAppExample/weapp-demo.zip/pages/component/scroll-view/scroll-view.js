define("pages/component/scroll-view/scroll-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/scroll-view/scroll-view.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    scrollX: false,
    scrollY: false,
    upperThreshold: 50,
    lowerThreshold: 50,
    scrollTop: 0,
    scrollLeft: 0,
    scrollIntoView: 0,
    scrollWithAnimation: false,
    enableBackToTop: false,
    range: [true, false],
    intoRange: [{
      id: -1,
      name: '请选择'
    }, {
      id: 0,
      name: 'topInto'
    }, {
      id: 1,
      name: 'bottomInto'
    }, {
      id: 2,
      name: 'leftInto'
    }, {
      id: 3,
      name: 'rightInto'
    }]
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  handleChange: function handleChange(e) {
    var data = this.data;
    if (e.detail.value == 0) {
      data[e.target.id] = true;
    } else {
      data[e.target.id] = false;
    }
    this.setData(data);
  },
  handleNameChange: function handleNameChange(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },

  upper: function upper(e) {
    console.log('滚动到顶部/左边时触发, type:' + e.type + ' offsetLeft:' + e.target.offsetLeft + ' offsetTop:' + e.target.offsetTop);
  },
  lower: function lower(e) {
    console.log('滚动到底部/右边时触发, type:' + e.type + ' offsetLeft:' + e.target.offsetLeft + ' offsetTop:' + e.target.offsetTop);
  },
  scroll: function scroll(e) {
    var _e$detail = e.detail,
        scrollLeft = _e$detail.scrollLeft,
        scrollTop = _e$detail.scrollTop,
        scrollHeight = _e$detail.scrollHeight,
        scrollWidth = _e$detail.scrollWidth;

    console.log('滚动时触发, scrollLeft:' + scrollLeft + ' scrollTop:' + scrollTop + ' scrollHeight:' + scrollHeight + ' scrollWidth:' + scrollWidth);
  }
});
});