define("pages/component/textarea/textarea.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/textarea/textarea.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    placeholder: '请输入',
    placeholderStyle: 0,
    placeholderClass: 0,
    disabled: 0,
    maxlength: 140,
    autoFocus: 0,
    focus: 0,
    autoHeight: 0,
    fixed: 0,
    cursor: 0,
    cursorSpacing: 0,
    showConfirmBar: 1,
    selectionStart: -1,
    selectionEnd: -1,
    adjustPosition: 1,
    range: [false, true],
    placeholderStyleRange: ['-', 'color: red;', 'color: yellow;', 'color: blue;'],
    placeholderClassRange: ['-', 'p_red', 'p_yellow', 'p_blue']
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },

  bindinputFn: function bindinputFn(e) {
    console.log('当键盘输入时，触发 input 事件:' + JSON.stringify(e.detail));
  },
  bindfocusFn: function bindfocusFn(e) {
    console.log('输入框聚焦时触发:' + JSON.stringify(e.detail));
  },
  bindblurFn: function bindblurFn(e) {
    console.log('输入框失去焦点时触发:' + JSON.stringify(e.detail));
  },
  bindconfirmFn: function bindconfirmFn(e) {
    console.log('点击完成时， 触发 confirm 事件:' + JSON.stringify(e.detail));
  },
  bindkeyboardFn: function bindkeyboardFn(e) {
    console.log('键盘高度发生变化的时候触发此事件:' + JSON.stringify(e.detail));
  },
  bindlinechangeFn: function bindlinechangeFn(e) {
    console.log('输入框行数变化时调用:' + JSON.stringify(e.detail));
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});