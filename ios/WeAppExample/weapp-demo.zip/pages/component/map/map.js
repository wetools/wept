define("pages/component/map/map.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
"use strict";

// pages/component/map/map.js
Page({

  data: {
    longitude: 113.324520,
    latitude: 23.099994,
    scale: 16,
    rotate: 0,
    skew: 0,
    showLocation: false,
    enable3D: true,
    showCompass: false,
    enableOverlooking: false,
    enableZoom: true,
    enableScroll: false,
    enableRotate: false,
    enableSatellite: false,
    enableTraffic: false,
    range: [true, false]
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  handleChange: function handleChange(e) {
    var data = this.data;
    if (e.detail.value == 0) {
      data[e.target.id] = true;
    } else {
      data[e.target.id] = false;
    }
    this.setData(data);
  }
});
});