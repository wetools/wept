define("pages/component/camera/camera.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/camera/camera.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src: '',
    mode: 0,
    devicePosition: 1,
    flash: 0,
    frameSize: 1,
    range: [false, true],
    modeRange: ['normal', 'scanCode'],
    devicePositionRange: ['front', 'back'],
    flashRange: ['auto', 'on', 'off'],
    frameSizeRange: ['small', 'medium', 'large']
  },

  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  takePhoto: function takePhoto() {
    var _this = this;

    var ctx = wx.createCameraContext();
    ctx.takePhoto({
      quality: 'high',
      success: function success(res) {
        _this.setData({
          src: res.tempImagePath
        });
      }
    });
  },
  bindstopFn: function bindstopFn(e) {
    console.log('摄像头在非正常终止时触发，如退出后台等情况' + JSON.stringify(e));
  },
  binderrorFn: function binderrorFn(e) {
    console.log('用户不允许使用摄像头时触发' + JSON.stringify(e));
  },
  bindinitdoneFn: function bindinitdoneFn(e) {
    console.log('相机初始化完成时触发' + JSON.stringify(e));
  },
  bindscancodeFn: function bindscancodeFn(e) {
    console.log('在扫码识别成功时触发' + JSON.stringify(e));
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});