define("pages/component/navigator/navigator.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/component/navigator/navigator.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    target: 0,
    url: 0,
    openType: 0,
    delta: 1,
    appId: 'wx43ac3c8667be819c',
    path: '',
    extraData: {
      'name': 'wuziqiang'
    },
    version: 0,
    hoverClass: 0,
    hoverStopPropagation: 0,
    hoverStartTime: 50,
    hoverStayTime: 600,
    range: [false, true],
    targetRange: ['self', 'miniProgram'],
    urlRange: [{
      name: 'input组件',
      src: '/pages/component/input/input'
    }, {
      name: 'ico组件',
      src: '/pages/component/icon/icon'
    }, {
      name: 'Tab页面',
      src: '/pages/component/index'
    }],
    openTypeRange: ['navigate', 'redirect', 'switchTab', 'reLaunch', 'navigateBack', 'exit'],
    versionRange: ['develop', 'trial', 'release'],
    hoverClassRange: ['navigator-hover', 'none']
  },
  handInput: function handInput(e) {
    var data = this.data;
    data[e.target.id] = e.detail.value;
    this.setData(data);
  },
  bindsuccessFn: function bindsuccessFn() {
    console.log('跳转小程序成功');
  },
  bindfailFn: function bindfailFn() {
    console.log('跳转小程序失败');
  },
  bindcompleteFn: function bindcompleteFn() {
    console.log('跳转小程序完成');
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});