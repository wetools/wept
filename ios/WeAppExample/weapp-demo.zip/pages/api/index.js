define("pages/api/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/api/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    categories: [{
      title: "吃瓜自定义接口",
      display: false,
      components: [{
        title: '登录',
        page: '/pages/cgapi/login'
      }]
    }, {
      title: "基础",
      display: false,
      components: [{
        title: '基础',
        page: '/pages/api/basis/basis'
      }, {
        title: '系统-系统信息',
        page: '/pages/api/system-information/system-information'
      }, {
        title: '更新',
        page: '/pages/api/update/update'
      }, {
        title: '小程序-生命周期',
        page: '/pages/api/getLaunchOptions/getLaunchOptions'
      }, {
        title: '小程序-应用级事件',
        page: '/pages/api/emergencyEvents/emergencyEvents'
      }, {
        title: '调试',
        page: '/pages/api/debug/debug'
      }, {
        title: '定时器',
        page: '/pages/api/timer/timer'
      }]
    }, {
      title: "路由",
      display: false,
      components: [{
        title: '路由',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "界面",
      display: false,
      components: [{
        title: '交互',
        page: '/pages/api/interaction/interaction'
      }, {
        title: '导航栏',
        page: '/pages/api/nav/nav'
      }, {
        title: '背景',
        page: '/pages/api/background/background'
      }, {
        title: 'Tab Bar',
        page: '/pages/api/tabBar/tabBar'
      }, {
        title: '字体',
        page: '/pages/api/fontFace/fontFace'
      }, {
        title: '下拉刷新',
        page: '/pages/api/pullDownRefresh/pullDownRefresh'
      }, {
        title: '滚动',
        page: '/pages/api/pageScrollTop/pageScrollTop'
      }, {
        title: '动画',
        page: '/pages/api/router/router'
      }, {
        title: '置顶',
        page: '/pages/api/setTop/setTop'
      }, {
        title: '菜单',
        page: '/pages/api/menu/menu'
      }, {
        title: '窗口',
        page: '/pages/api/windowResize/windowResize'
      }, {
        title: '键盘',
        page: '/pages/api/keyboard/keyboard'
      }]
    }, {
      title: "网络",
      display: false,
      components: [{
        title: '发起请求',
        page: '/pages/api/router/router'
      }, {
        title: '下载',
        page: '/pages/api/router/router'
      }, {
        title: '上传',
        page: '/pages/api/router/router'
      }, {
        title: 'WebSocket',
        page: '/pages/api/router/router'
      }, {
        title: 'mDNS',
        page: '/pages/api/router/router'
      }, {
        title: 'UDP 通信',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "数据缓存",
      display: false,
      components: [{
        title: '数据缓存',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "媒体",
      display: false,
      components: [{
        title: '地图',
        page: '/pages/api/router/router'
      }, {
        title: '图片',
        page: '/pages/api/router/router'
      }, {
        title: '视频',
        page: '/pages/api/router/router'
      }, {
        title: '音频',
        page: '/pages/api/router/router'
      }, {
        title: '背景音频',
        page: '/pages/api/router/router'
      }, {
        title: '实时音视频',
        page: '/pages/api/router/router'
      }, {
        title: '录音',
        page: '/pages/api/router/router'
      }, {
        title: '相机',
        page: '/pages/api/router/router'
      }, {
        title: '富文本',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "位置",
      display: false,
      components: [{
        title: '位置',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "转发",
      display: false,
      components: [{
        title: '转发',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "画布",
      display: false,
      components: [{
        title: '画布',
        page: '/pages/api/router/router'
      }, {
        title: 'Canvas',
        page: '/pages/api/router/router'
      }, {
        title: 'CanvasContext',
        page: '/pages/api/router/router'
      }, {
        title: 'CanvasGradient',
        page: '/pages/api/router/router'
      }, {
        title: 'OffscreenCanvas',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "文件",
      display: false,
      components: [{
        title: '文件',
        page: '/pages/api/router/router'
      }, {
        title: 'FileSystemManager',
        page: '/pages/api/router/router'
      }, {
        title: 'Stats',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "开放接口",
      display: false,
      components: [{
        title: '登录',
        page: '/pages/api/router/router'
      }, {
        title: '小程序跳转',
        page: '/pages/api/router/router'
      }, {
        title: '帐号信息',
        page: '/pages/api/router/router'
      }, {
        title: '用户信息',
        page: '/pages/api/router/router'
      }, {
        title: '数据上报',
        page: '/pages/api/router/router'
      }, {
        title: '数据分析',
        page: '/pages/api/router/router'
      }, {
        title: '支付',
        page: '/pages/api/router/router'
      }, {
        title: '授权',
        page: '/pages/api/router/router'
      }, {
        title: '设置',
        page: '/pages/api/router/router'
      }, {
        title: '收货地址',
        page: '/pages/api/router/router'
      }, {
        title: '卡券',
        page: '/pages/api/router/router'
      }, {
        title: '发票',
        page: '/pages/api/router/router'
      }, {
        title: '生物认证',
        page: '/pages/api/router/router'
      }, {
        title: '微信运动',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "设备",
      display: false,
      components: [{
        title: 'iBeacon',
        page: '/pages/api/router/router'
      }, {
        title: 'Wi-Fi',
        page: '/pages/api/router/router'
      }, {
        title: '低功耗蓝牙',
        page: '/pages/api/router/router'
      }, {
        title: '联系人',
        page: '/pages/api/router/router'
      }, {
        title: '蓝牙',
        page: '/pages/api/router/router'
      }, {
        title: '电量',
        page: '/pages/api/router/router'
      }, {
        title: '剪贴板',
        page: '/pages/api/router/router'
      }, {
        title: 'NFC',
        page: '/pages/api/router/router'
      }, {
        title: '网络',
        page: '/pages/api/router/router'
      }, {
        title: '屏幕',
        page: '/pages/api/router/router'
      }, {
        title: '电话',
        page: '/pages/api/router/router'
      }, {
        title: '加速计',
        page: '/pages/api/router/router'
      }, {
        title: '罗盘',
        page: '/pages/api/router/router'
      }, {
        title: '设备方向',
        page: '/pages/api/router/router'
      }, {
        title: '陀螺仪',
        page: '/pages/api/router/router'
      }, {
        title: '性能',
        page: '/pages/api/router/router'
      }, {
        title: '扫码',
        page: '/pages/api/router/router'
      }, {
        title: '振动',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "Worker",
      display: false,
      components: [{
        title: 'Worker',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "第三方平台",
      display: false,
      components: [{
        title: '第三方平台',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "WXML",
      display: false,
      components: [{
        title: 'WXML',
        page: '/pages/api/router/router'
      }, {
        title: 'IntersectionObserver',
        page: '/pages/api/router/router'
      }, {
        title: 'NodesRef',
        page: '/pages/api/router/router'
      }, {
        title: 'SelectorQuery',
        page: '/pages/api/router/router'
      }]
    }, {
      title: "广告",
      display: false,
      components: [{
        title: '广告',
        page: '/pages/api/router/router'
      }, {
        title: 'InterstitialAd',
        page: '/pages/api/router/router'
      }, {
        title: 'RewardedVideoAd',
        page: '/pages/api/router/router'
      }]
    }]
  },
  toggleCategory: function toggleCategory(e) {
    var categories = this.data.categories.map(function (category) {
      if (category.title === e.target.id) {
        category.display = !category.display;
      }

      return category;
    });
    this.setData({ categories: categories });
  },
  onLoad: function onLoad(options) {
    console.log('接口Api首页 onLoad:' + JSON.stringify(options));
  },
  onShow: function onShow() {
    console.log('接口Api首页 onShow');
  }
});
});