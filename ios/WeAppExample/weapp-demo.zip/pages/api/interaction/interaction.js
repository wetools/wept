define("pages/api/interaction/interaction.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/api/interaction/interaction.js
Page({

  /**
   * 页面的初始数据
   */
  data: {},
  showToastFn: function showToastFn() {
    wx.showToast({
      title: 'showToast',
      icon: 'none',
      duration: 5000,
      mask: false,
      success: function success() {
        console.log('showToash success');
      },
      fail: function fail() {
        console.log('showToash fail');
      },
      complete: function complete() {
        console.log('showToash complete');
      }
    });
  },
  hideToastFn: function hideToastFn() {
    wx.hideToast({
      success: function success() {
        console.log('hideToast success');
      },
      fail: function fail() {
        console.log('hideToast fail');
      },
      complete: function complete() {
        console.log('hideToast complete');
      }
    });
  },
  showModalFn: function showModalFn() {
    wx.showModal({
      title: 'showModal title',
      content: 'showModal content',
      showCancel: true,
      cancelText: '取消',
      cancelColor: '#000000',
      confirmText: '确定',
      confirmColor: '#576B95',
      success: function success(res) {
        if (res.confirm) {
          console.log('用户点击确定');
        } else if (res.cancel) {
          console.log('用户点击取消');
        }
      },
      fail: function fail() {
        console.log('showModal fail');
      },
      complete: function complete() {
        console.log('showModal complete');
      }
    });
  },
  showLoadingFn: function showLoadingFn() {
    wx.showLoading({
      title: '加载中...',
      mask: false,
      success: function success() {
        console.log('showLoading success');
      },
      fail: function fail() {
        console.log('showLoading fail');
      },
      complete: function complete() {
        console.log('showLoading complete');
      }
    });
  },
  hideLoadingFn: function hideLoadingFn() {
    wx.hideLoading({
      success: function success() {
        console.log('hideLoading success');
      },
      fail: function fail() {
        console.log('hideLoading fail');
      },
      complete: function complete() {
        console.log('hideLoading complete');
      }
    });
  },
  showActionSheetFn: function showActionSheetFn() {
    wx.showActionSheet({
      itemList: ['A', 'B', 'C'],
      itemColor: '#000000',
      success: function success(res) {
        console.log('showActionSheet success' + JSON.stringify(res));
      },
      fail: function fail(res) {
        console.log('showActionSheet fail' + JSON.stringify(res));
      },
      complete: function complete() {
        console.log('showActionSheet complete');
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});