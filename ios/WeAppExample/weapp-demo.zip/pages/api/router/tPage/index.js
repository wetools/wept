define("pages/api/router/tPage/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/api/router/tPage/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    optionsParams: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    console.log('详情页 onLoad:' + JSON.stringify(options));
    this.setData({
      optionsParams: JSON.stringify(options)
    });
    var pN = getCurrentPages();
    console.log('获取当前页面数：' + pN.length + ', 页面栈信息：' + JSON.stringify(pN));
  },

  tApi: function tApi() {
    wx.switchTab({
      url: '/pages/api/index'
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    console.log('详情页 onShow');
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '分享AAAA',
      path: '/pages/api/router/router',
      success: function success(res) {
        // 转发成功
        wx.showToast({
          title: "分享成功",
          icon: 'success',
          duration: 2000
        });
      },
      fail: function fail(res) {
        // 分享失败
      }
    };
  }
});
});