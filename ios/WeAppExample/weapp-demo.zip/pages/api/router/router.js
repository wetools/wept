define("pages/api/router/router.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

var app = getApp();

Page({
  data: {},
  tSwitchTab: function tSwitchTab() {
    wx.switchTab({
      url: '/pages/component/index'
    });
  },
  tRedirectTo: function tRedirectTo() {
    wx.redirectTo({
      url: 'tPage/index?type=redirectTo&date=' + new Date().getTime()
    });
  },
  tReLaunch: function tReLaunch() {
    wx.reLaunch({
      url: 'tPage/index?type=reLaunch&date=' + new Date().getTime()
    });
  },
  tNavgiateTo: function tNavgiateTo() {
    wx.navigateTo({
      url: 'tPage/index?type=navigateTo&date=' + new Date().getTime()
    });
  },
  tNavgiateBack: function tNavgiateBack() {
    var pN = getCurrentPages();
    console.log('获取当前页面数：' + pN.length + ', 页面栈信息：' + JSON.stringify(pN));
    wx.navigateBack({
      delta: 1
    });
  },

  onShareAppMessage: function onShareAppMessage() {
    console.log('1');
  }
});
});