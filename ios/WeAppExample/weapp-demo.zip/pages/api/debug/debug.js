define("pages/api/debug/debug.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/api/debug/debug.js
var logManager = wx.getLogManager();
logManager.log({ str: 'hello world' }, 'basic log', 100, [1, 2, 3]);
logManager.info({ str: 'hello world' }, 'info log', 100, [1, 2, 3]);
logManager.debug({ str: 'hello world' }, 'debug log', 100, [1, 2, 3]);
logManager.warn({ str: 'hello world' }, 'warn log', 100, [1, 2, 3]);
Page({

  /**
   * 页面的初始数据
   */
  data: {},
  openDebug: function openDebug() {
    wx.setEnableDebug({
      enableDebug: true
    });
  },
  closeDebug: function closeDebug() {
    wx.setEnableDebug({
      enableDebug: false
    });
  },
  debugC: function debugC() {
    console.debug('向调试面板中打印 debug 日志');
  },
  errorC: function errorC() {
    console.error('向调试面板中打印 error 日志');
  },
  groupC: function groupC() {
    console.group('向调试面板中打印 group 日志');
  },
  groupEndC: function groupEndC() {
    console.groupEnd('向调试面板中打印 groupEnd 日志');
  },
  infoC: function infoC() {
    console.info('向调试面板中打印 info 日志');
  },
  logC: function logC() {
    console.log('向调试面板中打印 log 日志');
  },
  warnC: function warnC() {
    console.warn('向调试面板中打印 warn 日志');
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});