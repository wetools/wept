define("pages/api/basis/basis.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,Reporter,print,URL,DOMParser,upload,preview,build,showDecryptedInfo,syncMessage,checkProxy,showSystemInfo,openVendor,openToolsLog,showRequestInfo,help,showDebugInfoTable,closeDebug,showDebugInfo,__global,WeixinJSBridge){
'use strict';

// pages/api/basis/basis.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isApi: '',
    isMethod: '',
    isParam: '',
    isOptions: '',
    isComponent: '',
    isAttribute: '',
    isOption: ''
  },

  isCanUse: function isCanUse(e) {
    var str = e.target.dataset.str;
    var res = wx.canIUse(str);
    var data = this.data;
    data[e.target.id] = res;
    this.setData(data);
  },
  base64ToArrayBuffer: function base64ToArrayBuffer() {
    var base64 = 'CxYh';
    var arrayBuffer = wx.base64ToArrayBuffer(base64);
    console.log('base64:' + base64 + ' arrayBuffer:', arrayBuffer);
  },
  arrayBufferToBase64: function arrayBufferToBase64() {
    var arrayBuffer = new Uint8Array([11, 22, 33]);
    var base64 = wx.arrayBufferToBase64(arrayBuffer);
    console.log('base64:' + base64 + ' arrayBuffer:', arrayBuffer);
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});
});