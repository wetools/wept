var __wxRoute, __wxRouteBegin, __wxAppCurrentFile__, __exportGlobal__={}, __wxAppData = {}, __wxAppCode__ = {}, __vd_version_info__ = {}, Component = function () { }, Behavior = function () { }, definePlugin = function () { }, requirePlugin = function () { }; var $gwx, __workerVendorCode__ = {}, __workersCode__ = {}, __WeixinWorker = WeixinWorker = {};
var MINI_ENV = "test";
    var __wxConfig = {"resizable":false,"debug":false,"widgets":[],"customClose":false,"workers":"","navigateToMiniProgramAppIdList":["wx76fed41ea41d26eb","wx43ac3c8667be819c","wx581d977d22ebc543"],"global":{"window":{"navigationBarBackgroundColor":"#FFFFFF","navigationBarTextStyle":"black","navigationBarTitleText":"WeChat","backgroundTextStyle":"light","enablePullDownRefresh":false}},"pages":["pages/component/index","pages/component/swipe-list/index","pages/component/scroll-view-olny/scroll-view-olny","pages/component/picker/picker","pages/api/webSocketTask/webSocketTask","pages/api/webSocket/webSocket","pages/api/router/router","pages/component/view/view","pages/api/record/record","pages/api/background-audio/background-audio","pages/api/voice/voice","pages/component/audio/audio","pages/component/cgImage/cgImage","pages/api/image/image","pages/api/file/file","pages/component/player/player","pages/component/bar/index","pages/component/pusher/pusher","pages/api/ad/ad","pages/component/ad/ad","pages/api/uploadFile/uploadFile","pages/component/map/map","pages/api/interaction/interaction","pages/api/animation/animation","pages/api/index","pages/freamwork/customNavigator/customNavigator","pages/api/requestPayment/requestPayment","pages/component/movable-view/movable-view","pages/freamwork/index","pages/api/intersection-observer/intersection-observer","pages/api/get-wxml-node-info/get-wxml-node-info","pages/api/bluetooth/bluetooth","pages/api/navigateMiniProgram/navigateMiniProgram","pages/api/downloadFile/downloadFile","pages/api/canvas/canvas","pages/api/editor/editor","pages/freamwork/pageConfig/pageConfig","pages/api/request/request","pages/api/vibrate/vibrate","pages/api/scanCode/scanCode","pages/api/gyroscope/gyroscope","pages/api/deviceMotion/deviceMotion","pages/api/compass/compass","pages/api/accelerometer/accelerometer","pages/api/phoneCall/phoneCall","pages/api/screen/screen","pages/api/network/network","pages/api/NFC/NFC","pages/api/clipboard/clipboard","pages/api/phoneContact/phoneContact","pages/api/battery/battery","pages/api/wifi/wifi","pages/api/weRun/weRun","pages/api/soterAuthentication/soterAuthentication","pages/api/address/address","pages/api/setting/setting","pages/api/authorize/authorize","pages/api/userInfo/userInfo","pages/api/accountInfo/accountInfo","pages/api/login/login","pages/api/share/share","pages/api/location/location","pages/api/camera/camera","pages/api/video/video","pages/api/map/map","pages/api/storage/storage","pages/api/keyboard/keyboard","pages/api/windowResize/windowResize","pages/api/menu/menu","pages/api/setTop/setTop","pages/api/pageScrollTop/pageScrollTop","pages/api/pullDownRefresh/pullDownRefresh","pages/api/fontFace/fontFace","pages/api/tabBar/tabBar","pages/api/background/background","pages/api/nav/nav","pages/api/timer/timer","pages/api/debug/debug","pages/api/emergencyEvents/emergencyEvents","pages/api/getLaunchOptions/getLaunchOptions","pages/api/update/update","pages/api/system-information/system-information","pages/api/basis/basis","pages/component/editor/editor","pages/component/input/input","pages/component/picker-view/picker-view","pages/component/rich-text/rich-text","pages/component/video/video","pages/component/form/form","pages/component/swiper/swiper","pages/component/open-data/open-data","pages/component/canvas/canvas","pages/component/image/image","pages/component/camera/camera","pages/component/navigator/navigator","pages/component/progress/progress","pages/component/textarea/textarea","pages/component/switch/switch","pages/component/slider/slider","pages/component/radio/radio","pages/component/label/label","pages/component/checkbox/checkbox","pages/component/text/text","pages/component/icon/icon","pages/component/scroll-view/scroll-view","pages/component/movable-area/movable-area","pages/component/cover-view/cover-view","pages/component/cover-image/cover-image","pages/component/button/button","pages/server/index","pages/api/router/tPage/index","pages/component/web-view/web-view","pages/freamwork/event/event","pages/freamwork/pageCustomConfig/pageCustomConfig","pages/api/requestNative/requestNative","pages/api/customVoice/customVoice","pages/component/input-native/input-native","pages/component/scroll-view-swiper/scroll-view-swiper"],"page":{"pages/component/index.html":{"window":{"navigationBarTitleText":" Component 1.0.5","usingComponents":{}}},"pages/component/scroll-view-olny/scroll-view-olny.html":{"window":{"enablePullDownRefresh":true,"usingComponents":{}}},"pages/component/swipe-list/index.html":{"window":{"disableScroll":true,"usingComponents":{"tab":"../../../components/tab/index","scroll":"../../../components/scroll/index"}}},"pages/api/webSocket/webSocket.html":{"window":{"usingComponents":{}}},"pages/api/webSocketTask/webSocketTask.html":{"window":{"usingComponents":{}}},"pages/component/picker/picker.html":{"window":{"usingComponents":{}}},"pages/api/record/record.html":{"window":{"navigationBarTitleText":"录音"}},"pages/api/router/router.html":{"window":{"usingComponents":{}}},"pages/component/view/view.html":{"window":{"usingComponents":{}}},"pages/api/voice/voice.html":{"window":{"navigationBarTitleText":"音频"}},"pages/api/image/image.html":{"window":{"usingComponents":{}}},"pages/component/audio/audio.html":{"window":{"usingComponents":{}}},"pages/component/cgImage/cgImage.html":{"window":{"usingComponents":{"cg-image":"../../../lib/cgImage/index"}}},"pages/api/background-audio/background-audio.html":{"window":{"navigationBarTitleText":"背景音乐"}},"pages/api/file/file.html":{"window":{"navigationBarTitleText":"文件"}},"pages/component/pusher/pusher.html":{"window":{"navigationBarTitleText":"直播"}},"pages/component/player/player.html":{"window":{"navigationBarTitleText":"直播"}},"pages/component/bar/index.html":{"window":{"usingComponents":{"ec-canvas":"../../../ec-canvas/ec-canvas"}}},"pages/component/ad/ad.html":{"window":{"usingComponents":{}}},"pages/api/uploadFile/uploadFile.html":{"window":{"usingComponents":{}}},"pages/component/map/map.html":{"window":{"usingComponents":{}}},"pages/api/interaction/interaction.html":{"window":{"usingComponents":{}}},"pages/api/animation/animation.html":{"window":{"navigationBarTitleText":"动画"}},"pages/freamwork/index.html":{"window":{"usingComponents":{},"navigationBarTitleText":"框架","disableScroll":true,"backgroundColor":"#FF0000","enablePullDownRefresh":true}},"pages/api/index.html":{"window":{"usingComponents":{}}},"pages/api/ad/ad.html":{"window":{"usingComponents":{}}},"pages/component/movable-view/movable-view.html":{"window":{"usingComponents":{}}},"pages/api/requestPayment/requestPayment.html":{"window":{"usingComponents":{}}},"pages/freamwork/customNavigator/customNavigator.html":{"window":{"navigationStyle":"custom","enablePullDownRefresh":true,"usingComponents":{"i-header":"../../../lib/customHeader/index"}}},"pages/api/intersection-observer/intersection-observer.html":{"window":{"navigationBarTitleText":"WXML节点布局相交状态"}},"pages/api/get-wxml-node-info/get-wxml-node-info.html":{"window":{"navigationBarTitleText":"获取WXML节点信息"}},"pages/api/downloadFile/downloadFile.html":{"window":{"usingComponents":{}}},"pages/api/editor/editor.html":{"window":{"navigationBarTitleText":"editor"}},"pages/api/canvas/canvas.html":{"window":{"navigationBarTitleText":"创建画布"}},"pages/api/bluetooth/bluetooth.html":{"window":{"navigationBarTitleText":"蓝牙"}},"pages/api/navigateMiniProgram/navigateMiniProgram.html":{"window":{"usingComponents":{}}},"pages/api/request/request.html":{"window":{"usingComponents":{}}},"pages/freamwork/pageConfig/pageConfig.html":{"window":{"navigationBarBackgroundColor":"#000000","navigationBarTextStyle":"white","navigationStyle":"default","backgroundColor":"#ffffff","backgroundTextStyle":"dark","backgroundColorTop":"#ffffff","backgroundColorBottom":"#ffffff","enablePullDownRefresh":false,"onReachBottomDistance":50,"pageOrientation":"portrait","disableScroll":false,"disableSwipeBack":false,"usingComponents":{}}},"pages/api/vibrate/vibrate.html":{"window":{"usingComponents":{}}},"pages/api/scanCode/scanCode.html":{"window":{"usingComponents":{}}},"pages/api/gyroscope/gyroscope.html":{"window":{"usingComponents":{}}},"pages/api/compass/compass.html":{"window":{"usingComponents":{}}},"pages/api/phoneCall/phoneCall.html":{"window":{"usingComponents":{}}},"pages/api/accelerometer/accelerometer.html":{"window":{"usingComponents":{}}},"pages/api/deviceMotion/deviceMotion.html":{"window":{"usingComponents":{}}},"pages/api/screen/screen.html":{"window":{"usingComponents":{}}},"pages/api/network/network.html":{"window":{"usingComponents":{}}},"pages/api/clipboard/clipboard.html":{"window":{"usingComponents":{}}},"pages/api/NFC/NFC.html":{"window":{"usingComponents":{}}},"pages/api/phoneContact/phoneContact.html":{"window":{"usingComponents":{}}},"pages/api/battery/battery.html":{"window":{"usingComponents":{}}},"pages/api/weRun/weRun.html":{"window":{"usingComponents":{}}},"pages/api/wifi/wifi.html":{"window":{"usingComponents":{}}},"pages/api/soterAuthentication/soterAuthentication.html":{"window":{"usingComponents":{}}},"pages/api/address/address.html":{"window":{"usingComponents":{}}},"pages/api/authorize/authorize.html":{"window":{"usingComponents":{}}},"pages/api/setting/setting.html":{"window":{"usingComponents":{}}},"pages/api/accountInfo/accountInfo.html":{"window":{"usingComponents":{}}},"pages/api/userInfo/userInfo.html":{"window":{"usingComponents":{}}},"pages/api/share/share.html":{"window":{"usingComponents":{}}},"pages/api/location/location.html":{"window":{"usingComponents":{}}},"pages/api/login/login.html":{"window":{"usingComponents":{}}},"pages/api/camera/camera.html":{"window":{"usingComponents":{}}},"pages/api/video/video.html":{"window":{"usingComponents":{}}},"pages/api/storage/storage.html":{"window":{"usingComponents":{}}},"pages/api/map/map.html":{"window":{"usingComponents":{}}},"pages/api/keyboard/keyboard.html":{"window":{"usingComponents":{}}},"pages/api/windowResize/windowResize.html":{"window":{"usingComponents":{},"pageOrientation":"auto"}},"pages/api/menu/menu.html":{"window":{"usingComponents":{}}},"pages/api/setTop/setTop.html":{"window":{"usingComponents":{}}},"pages/api/fontFace/fontFace.html":{"window":{"usingComponents":{}}},"pages/api/pageScrollTop/pageScrollTop.html":{"window":{"usingComponents":{}}},"pages/api/pullDownRefresh/pullDownRefresh.html":{"window":{"usingComponents":{},"enablePullDownRefresh":true}},"pages/api/background/background.html":{"window":{"usingComponents":{},"enablePullDownRefresh":true}},"pages/api/tabBar/tabBar.html":{"window":{"usingComponents":{}}},"pages/api/timer/timer.html":{"window":{"usingComponents":{}}},"pages/api/nav/nav.html":{"window":{"usingComponents":{}}},"pages/api/debug/debug.html":{"window":{"usingComponents":{}}},"pages/api/getLaunchOptions/getLaunchOptions.html":{"window":{"usingComponents":{}}},"pages/api/emergencyEvents/emergencyEvents.html":{"window":{"usingComponents":{}}},"pages/api/update/update.html":{"window":{"usingComponents":{}}},"pages/api/system-information/system-information.html":{"window":{"usingComponents":{}}},"pages/component/editor/editor.html":{"window":{"usingComponents":{}}},"pages/api/basis/basis.html":{"window":{"usingComponents":{}}},"pages/component/picker-view/picker-view.html":{"window":{"usingComponents":{}}},"pages/component/rich-text/rich-text.html":{"window":{"usingComponents":{}}},"pages/component/input/input.html":{"window":{"usingComponents":{}}},"pages/component/form/form.html":{"window":{"usingComponents":{}}},"pages/component/video/video.html":{"window":{"usingComponents":{}}},"pages/component/swiper/swiper.html":{"window":{"usingComponents":{}}},"pages/component/open-data/open-data.html":{"window":{"usingComponents":{}}},"pages/component/canvas/canvas.html":{"window":{"usingComponents":{}}},"pages/component/image/image.html":{"window":{"usingComponents":{}}},"pages/component/camera/camera.html":{"window":{"usingComponents":{}}},"pages/component/navigator/navigator.html":{"window":{"usingComponents":{}}},"pages/component/progress/progress.html":{"window":{"usingComponents":{}}},"pages/component/textarea/textarea.html":{"window":{"usingComponents":{}}},"pages/component/radio/radio.html":{"window":{"usingComponents":{}}},"pages/component/slider/slider.html":{"window":{"usingComponents":{}}},"pages/component/switch/switch.html":{"window":{"usingComponents":{}}},"pages/component/checkbox/checkbox.html":{"window":{"usingComponents":{}}},"pages/component/label/label.html":{"window":{"usingComponents":{}}},"pages/component/scroll-view/scroll-view.html":{"window":{"enablePullDownRefresh":true,"usingComponents":{}}},"pages/component/icon/icon.html":{"window":{"usingComponents":{}}},"pages/component/cover-view/cover-view.html":{"window":{"usingComponents":{}}},"pages/component/text/text.html":{"window":{"usingComponents":{}}},"pages/component/movable-area/movable-area.html":{"window":{"usingComponents":{}}},"pages/component/cover-image/cover-image.html":{"window":{"usingComponents":{}}},"pages/component/button/button.html":{"window":{"usingComponents":{}}},"pages/api/router/tPage/index.html":{"window":{"usingComponents":{}}},"pages/component/web-view/web-view.html":{"window":{"usingComponents":{}}},"pages/freamwork/event/event.html":{"window":{"usingComponents":{}}},"pages/server/index.html":{"window":{"usingComponents":{}}},"pages/api/requestNative/requestNative.html":{"window":{"usingComponents":{}}},"pages/freamwork/pageCustomConfig/pageCustomConfig.html":{"window":{"navigationBarBackgroundColor":"#FF0000","navigationBarTextStyle":"black","navigationBarTitleText":"自定义页面配置","navigationStyle":"default","backgroundColor":"#ffffff","backgroundTextStyle":"light","backgroundColorTop":"#ffffff","backgroundColorBottom":"#ffffff","enablePullDownRefresh":true,"onReachBottomDistance":50,"pageOrientation":"portrait","disableScroll":false,"disableSwipeBack":false,"usingComponents":{}}},"pages/api/customVoice/customVoice.html":{"window":{"usingComponents":{}}},"pages/component/scroll-view-swiper/scroll-view-swiper.html":{"window":{"enablePullDownRefresh":true,"usingComponents":{}}},"pages/component/input-native/input-native.html":{"window":{"usingComponents":{}}}},"networkTimeout":{"request":10000,"uploadFile":10000,"connectSocket":10000,"downloadFile":10000},"ext":{},"extAppid":"","mainPlugins":{},"__warning__":"","appType":0,"urlCheck":false,"wxAppInfo":{"maxRequestConcurrent":10,"maxUploadConcurrent":10,"maxDownloadConcurrent":10,"maxWorkerConcurrent":1},"env":{"USER_DATA_PATH":"cgfile://cg2f32b45b22e9fe15"},"platform":"devtools","envVersion":"develop","tabBar":{"color":"#000000","selectedColor":"#FF5548","backgroundColor":"#FFFFFF","borderStyle":"black","list":[{"pagePath":"pages/freamwork/index","iconPath":"static/image/first.png","selectedIconPath":"static/image/first_on.png","text":"框架"},{"pagePath":"pages/component/index","iconPath":"static/image/second.png","selectedIconPath":"static/image/second_on.png","text":"组件"},{"pagePath":"pages/api/index","iconPath":"static/image/third.png","selectedIconPath":"static/image/third_on.png","text":"接口"},{"pagePath":"pages/api/tabBar/tabBar","iconPath":"static/image/fourth.png","selectedIconPath":"static/image/fourth_on.png","text":"tabBar API"}]},"permission":{"scope.userLocation":{"desc":"吴林峰看这里"}},"requiredBackgroundModes":["audio","location"],"usingComponents":{"c-icon":"../lib/icon"},"sitemapLocation":"sitemap.json","entryPagePath":"pages/component/index.html","accountInfo":{"appId":"cg2f32b45b22e9fe15","icon":"","nickname":""},"libVersion":"2.9.4","appLaunchInfo":{"path":"pages/component/index","query":{},"scene":1001}};
    var __devtoolsConfig={"urlCheck":false,"setting":{}};
    /*v0.5vv_20190312_syb_scopedata*/global.__wcc_version__='v0.5vv_20190312_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
function gz$gwx_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_1)return __WXML_GLOBAL__.ops_cached.$gwx_1
__WXML_GLOBAL__.ops_cached.$gwx_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'change'])
Z([3,'touchend'])
Z([3,'scroll'])
Z([3,'vertical'])
Z([[2,'>='],[[7],[3,'refreshStatus']],[1,3]])
Z([a,[3,'height: calc(100vh + 40rpx + '],[[7],[3,'refreshSize']],[3,'rpx)']])
Z([[7],[3,'move']])
Z(z[2])
Z([3,'more'])
Z([3,'scroll__view'])
Z([[7],[3,'enableBackToTop']])
Z([a,[1,80],[3,'rpx']])
Z([[7],[3,'scrollTop']])
Z([[2,'=='],[[7],[3,'refreshStatus']],[1,1]])
Z([a,[3,'padding-bottom: '],[[7],[3,'bottomSize']],[3,'rpx;padding-top: '],[[7],[3,'topSize']],[3,'rpx;']])
Z([3,'scroll__loading'])
Z([[2,'||'],[[2,'=='],[[7],[3,'refreshStatus']],[1,1]],[[2,'=='],[[7],[3,'refreshStatus']],[1,2]]])
Z([[2,'=='],[[7],[3,'refreshStatus']],[1,3]])
Z([[2,'&&'],[[2,'==='],[[7],[3,'listCount']],[1,0]],[[7],[3,'emptyShow']]])
Z([[2,'&&'],[[2,'!=='],[[7],[3,'listCount']],[1,0]],[[7],[3,'overOnePage']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_1);return __WXML_GLOBAL__.ops_cached.$gwx_1
}
function gz$gwx_2(){
if( __WXML_GLOBAL__.ops_cached.$gwx_2)return __WXML_GLOBAL__.ops_cached.$gwx_2
__WXML_GLOBAL__.ops_cached.$gwx_2=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_2);return __WXML_GLOBAL__.ops_cached.$gwx_2
}
function gz$gwx_3(){
if( __WXML_GLOBAL__.ops_cached.$gwx_3)return __WXML_GLOBAL__.ops_cached.$gwx_3
__WXML_GLOBAL__.ops_cached.$gwx_3=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_3);return __WXML_GLOBAL__.ops_cached.$gwx_3
}
function gz$gwx_4(){
if( __WXML_GLOBAL__.ops_cached.$gwx_4)return __WXML_GLOBAL__.ops_cached.$gwx_4
__WXML_GLOBAL__.ops_cached.$gwx_4=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_4);return __WXML_GLOBAL__.ops_cached.$gwx_4
}
function gz$gwx_5(){
if( __WXML_GLOBAL__.ops_cached.$gwx_5)return __WXML_GLOBAL__.ops_cached.$gwx_5
__WXML_GLOBAL__.ops_cached.$gwx_5=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'nav-btn'])
Z([3,'toBack'])
Z([3,'#FFFFFF'])
Z([3,'24'])
Z([3,'return'])
Z([3,'toHome'])
Z([3,'#FFBF00'])
Z(z[3])
Z([3,'homepage'])
})(__WXML_GLOBAL__.ops_cached.$gwx_5);return __WXML_GLOBAL__.ops_cached.$gwx_5
}
function gz$gwx_6(){
if( __WXML_GLOBAL__.ops_cached.$gwx_6)return __WXML_GLOBAL__.ops_cached.$gwx_6
__WXML_GLOBAL__.ops_cached.$gwx_6=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_6);return __WXML_GLOBAL__.ops_cached.$gwx_6
}
function gz$gwx_7(){
if( __WXML_GLOBAL__.ops_cached.$gwx_7)return __WXML_GLOBAL__.ops_cached.$gwx_7
__WXML_GLOBAL__.ops_cached.$gwx_7=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'getHCEStateJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_7);return __WXML_GLOBAL__.ops_cached.$gwx_7
}
function gz$gwx_8(){
if( __WXML_GLOBAL__.ops_cached.$gwx_8)return __WXML_GLOBAL__.ops_cached.$gwx_8
__WXML_GLOBAL__.ops_cached.$gwx_8=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'startAccelerometerJsonStr']])
Z([[7],[3,'stopAccelerometerJsonStr']])
Z([[7],[3,'onAccelerometerChangeJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_8);return __WXML_GLOBAL__.ops_cached.$gwx_8
}
function gz$gwx_9(){
if( __WXML_GLOBAL__.ops_cached.$gwx_9)return __WXML_GLOBAL__.ops_cached.$gwx_9
__WXML_GLOBAL__.ops_cached.$gwx_9=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'getAccountInfoSyncJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_9);return __WXML_GLOBAL__.ops_cached.$gwx_9
}
function gz$gwx_10(){
if( __WXML_GLOBAL__.ops_cached.$gwx_10)return __WXML_GLOBAL__.ops_cached.$gwx_10
__WXML_GLOBAL__.ops_cached.$gwx_10=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_10);return __WXML_GLOBAL__.ops_cached.$gwx_10
}
function gz$gwx_11(){
if( __WXML_GLOBAL__.ops_cached.$gwx_11)return __WXML_GLOBAL__.ops_cached.$gwx_11
__WXML_GLOBAL__.ops_cached.$gwx_11=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'chooseAddressJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_11);return __WXML_GLOBAL__.ops_cached.$gwx_11
}
function gz$gwx_12(){
if( __WXML_GLOBAL__.ops_cached.$gwx_12)return __WXML_GLOBAL__.ops_cached.$gwx_12
__WXML_GLOBAL__.ops_cached.$gwx_12=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_12);return __WXML_GLOBAL__.ops_cached.$gwx_12
}
function gz$gwx_13(){
if( __WXML_GLOBAL__.ops_cached.$gwx_13)return __WXML_GLOBAL__.ops_cached.$gwx_13
__WXML_GLOBAL__.ops_cached.$gwx_13=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'authorizeJsonStr']])
Z([[7],[3,'userLocationJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_13);return __WXML_GLOBAL__.ops_cached.$gwx_13
}
function gz$gwx_14(){
if( __WXML_GLOBAL__.ops_cached.$gwx_14)return __WXML_GLOBAL__.ops_cached.$gwx_14
__WXML_GLOBAL__.ops_cached.$gwx_14=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'playBackgroundAudioJsonStr']])
Z([[7],[3,'pauseBackgroundAudioJsonStr']])
Z([[7],[3,'stopBackgroundAudioJsonStr']])
Z([[7],[3,'seekBackgroundAudioJsonStr']])
Z([[7],[3,'getBackgroundAudioPlayerStateJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_14);return __WXML_GLOBAL__.ops_cached.$gwx_14
}
function gz$gwx_15(){
if( __WXML_GLOBAL__.ops_cached.$gwx_15)return __WXML_GLOBAL__.ops_cached.$gwx_15
__WXML_GLOBAL__.ops_cached.$gwx_15=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_15);return __WXML_GLOBAL__.ops_cached.$gwx_15
}
function gz$gwx_16(){
if( __WXML_GLOBAL__.ops_cached.$gwx_16)return __WXML_GLOBAL__.ops_cached.$gwx_16
__WXML_GLOBAL__.ops_cached.$gwx_16=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'base64ImgUrl']])
})(__WXML_GLOBAL__.ops_cached.$gwx_16);return __WXML_GLOBAL__.ops_cached.$gwx_16
}
function gz$gwx_17(){
if( __WXML_GLOBAL__.ops_cached.$gwx_17)return __WXML_GLOBAL__.ops_cached.$gwx_17
__WXML_GLOBAL__.ops_cached.$gwx_17=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'getBatteryInfoJsonStr']])
Z([[7],[3,'getBatteryInfoSyncJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_17);return __WXML_GLOBAL__.ops_cached.$gwx_17
}
function gz$gwx_18(){
if( __WXML_GLOBAL__.ops_cached.$gwx_18)return __WXML_GLOBAL__.ops_cached.$gwx_18
__WXML_GLOBAL__.ops_cached.$gwx_18=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'connected']])
Z([[7],[3,'canWrite']])
})(__WXML_GLOBAL__.ops_cached.$gwx_18);return __WXML_GLOBAL__.ops_cached.$gwx_18
}
function gz$gwx_19(){
if( __WXML_GLOBAL__.ops_cached.$gwx_19)return __WXML_GLOBAL__.ops_cached.$gwx_19
__WXML_GLOBAL__.ops_cached.$gwx_19=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'is-item'])
Z([[7],[3,'takePhotoJsonStr']])
Z([[7],[3,'takePhotoTempFilePath']])
Z([[7],[3,'startRecordJsonStr']])
Z(z[1])
Z([[7],[3,'stopRecordJsonStr']])
Z([[7],[3,'recordTempFilePath']])
Z([[7],[3,'startJsonStr']])
Z([[7],[3,'stopJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_19);return __WXML_GLOBAL__.ops_cached.$gwx_19
}
function gz$gwx_20(){
if( __WXML_GLOBAL__.ops_cached.$gwx_20)return __WXML_GLOBAL__.ops_cached.$gwx_20
__WXML_GLOBAL__.ops_cached.$gwx_20=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_20);return __WXML_GLOBAL__.ops_cached.$gwx_20
}
function gz$gwx_21(){
if( __WXML_GLOBAL__.ops_cached.$gwx_21)return __WXML_GLOBAL__.ops_cached.$gwx_21
__WXML_GLOBAL__.ops_cached.$gwx_21=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'setClipboardDataJsonStr']])
Z([[7],[3,'getClipboardDataJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_21);return __WXML_GLOBAL__.ops_cached.$gwx_21
}
function gz$gwx_22(){
if( __WXML_GLOBAL__.ops_cached.$gwx_22)return __WXML_GLOBAL__.ops_cached.$gwx_22
__WXML_GLOBAL__.ops_cached.$gwx_22=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'startCompassJsonStr']])
Z([[7],[3,'stopCompassJsonStr']])
Z([[7],[3,'onCompassChangeJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_22);return __WXML_GLOBAL__.ops_cached.$gwx_22
}
function gz$gwx_23(){
if( __WXML_GLOBAL__.ops_cached.$gwx_23)return __WXML_GLOBAL__.ops_cached.$gwx_23
__WXML_GLOBAL__.ops_cached.$gwx_23=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_23);return __WXML_GLOBAL__.ops_cached.$gwx_23
}
function gz$gwx_24(){
if( __WXML_GLOBAL__.ops_cached.$gwx_24)return __WXML_GLOBAL__.ops_cached.$gwx_24
__WXML_GLOBAL__.ops_cached.$gwx_24=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_24);return __WXML_GLOBAL__.ops_cached.$gwx_24
}
function gz$gwx_25(){
if( __WXML_GLOBAL__.ops_cached.$gwx_25)return __WXML_GLOBAL__.ops_cached.$gwx_25
__WXML_GLOBAL__.ops_cached.$gwx_25=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'startDeviceMotionListeningJsonStr']])
Z([[7],[3,'stopDeviceMotionListeningJsonStr']])
Z([[7],[3,'onDeviceMotionChangeJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_25);return __WXML_GLOBAL__.ops_cached.$gwx_25
}
function gz$gwx_26(){
if( __WXML_GLOBAL__.ops_cached.$gwx_26)return __WXML_GLOBAL__.ops_cached.$gwx_26
__WXML_GLOBAL__.ops_cached.$gwx_26=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'is-item'])
Z([[7],[3,'downloadFileJsonStr']])
Z([[7],[3,'imageSrc']])
Z(z[2])
})(__WXML_GLOBAL__.ops_cached.$gwx_26);return __WXML_GLOBAL__.ops_cached.$gwx_26
}
function gz$gwx_27(){
if( __WXML_GLOBAL__.ops_cached.$gwx_27)return __WXML_GLOBAL__.ops_cached.$gwx_27
__WXML_GLOBAL__.ops_cached.$gwx_27=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_27);return __WXML_GLOBAL__.ops_cached.$gwx_27
}
function gz$gwx_28(){
if( __WXML_GLOBAL__.ops_cached.$gwx_28)return __WXML_GLOBAL__.ops_cached.$gwx_28
__WXML_GLOBAL__.ops_cached.$gwx_28=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_28);return __WXML_GLOBAL__.ops_cached.$gwx_28
}
function gz$gwx_29(){
if( __WXML_GLOBAL__.ops_cached.$gwx_29)return __WXML_GLOBAL__.ops_cached.$gwx_29
__WXML_GLOBAL__.ops_cached.$gwx_29=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'chooseJsonStr']])
Z([[7],[3,'getFileInfoJsonStr']])
Z([[7],[3,'saveFileJsonStr']])
Z([[7],[3,'removeSavedFileJsonStr']])
Z([[7],[3,'getSavedFileListJsonStr']])
Z([[7],[3,'getSavedFileInfoJsonStr']])
Z([[7],[3,'openDocumentJsonStr']])
Z([[7],[3,'getFileSystemInfoJsonStr']])
Z([[7],[3,'getSavedSystemFileListJsonStr']])
Z([[7],[3,'saveSystemFileJsonStr']])
Z([[7],[3,'removeSavedSystemFileJsonStr']])
Z([[7],[3,'mkdirJsonStr']])
Z([[7],[3,'readdirJsonStr']])
Z([[7],[3,'rmdirJsonStr']])
Z([[7],[3,'accessJsonStr']])
Z([[7],[3,'copyFileJsonStr']])
Z([[7],[3,'unlinkJsonStr']])
Z([[7],[3,'renameJsonStr']])
Z([[7],[3,'appendFileJsonStr']])
Z([[7],[3,'writeFileJsonStr']])
Z([[7],[3,'readFileJsonStr']])
Z([[7],[3,'unzipJsonStr']])
Z([[7],[3,'statJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_29);return __WXML_GLOBAL__.ops_cached.$gwx_29
}
function gz$gwx_30(){
if( __WXML_GLOBAL__.ops_cached.$gwx_30)return __WXML_GLOBAL__.ops_cached.$gwx_30
__WXML_GLOBAL__.ops_cached.$gwx_30=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_30);return __WXML_GLOBAL__.ops_cached.$gwx_30
}
function gz$gwx_31(){
if( __WXML_GLOBAL__.ops_cached.$gwx_31)return __WXML_GLOBAL__.ops_cached.$gwx_31
__WXML_GLOBAL__.ops_cached.$gwx_31=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_31);return __WXML_GLOBAL__.ops_cached.$gwx_31
}
function gz$gwx_32(){
if( __WXML_GLOBAL__.ops_cached.$gwx_32)return __WXML_GLOBAL__.ops_cached.$gwx_32
__WXML_GLOBAL__.ops_cached.$gwx_32=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_32);return __WXML_GLOBAL__.ops_cached.$gwx_32
}
function gz$gwx_33(){
if( __WXML_GLOBAL__.ops_cached.$gwx_33)return __WXML_GLOBAL__.ops_cached.$gwx_33
__WXML_GLOBAL__.ops_cached.$gwx_33=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'startGyroscopeJsonStr']])
Z([[7],[3,'stopGyroscopeJsonStr']])
Z([[7],[3,'onGyroscopeChangeJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_33);return __WXML_GLOBAL__.ops_cached.$gwx_33
}
function gz$gwx_34(){
if( __WXML_GLOBAL__.ops_cached.$gwx_34)return __WXML_GLOBAL__.ops_cached.$gwx_34
__WXML_GLOBAL__.ops_cached.$gwx_34=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'saveImageToPhotosAlbumJsonStr']])
Z([[7],[3,'getImageInfoJsonStr']])
Z([3,'is-item'])
Z([[7],[3,'compressImageJsonStr']])
Z([[7],[3,'compressImageTempFilePath']])
Z([[7],[3,'chooseMessageFileJsonStr']])
Z([[7],[3,'chooseImageJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_34);return __WXML_GLOBAL__.ops_cached.$gwx_34
}
function gz$gwx_35(){
if( __WXML_GLOBAL__.ops_cached.$gwx_35)return __WXML_GLOBAL__.ops_cached.$gwx_35
__WXML_GLOBAL__.ops_cached.$gwx_35=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_35);return __WXML_GLOBAL__.ops_cached.$gwx_35
}
function gz$gwx_36(){
if( __WXML_GLOBAL__.ops_cached.$gwx_36)return __WXML_GLOBAL__.ops_cached.$gwx_36
__WXML_GLOBAL__.ops_cached.$gwx_36=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_36);return __WXML_GLOBAL__.ops_cached.$gwx_36
}
function gz$gwx_37(){
if( __WXML_GLOBAL__.ops_cached.$gwx_37)return __WXML_GLOBAL__.ops_cached.$gwx_37
__WXML_GLOBAL__.ops_cached.$gwx_37=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_37);return __WXML_GLOBAL__.ops_cached.$gwx_37
}
function gz$gwx_38(){
if( __WXML_GLOBAL__.ops_cached.$gwx_38)return __WXML_GLOBAL__.ops_cached.$gwx_38
__WXML_GLOBAL__.ops_cached.$gwx_38=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_38);return __WXML_GLOBAL__.ops_cached.$gwx_38
}
function gz$gwx_39(){
if( __WXML_GLOBAL__.ops_cached.$gwx_39)return __WXML_GLOBAL__.ops_cached.$gwx_39
__WXML_GLOBAL__.ops_cached.$gwx_39=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'chooseLocationJsonStr']])
Z([[7],[3,'getLocationJsonStr']])
Z([[7],[3,'openLocationJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_39);return __WXML_GLOBAL__.ops_cached.$gwx_39
}
function gz$gwx_40(){
if( __WXML_GLOBAL__.ops_cached.$gwx_40)return __WXML_GLOBAL__.ops_cached.$gwx_40
__WXML_GLOBAL__.ops_cached.$gwx_40=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'loginJsonStr']])
Z([3,'is-item'])
Z([[7],[3,'getTokenJsonStr']])
Z([[7],[3,'getToken2JsonStr']])
Z([[7],[3,'checkSessionJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_40);return __WXML_GLOBAL__.ops_cached.$gwx_40
}
function gz$gwx_41(){
if( __WXML_GLOBAL__.ops_cached.$gwx_41)return __WXML_GLOBAL__.ops_cached.$gwx_41
__WXML_GLOBAL__.ops_cached.$gwx_41=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'getCenterLocationJsonStr']])
Z([[7],[3,'getRegionJsonStr']])
Z([[7],[3,'getScaleJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_41);return __WXML_GLOBAL__.ops_cached.$gwx_41
}
function gz$gwx_42(){
if( __WXML_GLOBAL__.ops_cached.$gwx_42)return __WXML_GLOBAL__.ops_cached.$gwx_42
__WXML_GLOBAL__.ops_cached.$gwx_42=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_42);return __WXML_GLOBAL__.ops_cached.$gwx_42
}
function gz$gwx_43(){
if( __WXML_GLOBAL__.ops_cached.$gwx_43)return __WXML_GLOBAL__.ops_cached.$gwx_43
__WXML_GLOBAL__.ops_cached.$gwx_43=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_43);return __WXML_GLOBAL__.ops_cached.$gwx_43
}
function gz$gwx_44(){
if( __WXML_GLOBAL__.ops_cached.$gwx_44)return __WXML_GLOBAL__.ops_cached.$gwx_44
__WXML_GLOBAL__.ops_cached.$gwx_44=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_44);return __WXML_GLOBAL__.ops_cached.$gwx_44
}
function gz$gwx_45(){
if( __WXML_GLOBAL__.ops_cached.$gwx_45)return __WXML_GLOBAL__.ops_cached.$gwx_45
__WXML_GLOBAL__.ops_cached.$gwx_45=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_45);return __WXML_GLOBAL__.ops_cached.$gwx_45
}
function gz$gwx_46(){
if( __WXML_GLOBAL__.ops_cached.$gwx_46)return __WXML_GLOBAL__.ops_cached.$gwx_46
__WXML_GLOBAL__.ops_cached.$gwx_46=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_46);return __WXML_GLOBAL__.ops_cached.$gwx_46
}
function gz$gwx_47(){
if( __WXML_GLOBAL__.ops_cached.$gwx_47)return __WXML_GLOBAL__.ops_cached.$gwx_47
__WXML_GLOBAL__.ops_cached.$gwx_47=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'makePhoneCallJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_47);return __WXML_GLOBAL__.ops_cached.$gwx_47
}
function gz$gwx_48(){
if( __WXML_GLOBAL__.ops_cached.$gwx_48)return __WXML_GLOBAL__.ops_cached.$gwx_48
__WXML_GLOBAL__.ops_cached.$gwx_48=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'chooseContactJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_48);return __WXML_GLOBAL__.ops_cached.$gwx_48
}
function gz$gwx_49(){
if( __WXML_GLOBAL__.ops_cached.$gwx_49)return __WXML_GLOBAL__.ops_cached.$gwx_49
__WXML_GLOBAL__.ops_cached.$gwx_49=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_49);return __WXML_GLOBAL__.ops_cached.$gwx_49
}
function gz$gwx_50(){
if( __WXML_GLOBAL__.ops_cached.$gwx_50)return __WXML_GLOBAL__.ops_cached.$gwx_50
__WXML_GLOBAL__.ops_cached.$gwx_50=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'tempFilePathRecordManager']])
Z([[7],[3,'startRecordJsonStr']])
Z([[7],[3,'stopRecordJsonStr']])
Z([[7],[3,'tempFilePathRecord']])
})(__WXML_GLOBAL__.ops_cached.$gwx_50);return __WXML_GLOBAL__.ops_cached.$gwx_50
}
function gz$gwx_51(){
if( __WXML_GLOBAL__.ops_cached.$gwx_51)return __WXML_GLOBAL__.ops_cached.$gwx_51
__WXML_GLOBAL__.ops_cached.$gwx_51=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'requestJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_51);return __WXML_GLOBAL__.ops_cached.$gwx_51
}
function gz$gwx_52(){
if( __WXML_GLOBAL__.ops_cached.$gwx_52)return __WXML_GLOBAL__.ops_cached.$gwx_52
__WXML_GLOBAL__.ops_cached.$gwx_52=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'requestNativeJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_52);return __WXML_GLOBAL__.ops_cached.$gwx_52
}
function gz$gwx_53(){
if( __WXML_GLOBAL__.ops_cached.$gwx_53)return __WXML_GLOBAL__.ops_cached.$gwx_53
__WXML_GLOBAL__.ops_cached.$gwx_53=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'requestPaymentJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_53);return __WXML_GLOBAL__.ops_cached.$gwx_53
}
function gz$gwx_54(){
if( __WXML_GLOBAL__.ops_cached.$gwx_54)return __WXML_GLOBAL__.ops_cached.$gwx_54
__WXML_GLOBAL__.ops_cached.$gwx_54=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_54);return __WXML_GLOBAL__.ops_cached.$gwx_54
}
function gz$gwx_55(){
if( __WXML_GLOBAL__.ops_cached.$gwx_55)return __WXML_GLOBAL__.ops_cached.$gwx_55
__WXML_GLOBAL__.ops_cached.$gwx_55=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'optionsParams']])
Z([[7],[3,'pageLength']])
})(__WXML_GLOBAL__.ops_cached.$gwx_55);return __WXML_GLOBAL__.ops_cached.$gwx_55
}
function gz$gwx_56(){
if( __WXML_GLOBAL__.ops_cached.$gwx_56)return __WXML_GLOBAL__.ops_cached.$gwx_56
__WXML_GLOBAL__.ops_cached.$gwx_56=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'scanCodeJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_56);return __WXML_GLOBAL__.ops_cached.$gwx_56
}
function gz$gwx_57(){
if( __WXML_GLOBAL__.ops_cached.$gwx_57)return __WXML_GLOBAL__.ops_cached.$gwx_57
__WXML_GLOBAL__.ops_cached.$gwx_57=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'getScreenBrightnessJsonStr']])
Z([[7],[3,'setScreenBrightnessJsonStr']])
Z([[7],[3,'setKeepScreenOnJsonStr']])
Z([[7],[3,'onUserCaptureScreenJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_57);return __WXML_GLOBAL__.ops_cached.$gwx_57
}
function gz$gwx_58(){
if( __WXML_GLOBAL__.ops_cached.$gwx_58)return __WXML_GLOBAL__.ops_cached.$gwx_58
__WXML_GLOBAL__.ops_cached.$gwx_58=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_58);return __WXML_GLOBAL__.ops_cached.$gwx_58
}
function gz$gwx_59(){
if( __WXML_GLOBAL__.ops_cached.$gwx_59)return __WXML_GLOBAL__.ops_cached.$gwx_59
__WXML_GLOBAL__.ops_cached.$gwx_59=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'openSettingJsonStr']])
Z([[7],[3,'getSettingJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_59);return __WXML_GLOBAL__.ops_cached.$gwx_59
}
function gz$gwx_60(){
if( __WXML_GLOBAL__.ops_cached.$gwx_60)return __WXML_GLOBAL__.ops_cached.$gwx_60
__WXML_GLOBAL__.ops_cached.$gwx_60=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'updateShareMenuJsonStr']])
Z([[7],[3,'getShareInfoJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_60);return __WXML_GLOBAL__.ops_cached.$gwx_60
}
function gz$gwx_61(){
if( __WXML_GLOBAL__.ops_cached.$gwx_61)return __WXML_GLOBAL__.ops_cached.$gwx_61
__WXML_GLOBAL__.ops_cached.$gwx_61=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'startSoterAuthenticationJsonStr']])
Z([[7],[3,'checkIsSupportSoterAuthenticationJsonStr']])
Z([[7],[3,'checkIsSoterEnrolledInDeviceJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_61);return __WXML_GLOBAL__.ops_cached.$gwx_61
}
function gz$gwx_62(){
if( __WXML_GLOBAL__.ops_cached.$gwx_62)return __WXML_GLOBAL__.ops_cached.$gwx_62
__WXML_GLOBAL__.ops_cached.$gwx_62=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'storageValue']])
Z([[7],[3,'storageSyncValue']])
})(__WXML_GLOBAL__.ops_cached.$gwx_62);return __WXML_GLOBAL__.ops_cached.$gwx_62
}
function gz$gwx_63(){
if( __WXML_GLOBAL__.ops_cached.$gwx_63)return __WXML_GLOBAL__.ops_cached.$gwx_63
__WXML_GLOBAL__.ops_cached.$gwx_63=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'getSystemInfoJsonStr']])
Z([[7],[3,'getSystemInfoSyncJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_63);return __WXML_GLOBAL__.ops_cached.$gwx_63
}
function gz$gwx_64(){
if( __WXML_GLOBAL__.ops_cached.$gwx_64)return __WXML_GLOBAL__.ops_cached.$gwx_64
__WXML_GLOBAL__.ops_cached.$gwx_64=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_64);return __WXML_GLOBAL__.ops_cached.$gwx_64
}
function gz$gwx_65(){
if( __WXML_GLOBAL__.ops_cached.$gwx_65)return __WXML_GLOBAL__.ops_cached.$gwx_65
__WXML_GLOBAL__.ops_cached.$gwx_65=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_65);return __WXML_GLOBAL__.ops_cached.$gwx_65
}
function gz$gwx_66(){
if( __WXML_GLOBAL__.ops_cached.$gwx_66)return __WXML_GLOBAL__.ops_cached.$gwx_66
__WXML_GLOBAL__.ops_cached.$gwx_66=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_66);return __WXML_GLOBAL__.ops_cached.$gwx_66
}
function gz$gwx_67(){
if( __WXML_GLOBAL__.ops_cached.$gwx_67)return __WXML_GLOBAL__.ops_cached.$gwx_67
__WXML_GLOBAL__.ops_cached.$gwx_67=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'is-item'])
Z([[7],[3,'uploadFileJsonStr']])
Z([[7],[3,'imageSrc']])
Z(z[3])
Z(z[1])
Z([[7],[3,'cgUploadFileJsonStr']])
Z([[7],[3,'cgImageSrc']])
Z(z[7])
Z(z[1])
Z([[7],[3,'cgALUploadFileJsonStr']])
Z([[7],[3,'cgALImageSrc']])
Z(z[11])
Z(z[1])
Z([[7],[3,'cgUploadMoreFileJsonStr']])
Z(z[7])
Z(z[7])
Z(z[1])
Z([[7],[3,'failcgUploadFileJsonStr']])
Z([[7],[3,'failcgImageSrc']])
Z(z[19])
})(__WXML_GLOBAL__.ops_cached.$gwx_67);return __WXML_GLOBAL__.ops_cached.$gwx_67
}
function gz$gwx_68(){
if( __WXML_GLOBAL__.ops_cached.$gwx_68)return __WXML_GLOBAL__.ops_cached.$gwx_68
__WXML_GLOBAL__.ops_cached.$gwx_68=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'getUserInfoJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_68);return __WXML_GLOBAL__.ops_cached.$gwx_68
}
function gz$gwx_69(){
if( __WXML_GLOBAL__.ops_cached.$gwx_69)return __WXML_GLOBAL__.ops_cached.$gwx_69
__WXML_GLOBAL__.ops_cached.$gwx_69=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'vibrateShortJsonStr']])
Z([[7],[3,'vibrateLongJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_69);return __WXML_GLOBAL__.ops_cached.$gwx_69
}
function gz$gwx_70(){
if( __WXML_GLOBAL__.ops_cached.$gwx_70)return __WXML_GLOBAL__.ops_cached.$gwx_70
__WXML_GLOBAL__.ops_cached.$gwx_70=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'is-item'])
Z([[7],[3,'chooseVideoJsonStr']])
Z([[7],[3,'chooseVideoTempFilePath']])
Z([[7],[3,'saveVideoToPhotosAlbumJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_70);return __WXML_GLOBAL__.ops_cached.$gwx_70
}
function gz$gwx_71(){
if( __WXML_GLOBAL__.ops_cached.$gwx_71)return __WXML_GLOBAL__.ops_cached.$gwx_71
__WXML_GLOBAL__.ops_cached.$gwx_71=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'getAvailableAudioSourcesJsonStr']])
Z([[7],[3,'setInnerAudioOptionJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_71);return __WXML_GLOBAL__.ops_cached.$gwx_71
}
function gz$gwx_72(){
if( __WXML_GLOBAL__.ops_cached.$gwx_72)return __WXML_GLOBAL__.ops_cached.$gwx_72
__WXML_GLOBAL__.ops_cached.$gwx_72=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'getWeRunDataJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_72);return __WXML_GLOBAL__.ops_cached.$gwx_72
}
function gz$gwx_73(){
if( __WXML_GLOBAL__.ops_cached.$gwx_73)return __WXML_GLOBAL__.ops_cached.$gwx_73
__WXML_GLOBAL__.ops_cached.$gwx_73=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'connectSocketJsonStr']])
Z([[7],[3,'sendSocketMessageJsonStr']])
Z([[7],[3,'closeSocketJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_73);return __WXML_GLOBAL__.ops_cached.$gwx_73
}
function gz$gwx_74(){
if( __WXML_GLOBAL__.ops_cached.$gwx_74)return __WXML_GLOBAL__.ops_cached.$gwx_74
__WXML_GLOBAL__.ops_cached.$gwx_74=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'connectSocketJsonStr']])
Z([[7],[3,'sendJsonStr']])
Z([[7],[3,'closeJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_74);return __WXML_GLOBAL__.ops_cached.$gwx_74
}
function gz$gwx_75(){
if( __WXML_GLOBAL__.ops_cached.$gwx_75)return __WXML_GLOBAL__.ops_cached.$gwx_75
__WXML_GLOBAL__.ops_cached.$gwx_75=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'startWifiJsonStr']])
Z([[7],[3,'stopWifiJsonStr']])
Z([[7],[3,'onGetWifiListJsonStr']])
})(__WXML_GLOBAL__.ops_cached.$gwx_75);return __WXML_GLOBAL__.ops_cached.$gwx_75
}
function gz$gwx_76(){
if( __WXML_GLOBAL__.ops_cached.$gwx_76)return __WXML_GLOBAL__.ops_cached.$gwx_76
__WXML_GLOBAL__.ops_cached.$gwx_76=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_76);return __WXML_GLOBAL__.ops_cached.$gwx_76
}
function gz$gwx_77(){
if( __WXML_GLOBAL__.ops_cached.$gwx_77)return __WXML_GLOBAL__.ops_cached.$gwx_77
__WXML_GLOBAL__.ops_cached.$gwx_77=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'head'])
Z([3,'page-head'])
Z([[7],[3,'desc']])
Z([[7],[3,'tip']])
})(__WXML_GLOBAL__.ops_cached.$gwx_77);return __WXML_GLOBAL__.ops_cached.$gwx_77
}
function gz$gwx_78(){
if( __WXML_GLOBAL__.ops_cached.$gwx_78)return __WXML_GLOBAL__.ops_cached.$gwx_78
__WXML_GLOBAL__.ops_cached.$gwx_78=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'noSupport'])
Z([[7],[3,'property']])
Z([[7],[3,'event']])
})(__WXML_GLOBAL__.ops_cached.$gwx_78);return __WXML_GLOBAL__.ops_cached.$gwx_78
}
function gz$gwx_79(){
if( __WXML_GLOBAL__.ops_cached.$gwx_79)return __WXML_GLOBAL__.ops_cached.$gwx_79
__WXML_GLOBAL__.ops_cached.$gwx_79=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_79);return __WXML_GLOBAL__.ops_cached.$gwx_79
}
function gz$gwx_80(){
if( __WXML_GLOBAL__.ops_cached.$gwx_80)return __WXML_GLOBAL__.ops_cached.$gwx_80
__WXML_GLOBAL__.ops_cached.$gwx_80=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'audio']],[[8],'desc',[1,'音频。1.6.0版本开始，该组件不再维护。建议使用能力更强的 wx.createInnerAudioContext 接口']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_80);return __WXML_GLOBAL__.ops_cached.$gwx_80
}
function gz$gwx_81(){
if( __WXML_GLOBAL__.ops_cached.$gwx_81)return __WXML_GLOBAL__.ops_cached.$gwx_81
__WXML_GLOBAL__.ops_cached.$gwx_81=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'mychart-bar'])
Z([[7],[3,'ec']])
Z([3,'mychart-dom-bar'])
})(__WXML_GLOBAL__.ops_cached.$gwx_81);return __WXML_GLOBAL__.ops_cached.$gwx_81
}
function gz$gwx_82(){
if( __WXML_GLOBAL__.ops_cached.$gwx_82)return __WXML_GLOBAL__.ops_cached.$gwx_82
__WXML_GLOBAL__.ops_cached.$gwx_82=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_82);return __WXML_GLOBAL__.ops_cached.$gwx_82
}
function gz$gwx_83(){
if( __WXML_GLOBAL__.ops_cached.$gwx_83)return __WXML_GLOBAL__.ops_cached.$gwx_83
__WXML_GLOBAL__.ops_cached.$gwx_83=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'camera']],[[8],'desc',[1,'系统相机。扫码二维码功能，需升级微信客户端至6.7.3。需要用户授权 scope.camera。相关api：wx.createCameraContext']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_83);return __WXML_GLOBAL__.ops_cached.$gwx_83
}
function gz$gwx_84(){
if( __WXML_GLOBAL__.ops_cached.$gwx_84)return __WXML_GLOBAL__.ops_cached.$gwx_84
__WXML_GLOBAL__.ops_cached.$gwx_84=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'canvas']],[[8],'desc',[1,'画布。相关api：wx.createCanvasContext。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_84);return __WXML_GLOBAL__.ops_cached.$gwx_84
}
function gz$gwx_85(){
if( __WXML_GLOBAL__.ops_cached.$gwx_85)return __WXML_GLOBAL__.ops_cached.$gwx_85
__WXML_GLOBAL__.ops_cached.$gwx_85=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'imgList'])
Z([3,'img'])
Z([3,''])
Z([[7],[3,'src']])
Z([3,'imgload'])
Z([1,true])
Z([3,'../../static/image/1.jpg'])
Z(z[4])
Z(z[5])
Z([3,'/static/image/1.jpg'])
Z(z[5])
Z([3,'http://dyfsserver.oss-cn-shenzhen.aliyuncs.com/chigua/mini-program/static/dockingAPI/pic_01.png'])
Z(z[4])
Z(z[5])
Z([3,'http://dyfsserver.oss-cn-shenzhen.aliyuncs.com/chigua/mini-program/static/dockingGame/importGame.png'])
})(__WXML_GLOBAL__.ops_cached.$gwx_85);return __WXML_GLOBAL__.ops_cached.$gwx_85
}
function gz$gwx_86(){
if( __WXML_GLOBAL__.ops_cached.$gwx_86)return __WXML_GLOBAL__.ops_cached.$gwx_86
__WXML_GLOBAL__.ops_cached.$gwx_86=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[8],'title',[1,'checkbox']],[[8],'desc',[1,'多选项目。']]])
Z([3,'head'])
Z([[9],[[8],'title',[1,'checkbox-group']],[[8],'desc',[1,'多项选择器，内部由多个checkbox组成。']]])
Z(z[2])
})(__WXML_GLOBAL__.ops_cached.$gwx_86);return __WXML_GLOBAL__.ops_cached.$gwx_86
}
function gz$gwx_87(){
if( __WXML_GLOBAL__.ops_cached.$gwx_87)return __WXML_GLOBAL__.ops_cached.$gwx_87
__WXML_GLOBAL__.ops_cached.$gwx_87=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'cover-image']],[[8],'desc',[1,'覆盖在原生组件之上的图片视图。可覆盖的原生组件同cover-view，支持嵌套在cover-view里。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_87);return __WXML_GLOBAL__.ops_cached.$gwx_87
}
function gz$gwx_88(){
if( __WXML_GLOBAL__.ops_cached.$gwx_88)return __WXML_GLOBAL__.ops_cached.$gwx_88
__WXML_GLOBAL__.ops_cached.$gwx_88=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'cover-view']],[[8],'desc',[1,'覆盖在原生组件之上的文本视图。可覆盖的原生组件包括 map、video、canvas、camera、live-player、live-pusher。只支持嵌套 cover-view、cover-image，可在 cover-view 中使用 button。组件属性的长度单位默认为px，2.4.0起支持传入单位(rpx/px)。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_88);return __WXML_GLOBAL__.ops_cached.$gwx_88
}
function gz$gwx_89(){
if( __WXML_GLOBAL__.ops_cached.$gwx_89)return __WXML_GLOBAL__.ops_cached.$gwx_89
__WXML_GLOBAL__.ops_cached.$gwx_89=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[9],[[8],'title',[1,'editor']],[[8],'desc',[1,'富文本编辑器，可以对图片、文字进行编辑。']]],[[8],'tip',[1,'图片控件仅初始化时设置有效']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_89);return __WXML_GLOBAL__.ops_cached.$gwx_89
}
function gz$gwx_90(){
if( __WXML_GLOBAL__.ops_cached.$gwx_90)return __WXML_GLOBAL__.ops_cached.$gwx_90
__WXML_GLOBAL__.ops_cached.$gwx_90=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[8],'title',[1,'form']],[[8],'desc',[1,'表单。将组件内的用户输入的switch input checkbox slider radio picker 提交。当点击 form 表单中 form-type 为 submit 的 button 组件时，会将表单组件中的 value 值进行提交，需要在表单组件中加上 name 来作为 key。']]])
Z([3,'head'])
Z([[9],[[8],'property',[1,'report-submit、report-submit-timeout']],[[8],'event',[1,'']]])
Z([3,'noSupport'])
})(__WXML_GLOBAL__.ops_cached.$gwx_90);return __WXML_GLOBAL__.ops_cached.$gwx_90
}
function gz$gwx_91(){
if( __WXML_GLOBAL__.ops_cached.$gwx_91)return __WXML_GLOBAL__.ops_cached.$gwx_91
__WXML_GLOBAL__.ops_cached.$gwx_91=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'icon']],[[8],'desc',[1,'图标。组件属性的长度单位默认为px，2.4.0起支持传入单位(rpx/px)。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_91);return __WXML_GLOBAL__.ops_cached.$gwx_91
}
function gz$gwx_92(){
if( __WXML_GLOBAL__.ops_cached.$gwx_92)return __WXML_GLOBAL__.ops_cached.$gwx_92
__WXML_GLOBAL__.ops_cached.$gwx_92=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'image']],[[8],'desc',[1,'图片。支持JPG、PNG、SVG格式，2.3.0 起支持云文件ID。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_92);return __WXML_GLOBAL__.ops_cached.$gwx_92
}
function gz$gwx_93(){
if( __WXML_GLOBAL__.ops_cached.$gwx_93)return __WXML_GLOBAL__.ops_cached.$gwx_93
__WXML_GLOBAL__.ops_cached.$gwx_93=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_93);return __WXML_GLOBAL__.ops_cached.$gwx_93
}
function gz$gwx_94(){
if( __WXML_GLOBAL__.ops_cached.$gwx_94)return __WXML_GLOBAL__.ops_cached.$gwx_94
__WXML_GLOBAL__.ops_cached.$gwx_94=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'withOauth']])
})(__WXML_GLOBAL__.ops_cached.$gwx_94);return __WXML_GLOBAL__.ops_cached.$gwx_94
}
function gz$gwx_95(){
if( __WXML_GLOBAL__.ops_cached.$gwx_95)return __WXML_GLOBAL__.ops_cached.$gwx_95
__WXML_GLOBAL__.ops_cached.$gwx_95=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_95);return __WXML_GLOBAL__.ops_cached.$gwx_95
}
function gz$gwx_96(){
if( __WXML_GLOBAL__.ops_cached.$gwx_96)return __WXML_GLOBAL__.ops_cached.$gwx_96
__WXML_GLOBAL__.ops_cached.$gwx_96=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[8],'title',[1,'input']],[[8],'desc',[1,'输入框。该组件是原生组件，使用时请注意相关限制']]])
Z([3,'head'])
Z([[9],[[8],'property',[1,'cursor-spacing、cursor、confirm-type、selection-start、selection-end、adjust-position、hold-keyboard']],[[8],'event',[1,'bindkeyboardheightchange']]])
Z([3,'noSupport'])
})(__WXML_GLOBAL__.ops_cached.$gwx_96);return __WXML_GLOBAL__.ops_cached.$gwx_96
}
function gz$gwx_97(){
if( __WXML_GLOBAL__.ops_cached.$gwx_97)return __WXML_GLOBAL__.ops_cached.$gwx_97
__WXML_GLOBAL__.ops_cached.$gwx_97=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'label']],[[8],'desc',[1,'用来改进表单组件的可用性。使用for属性找到对应的id，或者将控件放在该标签下，当点击时，就会触发对应的控件。 for优先级高于内部控件，内部有多个控件的时候默认触发第一个控件。 目前可以绑定的控件有：button, checkbox, radio, switch。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_97);return __WXML_GLOBAL__.ops_cached.$gwx_97
}
function gz$gwx_98(){
if( __WXML_GLOBAL__.ops_cached.$gwx_98)return __WXML_GLOBAL__.ops_cached.$gwx_98
__WXML_GLOBAL__.ops_cached.$gwx_98=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_98);return __WXML_GLOBAL__.ops_cached.$gwx_98
}
function gz$gwx_99(){
if( __WXML_GLOBAL__.ops_cached.$gwx_99)return __WXML_GLOBAL__.ops_cached.$gwx_99
__WXML_GLOBAL__.ops_cached.$gwx_99=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'movable-area']],[[8],'desc',[1,'movable-view的可移动区域。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_99);return __WXML_GLOBAL__.ops_cached.$gwx_99
}
function gz$gwx_100(){
if( __WXML_GLOBAL__.ops_cached.$gwx_100)return __WXML_GLOBAL__.ops_cached.$gwx_100
__WXML_GLOBAL__.ops_cached.$gwx_100=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_100);return __WXML_GLOBAL__.ops_cached.$gwx_100
}
function gz$gwx_101(){
if( __WXML_GLOBAL__.ops_cached.$gwx_101)return __WXML_GLOBAL__.ops_cached.$gwx_101
__WXML_GLOBAL__.ops_cached.$gwx_101=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[8],'title',[1,'navigator']],[[8],'desc',[1,'页面链接。']]])
Z([3,'head'])
Z([[9],[[8],'property',[1,'open-type(reLaunch、exit)、delta、app-id、path、extra-data。version']],[[8],'event',[1,'bindsuccess、bindfail、bindcomplete']]])
Z([3,'noSupport'])
Z([3,'a-list'])
Z([[2,'&&'],[[2,'!='],[[7],[3,'openType']],[1,4]],[[2,'!='],[[7],[3,'target']],[1,1]]])
Z([[2,'=='],[[7],[3,'openType']],[1,4]])
})(__WXML_GLOBAL__.ops_cached.$gwx_101);return __WXML_GLOBAL__.ops_cached.$gwx_101
}
function gz$gwx_102(){
if( __WXML_GLOBAL__.ops_cached.$gwx_102)return __WXML_GLOBAL__.ops_cached.$gwx_102
__WXML_GLOBAL__.ops_cached.$gwx_102=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[9],[[8],'title',[1,'open-data']],[[8],'desc',[1,'用于展示微信开放的数据。']]],[[8],'tip',[1,'type为groupName时需要另外处理，详情看微信官网。']]])
Z([3,'head'])
Z([3,'a-list'])
Z([[2,'=='],[[7],[3,'type']],[1,0]])
Z([[2,'!='],[[7],[3,'type']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_102);return __WXML_GLOBAL__.ops_cached.$gwx_102
}
function gz$gwx_103(){
if( __WXML_GLOBAL__.ops_cached.$gwx_103)return __WXML_GLOBAL__.ops_cached.$gwx_103
__WXML_GLOBAL__.ops_cached.$gwx_103=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[9],[[8],'title',[1,'picker-view']],[[8],'desc',[1,'嵌入页面的滚动选择器。其中只可放置 picker-view-column组件，其它节点不会显示。']]],[[8],'tip',[1,'初始化生效属性：indicator-style、indicator-class、mask-style、mask-class']]])
Z([3,'head'])
Z([[9],[[8],'title',[1,'picker-view-column']],[[8],'desc',[1,'滚动选择器子项。仅可放置于picker-view中，其孩子节点的高度会自动设置成与picker-view的选中框的高度一致']]])
Z(z[2])
Z([[9],[[8],'property',[1,'indicator-class、mask-style、mask-class']],[[8],'event',[1,'bindpickstart、bindpickend']]])
Z([3,'noSupport'])
})(__WXML_GLOBAL__.ops_cached.$gwx_103);return __WXML_GLOBAL__.ops_cached.$gwx_103
}
function gz$gwx_104(){
if( __WXML_GLOBAL__.ops_cached.$gwx_104)return __WXML_GLOBAL__.ops_cached.$gwx_104
__WXML_GLOBAL__.ops_cached.$gwx_104=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[8],'title',[1,'picker']],[[8],'desc',[1,'从底部弹起的滚动选择器。']]])
Z([3,'head'])
Z([[9],[[8],'property',[1,'mode(multiSelector、region)']],[[8],'event',[1,'']]])
Z([3,'noSupport'])
Z([3,'demo'])
Z([[2,'=='],[[7],[3,'mode']],[1,0]])
Z([[2,'=='],[[7],[3,'mode']],[1,1]])
Z([[2,'=='],[[7],[3,'mode']],[1,2]])
Z([[2,'=='],[[7],[3,'mode']],[1,3]])
Z([[2,'=='],[[7],[3,'mode']],[1,4]])
})(__WXML_GLOBAL__.ops_cached.$gwx_104);return __WXML_GLOBAL__.ops_cached.$gwx_104
}
function gz$gwx_105(){
if( __WXML_GLOBAL__.ops_cached.$gwx_105)return __WXML_GLOBAL__.ops_cached.$gwx_105
__WXML_GLOBAL__.ops_cached.$gwx_105=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_105);return __WXML_GLOBAL__.ops_cached.$gwx_105
}
function gz$gwx_106(){
if( __WXML_GLOBAL__.ops_cached.$gwx_106)return __WXML_GLOBAL__.ops_cached.$gwx_106
__WXML_GLOBAL__.ops_cached.$gwx_106=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'progress']],[[8],'desc',[1,'进度条。组件属性的长度单位默认为px，2.4.0起支持传入单位(rpx/px)。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_106);return __WXML_GLOBAL__.ops_cached.$gwx_106
}
function gz$gwx_107(){
if( __WXML_GLOBAL__.ops_cached.$gwx_107)return __WXML_GLOBAL__.ops_cached.$gwx_107
__WXML_GLOBAL__.ops_cached.$gwx_107=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_107);return __WXML_GLOBAL__.ops_cached.$gwx_107
}
function gz$gwx_108(){
if( __WXML_GLOBAL__.ops_cached.$gwx_108)return __WXML_GLOBAL__.ops_cached.$gwx_108
__WXML_GLOBAL__.ops_cached.$gwx_108=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[8],'title',[1,'radio']],[[8],'desc',[1,'单选项目。']]])
Z([3,'head'])
Z([[9],[[8],'title',[1,'radio-group']],[[8],'desc',[1,'单项选择器，内部由多个 radio 组成。']]])
Z(z[2])
})(__WXML_GLOBAL__.ops_cached.$gwx_108);return __WXML_GLOBAL__.ops_cached.$gwx_108
}
function gz$gwx_109(){
if( __WXML_GLOBAL__.ops_cached.$gwx_109)return __WXML_GLOBAL__.ops_cached.$gwx_109
__WXML_GLOBAL__.ops_cached.$gwx_109=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[9],[[8],'title',[1,'rich-text']],[[8],'desc',[1,'富文本。']]],[[8],'tip',[1,'nodes: 现支持两种节点，通过type来区分，分别是元素节点和文本节点，默认是元素节点，在富文本区域里显示的HTML节点 元素节点：type \x3d node*,文本节点：type \x3d text*']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_109);return __WXML_GLOBAL__.ops_cached.$gwx_109
}
function gz$gwx_110(){
if( __WXML_GLOBAL__.ops_cached.$gwx_110)return __WXML_GLOBAL__.ops_cached.$gwx_110
__WXML_GLOBAL__.ops_cached.$gwx_110=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_110);return __WXML_GLOBAL__.ops_cached.$gwx_110
}
function gz$gwx_111(){
if( __WXML_GLOBAL__.ops_cached.$gwx_111)return __WXML_GLOBAL__.ops_cached.$gwx_111
__WXML_GLOBAL__.ops_cached.$gwx_111=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_111);return __WXML_GLOBAL__.ops_cached.$gwx_111
}
function gz$gwx_112(){
if( __WXML_GLOBAL__.ops_cached.$gwx_112)return __WXML_GLOBAL__.ops_cached.$gwx_112
__WXML_GLOBAL__.ops_cached.$gwx_112=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[8],'title',[1,'scroll-view']],[[8],'desc',[1,'可滚动视图区域。使用竖向滚动时，需要给scroll-view一个固定高度，通过 WXSS 设置 height。组件属性的长度单位默认为px，2.4.0起支持传入单位(rpx/px)。']]])
Z([3,'head'])
Z([[9],[[8],'property',[1,'enable-back-to-top']],[[8],'event',[1,'']]])
Z([3,'noSupport'])
})(__WXML_GLOBAL__.ops_cached.$gwx_112);return __WXML_GLOBAL__.ops_cached.$gwx_112
}
function gz$gwx_113(){
if( __WXML_GLOBAL__.ops_cached.$gwx_113)return __WXML_GLOBAL__.ops_cached.$gwx_113
__WXML_GLOBAL__.ops_cached.$gwx_113=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'slider']],[[8],'desc',[1,'滑动选择器。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_113);return __WXML_GLOBAL__.ops_cached.$gwx_113
}
function gz$gwx_114(){
if( __WXML_GLOBAL__.ops_cached.$gwx_114)return __WXML_GLOBAL__.ops_cached.$gwx_114
__WXML_GLOBAL__.ops_cached.$gwx_114=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'toggleCategory'])
Z([3,'category'])
Z([1,true])
Z([1,80])
Z([[7],[3,'categoryCur']])
Z([[7],[3,'categoryMenu']])
Z([3,'animationFinish'])
Z(z[4])
Z([[7],[3,'duration']])
Z([[7],[3,'categoryData']])
Z([3,'index'])
Z([3,'more'])
Z([3,'refresh'])
Z([[6],[[7],[3,'item']],[3,'emptyShow']])
Z([[6],[[7],[3,'item']],[3,'end']])
Z(z[2])
Z([[6],[[6],[[7],[3,'item']],[3,'listData']],[3,'length']])
Z([[6],[[7],[3,'item']],[3,'requesting']])
Z(z[3])
})(__WXML_GLOBAL__.ops_cached.$gwx_114);return __WXML_GLOBAL__.ops_cached.$gwx_114
}
function gz$gwx_115(){
if( __WXML_GLOBAL__.ops_cached.$gwx_115)return __WXML_GLOBAL__.ops_cached.$gwx_115
__WXML_GLOBAL__.ops_cached.$gwx_115=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_115);return __WXML_GLOBAL__.ops_cached.$gwx_115
}
function gz$gwx_116(){
if( __WXML_GLOBAL__.ops_cached.$gwx_116)return __WXML_GLOBAL__.ops_cached.$gwx_116
__WXML_GLOBAL__.ops_cached.$gwx_116=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[8],'title',[1,'swiper']],[[8],'desc',[1,'滑块视图容器。其中只可放置swiper-item组件，否则会导致未定义的行为。']]])
Z([3,'head'])
Z([[9],[[8],'title',[1,'swiper-item']],[[8],'desc',[1,'仅可放置在swiper组件中，宽高自动设置为100%。']]])
Z(z[2])
})(__WXML_GLOBAL__.ops_cached.$gwx_116);return __WXML_GLOBAL__.ops_cached.$gwx_116
}
function gz$gwx_117(){
if( __WXML_GLOBAL__.ops_cached.$gwx_117)return __WXML_GLOBAL__.ops_cached.$gwx_117
__WXML_GLOBAL__.ops_cached.$gwx_117=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'switch']],[[8],'desc',[1,'开关选择器。']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_117);return __WXML_GLOBAL__.ops_cached.$gwx_117
}
function gz$gwx_118(){
if( __WXML_GLOBAL__.ops_cached.$gwx_118)return __WXML_GLOBAL__.ops_cached.$gwx_118
__WXML_GLOBAL__.ops_cached.$gwx_118=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_118);return __WXML_GLOBAL__.ops_cached.$gwx_118
}
function gz$gwx_119(){
if( __WXML_GLOBAL__.ops_cached.$gwx_119)return __WXML_GLOBAL__.ops_cached.$gwx_119
__WXML_GLOBAL__.ops_cached.$gwx_119=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[9],[[8],'title',[1,'textarea']],[[8],'desc',[1,'多行输入框。该组件是原生组件，使用时请注意相关限制。']]],[[8],'tip',[1,'初始化属性：show-confirm-bar']]])
Z([3,'head'])
Z([[9],[[8],'property',[1,'fixed、cursor-spacing、show-confirm-bar、selection-start、selection-end、adjust-position']],[[8],'event',[1,'bindconfirm、bindkeyboardheightchange']]])
Z([3,'noSupport'])
})(__WXML_GLOBAL__.ops_cached.$gwx_119);return __WXML_GLOBAL__.ops_cached.$gwx_119
}
function gz$gwx_120(){
if( __WXML_GLOBAL__.ops_cached.$gwx_120)return __WXML_GLOBAL__.ops_cached.$gwx_120
__WXML_GLOBAL__.ops_cached.$gwx_120=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[9],[[9],[[8],'title',[1,'video']],[[8],'desc',[1,'视频。相关api：wx.createVideoContext']]],[[8],'tip',[1,'初始化属性：object-fit；手机端生效属性：showPlayBtn、poster、playBtnPosition']]])
Z([3,'head'])
Z([[9],[[8],'property',[1,'loop、muted、initial-time、page-gesture、direction、show-progress、show-fullscreen-btn、show-play-btn、show-center-play-btn、enable-progress-gesture、show-mute-btn、title、play-btn-position、enable-play-gesture、auto-pause-if-navigate、auto-pause-if-open-native、vslide-gesture、vslide-gesture-in-fullscreen']],[[8],'event',[1,'bindfullscreenchange、bindwaiting、binderror、bindprogress']]])
Z([3,'noSupport'])
})(__WXML_GLOBAL__.ops_cached.$gwx_120);return __WXML_GLOBAL__.ops_cached.$gwx_120
}
function gz$gwx_121(){
if( __WXML_GLOBAL__.ops_cached.$gwx_121)return __WXML_GLOBAL__.ops_cached.$gwx_121
__WXML_GLOBAL__.ops_cached.$gwx_121=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[9],[[8],'title',[1,'view']],[[8],'desc',[1,'视图容器']]])
Z([3,'head'])
})(__WXML_GLOBAL__.ops_cached.$gwx_121);return __WXML_GLOBAL__.ops_cached.$gwx_121
}
function gz$gwx_122(){
if( __WXML_GLOBAL__.ops_cached.$gwx_122)return __WXML_GLOBAL__.ops_cached.$gwx_122
__WXML_GLOBAL__.ops_cached.$gwx_122=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_122);return __WXML_GLOBAL__.ops_cached.$gwx_122
}
function gz$gwx_123(){
if( __WXML_GLOBAL__.ops_cached.$gwx_123)return __WXML_GLOBAL__.ops_cached.$gwx_123
__WXML_GLOBAL__.ops_cached.$gwx_123=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'navHeight']])
Z([[7],[3,'systemHeight']])
})(__WXML_GLOBAL__.ops_cached.$gwx_123);return __WXML_GLOBAL__.ops_cached.$gwx_123
}
function gz$gwx_124(){
if( __WXML_GLOBAL__.ops_cached.$gwx_124)return __WXML_GLOBAL__.ops_cached.$gwx_124
__WXML_GLOBAL__.ops_cached.$gwx_124=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_124);return __WXML_GLOBAL__.ops_cached.$gwx_124
}
function gz$gwx_125(){
if( __WXML_GLOBAL__.ops_cached.$gwx_125)return __WXML_GLOBAL__.ops_cached.$gwx_125
__WXML_GLOBAL__.ops_cached.$gwx_125=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_125);return __WXML_GLOBAL__.ops_cached.$gwx_125
}
function gz$gwx_126(){
if( __WXML_GLOBAL__.ops_cached.$gwx_126)return __WXML_GLOBAL__.ops_cached.$gwx_126
__WXML_GLOBAL__.ops_cached.$gwx_126=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_126);return __WXML_GLOBAL__.ops_cached.$gwx_126
}
function gz$gwx_127(){
if( __WXML_GLOBAL__.ops_cached.$gwx_127)return __WXML_GLOBAL__.ops_cached.$gwx_127
__WXML_GLOBAL__.ops_cached.$gwx_127=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_127);return __WXML_GLOBAL__.ops_cached.$gwx_127
}
function gz$gwx_128(){
if( __WXML_GLOBAL__.ops_cached.$gwx_128)return __WXML_GLOBAL__.ops_cached.$gwx_128
__WXML_GLOBAL__.ops_cached.$gwx_128=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_128);return __WXML_GLOBAL__.ops_cached.$gwx_128
}
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={"m_./pages/api/bluetooth/bluetooth.wxml:utils":np_0,};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
f_['./pages/api/bluetooth/bluetooth.wxml']={};
f_['./pages/api/bluetooth/bluetooth.wxml']['utils'] =nv_require("m_./pages/api/bluetooth/bluetooth.wxml:utils");
function np_0(){var nv_module={nv_exports:{}};nv_module.nv_exports.nv_max = (function (nv_n1,nv_n2){return(Math.nv_max(nv_n1,nv_n2))});nv_module.nv_exports.nv_len = (function (nv_arr){nv_arr = nv_arr || [];return(nv_arr.nv_length)});return nv_module.nv_exports;}

var x=['./components/scroll/index.wxml','./components/tab/index.wxml','./ec-canvas/ec-canvas.wxml','./lib/cgImage/index.wxml','./lib/customHeader/index.wxml','./lib/icon/index.wxml','./pages/api/NFC/NFC.wxml','./pages/api/accelerometer/accelerometer.wxml','./pages/api/accountInfo/accountInfo.wxml','./pages/api/ad/ad.wxml','./pages/api/address/address.wxml','./pages/api/animation/animation.wxml','./pages/api/authorize/authorize.wxml','./pages/api/background-audio/background-audio.wxml','./pages/api/background/background.wxml','./pages/api/basis/basis.wxml','./pages/api/battery/battery.wxml','./pages/api/bluetooth/bluetooth.wxml','./pages/api/camera/camera.wxml','./pages/api/canvas/canvas.wxml','./pages/api/clipboard/clipboard.wxml','./pages/api/compass/compass.wxml','./pages/api/customVoice/customVoice.wxml','./pages/api/debug/debug.wxml','./pages/api/deviceMotion/deviceMotion.wxml','./pages/api/downloadFile/downloadFile.wxml','./pages/api/editor/editor.wxml','./pages/api/emergencyEvents/emergencyEvents.wxml','./pages/api/file/file.wxml','./pages/api/fontFace/fontFace.wxml','./pages/api/get-wxml-node-info/get-wxml-node-info.wxml','./pages/api/getLaunchOptions/getLaunchOptions.wxml','./pages/api/gyroscope/gyroscope.wxml','./pages/api/image/image.wxml','./pages/api/index.wxml','./pages/api/interaction/interaction.wxml','./pages/api/intersection-observer/intersection-observer.wxml','./pages/api/keyboard/keyboard.wxml','./pages/api/location/location.wxml','./pages/api/login/login.wxml','./pages/api/map/map.wxml','./pages/api/menu/menu.wxml','./pages/api/nav/nav.wxml','./pages/api/navigateMiniProgram/navigateMiniProgram.wxml','./pages/api/network/network.wxml','./pages/api/pageScrollTop/pageScrollTop.wxml','./pages/api/phoneCall/phoneCall.wxml','./pages/api/phoneContact/phoneContact.wxml','./pages/api/pullDownRefresh/pullDownRefresh.wxml','./pages/api/record/record.wxml','./pages/api/request/request.wxml','./pages/api/requestNative/requestNative.wxml','./pages/api/requestPayment/requestPayment.wxml','./pages/api/router/router.wxml','./pages/api/router/tPage/index.wxml','./pages/api/scanCode/scanCode.wxml','./pages/api/screen/screen.wxml','./pages/api/setTop/setTop.wxml','./pages/api/setting/setting.wxml','./pages/api/share/share.wxml','./pages/api/soterAuthentication/soterAuthentication.wxml','./pages/api/storage/storage.wxml','./pages/api/system-information/system-information.wxml','./pages/api/tabBar/tabBar.wxml','./pages/api/timer/timer.wxml','./pages/api/update/update.wxml','./pages/api/uploadFile/uploadFile.wxml','./pages/api/userInfo/userInfo.wxml','./pages/api/vibrate/vibrate.wxml','./pages/api/video/video.wxml','./pages/api/voice/voice.wxml','./pages/api/weRun/weRun.wxml','./pages/api/webSocket/webSocket.wxml','./pages/api/webSocketTask/webSocketTask.wxml','./pages/api/wifi/wifi.wxml','./pages/api/windowResize/windowResize.wxml','./pages/common/head.wxml','./pages/common/noSupport.wxml','./pages/component/ad/ad.wxml','./pages/component/audio/audio.wxml','/pages/common/head.wxml','./pages/component/bar/index.wxml','./pages/component/button/button.wxml','./pages/component/camera/camera.wxml','./pages/component/canvas/canvas.wxml','./pages/component/cgImage/cgImage.wxml','./pages/component/checkbox/checkbox.wxml','./pages/component/cover-image/cover-image.wxml','./pages/component/cover-view/cover-view.wxml','./pages/component/editor/editor.wxml','./pages/component/form/form.wxml','/pages/common/noSupport.wxml','./pages/component/icon/icon.wxml','./pages/component/image/image.wxml','./pages/component/index-list/index.wxml','./pages/component/index.wxml','./pages/component/input-native/input-native.wxml','./pages/component/input/input.wxml','./pages/component/label/label.wxml','./pages/component/map/map.wxml','./pages/component/movable-area/movable-area.wxml','./pages/component/movable-view/movable-view.wxml','./pages/component/navigator/navigator.wxml','./pages/component/open-data/open-data.wxml','./pages/component/picker-view/picker-view.wxml','./pages/component/picker/picker.wxml','./pages/component/player/player.wxml','./pages/component/progress/progress.wxml','./pages/component/pusher/pusher.wxml','./pages/component/radio/radio.wxml','./pages/component/rich-text/rich-text.wxml','./pages/component/scroll-view-olny/scroll-view-olny.wxml','./pages/component/scroll-view-swiper/scroll-view-swiper.wxml','./pages/component/scroll-view/scroll-view.wxml','./pages/component/slider/slider.wxml','./pages/component/swipe-list/index.wxml','./pages/component/swipe-list/webview/index.wxml','./pages/component/swiper/swiper.wxml','./pages/component/switch/switch.wxml','./pages/component/text/text.wxml','./pages/component/textarea/textarea.wxml','./pages/component/video/video.wxml','./pages/component/view/view.wxml','./pages/component/web-view/web-view.wxml','./pages/freamwork/customNavigator/customNavigator.wxml','./pages/freamwork/event/event.wxml','./pages/freamwork/index.wxml','./pages/freamwork/pageConfig/pageConfig.wxml','./pages/freamwork/pageCustomConfig/pageCustomConfig.wxml','./pages/server/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_1()
var oB=_mz(z,'movable-view',['bind:change',0,'bind:touchend',1,'class',1,'direction',2,'disabled',3,'style',4,'y',5],[],e,s,gg)
var xC=_mz(z,'scroll-view',['bindscroll',7,'bindscrolltolower',1,'class',2,'enableBackToTop',3,'lowerThreshold',4,'scrollTop',5,'scrollY',6,'style',7],[],e,s,gg)
var cF=_n('view')
_rz(z,cF,'class',15,e,s,gg)
var hG=_v()
_(cF,hG)
if(_oz(z,16,e,s,gg)){hG.wxVkey=1
}
var oH=_v()
_(cF,oH)
if(_oz(z,17,e,s,gg)){oH.wxVkey=1
}
hG.wxXCkey=1
oH.wxXCkey=1
_(xC,cF)
var cI=_n('slot')
_(xC,cI)
var oD=_v()
_(xC,oD)
if(_oz(z,18,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(xC,fE)
if(_oz(z,19,e,s,gg)){fE.wxVkey=1
}
oD.wxXCkey=1
fE.wxXCkey=1
_(oB,xC)
_(r,oB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var z=gz$gwx_2()
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var z=gz$gwx_3()
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
d_[x[3]]={}
var m3=function(e,s,r,gg){
var z=gz$gwx_4()
return r
}
e_[x[3]]={f:m3,j:[],i:[],ti:[],ic:[]}
d_[x[4]]={}
var m4=function(e,s,r,gg){
var z=gz$gwx_5()
var eN=_n('view')
_rz(z,eN,'class',0,e,s,gg)
var bO=_mz(z,'i-icon',['bindtap',1,'color',1,'size',2,'type',3],[],e,s,gg)
_(eN,bO)
var oP=_mz(z,'i-icon',['bindtap',5,'color',1,'size',2,'type',3],[],e,s,gg)
_(eN,oP)
_(r,eN)
return r
}
e_[x[4]]={f:m4,j:[],i:[],ti:[],ic:[]}
d_[x[5]]={}
var m5=function(e,s,r,gg){
var z=gz$gwx_6()
return r
}
e_[x[5]]={f:m5,j:[],i:[],ti:[],ic:[]}
d_[x[6]]={}
var m6=function(e,s,r,gg){
var z=gz$gwx_7()
var fS=_v()
_(r,fS)
if(_oz(z,0,e,s,gg)){fS.wxVkey=1
}
fS.wxXCkey=1
return r
}
e_[x[6]]={f:m6,j:[],i:[],ti:[],ic:[]}
d_[x[7]]={}
var m7=function(e,s,r,gg){
var z=gz$gwx_8()
var hU=_n('view')
_rz(z,hU,'class',0,e,s,gg)
var oV=_v()
_(hU,oV)
if(_oz(z,1,e,s,gg)){oV.wxVkey=1
}
var cW=_v()
_(hU,cW)
if(_oz(z,2,e,s,gg)){cW.wxVkey=1
}
var oX=_v()
_(hU,oX)
if(_oz(z,3,e,s,gg)){oX.wxVkey=1
}
oV.wxXCkey=1
cW.wxXCkey=1
oX.wxXCkey=1
_(r,hU)
return r
}
e_[x[7]]={f:m7,j:[],i:[],ti:[],ic:[]}
d_[x[8]]={}
var m8=function(e,s,r,gg){
var z=gz$gwx_9()
var aZ=_v()
_(r,aZ)
if(_oz(z,0,e,s,gg)){aZ.wxVkey=1
}
aZ.wxXCkey=1
return r
}
e_[x[8]]={f:m8,j:[],i:[],ti:[],ic:[]}
d_[x[9]]={}
var m9=function(e,s,r,gg){
var z=gz$gwx_10()
return r
}
e_[x[9]]={f:m9,j:[],i:[],ti:[],ic:[]}
d_[x[10]]={}
var m10=function(e,s,r,gg){
var z=gz$gwx_11()
var b3=_v()
_(r,b3)
if(_oz(z,0,e,s,gg)){b3.wxVkey=1
}
b3.wxXCkey=1
return r
}
e_[x[10]]={f:m10,j:[],i:[],ti:[],ic:[]}
d_[x[11]]={}
var m11=function(e,s,r,gg){
var z=gz$gwx_12()
return r
}
e_[x[11]]={f:m11,j:[],i:[],ti:[],ic:[]}
d_[x[12]]={}
var m12=function(e,s,r,gg){
var z=gz$gwx_13()
var o6=_n('view')
_rz(z,o6,'class',0,e,s,gg)
var f7=_v()
_(o6,f7)
if(_oz(z,1,e,s,gg)){f7.wxVkey=1
}
var c8=_v()
_(o6,c8)
if(_oz(z,2,e,s,gg)){c8.wxVkey=1
}
f7.wxXCkey=1
c8.wxXCkey=1
_(r,o6)
return r
}
e_[x[12]]={f:m12,j:[],i:[],ti:[],ic:[]}
d_[x[13]]={}
var m13=function(e,s,r,gg){
var z=gz$gwx_14()
var o0=_n('view')
_rz(z,o0,'class',0,e,s,gg)
var cAB=_v()
_(o0,cAB)
if(_oz(z,1,e,s,gg)){cAB.wxVkey=1
}
var oBB=_v()
_(o0,oBB)
if(_oz(z,2,e,s,gg)){oBB.wxVkey=1
}
var lCB=_v()
_(o0,lCB)
if(_oz(z,3,e,s,gg)){lCB.wxVkey=1
}
var aDB=_v()
_(o0,aDB)
if(_oz(z,4,e,s,gg)){aDB.wxVkey=1
}
var tEB=_v()
_(o0,tEB)
if(_oz(z,5,e,s,gg)){tEB.wxVkey=1
}
cAB.wxXCkey=1
oBB.wxXCkey=1
lCB.wxXCkey=1
aDB.wxXCkey=1
tEB.wxXCkey=1
_(r,o0)
return r
}
e_[x[13]]={f:m13,j:[],i:[],ti:[],ic:[]}
d_[x[14]]={}
var m14=function(e,s,r,gg){
var z=gz$gwx_15()
return r
}
e_[x[14]]={f:m14,j:[],i:[],ti:[],ic:[]}
d_[x[15]]={}
var m15=function(e,s,r,gg){
var z=gz$gwx_16()
var oHB=_v()
_(r,oHB)
if(_oz(z,0,e,s,gg)){oHB.wxVkey=1
}
oHB.wxXCkey=1
return r
}
e_[x[15]]={f:m15,j:[],i:[],ti:[],ic:[]}
d_[x[16]]={}
var m16=function(e,s,r,gg){
var z=gz$gwx_17()
var oJB=_n('view')
_rz(z,oJB,'class',0,e,s,gg)
var fKB=_v()
_(oJB,fKB)
if(_oz(z,1,e,s,gg)){fKB.wxVkey=1
}
var cLB=_v()
_(oJB,cLB)
if(_oz(z,2,e,s,gg)){cLB.wxVkey=1
}
fKB.wxXCkey=1
cLB.wxXCkey=1
_(r,oJB)
return r
}
e_[x[16]]={f:m16,j:[],i:[],ti:[],ic:[]}
d_[x[17]]={}
var m17=function(e,s,r,gg){
var z=gz$gwx_18()
var oNB=_v()
_(r,oNB)
if(_oz(z,0,e,s,gg)){oNB.wxVkey=1
var cOB=_v()
_(oNB,cOB)
if(_oz(z,1,e,s,gg)){cOB.wxVkey=1
}
cOB.wxXCkey=1
}
oNB.wxXCkey=1
return r
}
e_[x[17]]={f:m17,j:[],i:[],ti:[],ic:[]}
d_[x[18]]={}
var m18=function(e,s,r,gg){
var z=gz$gwx_19()
var lQB=_n('view')
_rz(z,lQB,'class',0,e,s,gg)
var bUB=_n('view')
_rz(z,bUB,'class',1,e,s,gg)
var oVB=_v()
_(bUB,oVB)
if(_oz(z,2,e,s,gg)){oVB.wxVkey=1
}
var xWB=_v()
_(bUB,xWB)
if(_oz(z,3,e,s,gg)){xWB.wxVkey=1
}
oVB.wxXCkey=1
xWB.wxXCkey=1
_(lQB,bUB)
var aRB=_v()
_(lQB,aRB)
if(_oz(z,4,e,s,gg)){aRB.wxVkey=1
}
var oXB=_n('view')
_rz(z,oXB,'class',5,e,s,gg)
var fYB=_v()
_(oXB,fYB)
if(_oz(z,6,e,s,gg)){fYB.wxVkey=1
}
var cZB=_v()
_(oXB,cZB)
if(_oz(z,7,e,s,gg)){cZB.wxVkey=1
}
fYB.wxXCkey=1
cZB.wxXCkey=1
_(lQB,oXB)
var tSB=_v()
_(lQB,tSB)
if(_oz(z,8,e,s,gg)){tSB.wxVkey=1
}
var eTB=_v()
_(lQB,eTB)
if(_oz(z,9,e,s,gg)){eTB.wxVkey=1
}
aRB.wxXCkey=1
tSB.wxXCkey=1
eTB.wxXCkey=1
_(r,lQB)
return r
}
e_[x[18]]={f:m18,j:[],i:[],ti:[],ic:[]}
d_[x[19]]={}
var m19=function(e,s,r,gg){
var z=gz$gwx_20()
return r
}
e_[x[19]]={f:m19,j:[],i:[],ti:[],ic:[]}
d_[x[20]]={}
var m20=function(e,s,r,gg){
var z=gz$gwx_21()
var c3B=_n('view')
_rz(z,c3B,'class',0,e,s,gg)
var o4B=_v()
_(c3B,o4B)
if(_oz(z,1,e,s,gg)){o4B.wxVkey=1
}
var l5B=_v()
_(c3B,l5B)
if(_oz(z,2,e,s,gg)){l5B.wxVkey=1
}
o4B.wxXCkey=1
l5B.wxXCkey=1
_(r,c3B)
return r
}
e_[x[20]]={f:m20,j:[],i:[],ti:[],ic:[]}
d_[x[21]]={}
var m21=function(e,s,r,gg){
var z=gz$gwx_22()
var t7B=_n('view')
_rz(z,t7B,'class',0,e,s,gg)
var e8B=_v()
_(t7B,e8B)
if(_oz(z,1,e,s,gg)){e8B.wxVkey=1
}
var b9B=_v()
_(t7B,b9B)
if(_oz(z,2,e,s,gg)){b9B.wxVkey=1
}
var o0B=_v()
_(t7B,o0B)
if(_oz(z,3,e,s,gg)){o0B.wxVkey=1
}
e8B.wxXCkey=1
b9B.wxXCkey=1
o0B.wxXCkey=1
_(r,t7B)
return r
}
e_[x[21]]={f:m21,j:[],i:[],ti:[],ic:[]}
d_[x[22]]={}
var m22=function(e,s,r,gg){
var z=gz$gwx_23()
return r
}
e_[x[22]]={f:m22,j:[],i:[],ti:[],ic:[]}
d_[x[23]]={}
var m23=function(e,s,r,gg){
var z=gz$gwx_24()
return r
}
e_[x[23]]={f:m23,j:[],i:[],ti:[],ic:[]}
d_[x[24]]={}
var m24=function(e,s,r,gg){
var z=gz$gwx_25()
var cDC=_n('view')
_rz(z,cDC,'class',0,e,s,gg)
var hEC=_v()
_(cDC,hEC)
if(_oz(z,1,e,s,gg)){hEC.wxVkey=1
}
var oFC=_v()
_(cDC,oFC)
if(_oz(z,2,e,s,gg)){oFC.wxVkey=1
}
var cGC=_v()
_(cDC,cGC)
if(_oz(z,3,e,s,gg)){cGC.wxVkey=1
}
hEC.wxXCkey=1
oFC.wxXCkey=1
cGC.wxXCkey=1
_(r,cDC)
return r
}
e_[x[24]]={f:m24,j:[],i:[],ti:[],ic:[]}
d_[x[25]]={}
var m25=function(e,s,r,gg){
var z=gz$gwx_26()
var lIC=_n('view')
_rz(z,lIC,'class',0,e,s,gg)
var aJC=_v()
_(lIC,aJC)
if(_oz(z,1,e,s,gg)){aJC.wxVkey=1
}
var tKC=_v()
_(lIC,tKC)
if(_oz(z,2,e,s,gg)){tKC.wxVkey=1
var eLC=_v()
_(tKC,eLC)
if(_oz(z,3,e,s,gg)){eLC.wxVkey=1
}
eLC.wxXCkey=1
}
aJC.wxXCkey=1
tKC.wxXCkey=1
_(r,lIC)
return r
}
e_[x[25]]={f:m25,j:[],i:[],ti:[],ic:[]}
d_[x[26]]={}
var m26=function(e,s,r,gg){
var z=gz$gwx_27()
return r
}
e_[x[26]]={f:m26,j:[],i:[],ti:[],ic:[]}
d_[x[27]]={}
var m27=function(e,s,r,gg){
var z=gz$gwx_28()
return r
}
e_[x[27]]={f:m27,j:[],i:[],ti:[],ic:[]}
d_[x[28]]={}
var m28=function(e,s,r,gg){
var z=gz$gwx_29()
var oPC=_n('view')
_rz(z,oPC,'class',0,e,s,gg)
var fQC=_v()
_(oPC,fQC)
if(_oz(z,1,e,s,gg)){fQC.wxVkey=1
}
var cRC=_v()
_(oPC,cRC)
if(_oz(z,2,e,s,gg)){cRC.wxVkey=1
}
var hSC=_v()
_(oPC,hSC)
if(_oz(z,3,e,s,gg)){hSC.wxVkey=1
}
var oTC=_v()
_(oPC,oTC)
if(_oz(z,4,e,s,gg)){oTC.wxVkey=1
}
var cUC=_v()
_(oPC,cUC)
if(_oz(z,5,e,s,gg)){cUC.wxVkey=1
}
var oVC=_v()
_(oPC,oVC)
if(_oz(z,6,e,s,gg)){oVC.wxVkey=1
}
var lWC=_v()
_(oPC,lWC)
if(_oz(z,7,e,s,gg)){lWC.wxVkey=1
}
var aXC=_v()
_(oPC,aXC)
if(_oz(z,8,e,s,gg)){aXC.wxVkey=1
}
var tYC=_v()
_(oPC,tYC)
if(_oz(z,9,e,s,gg)){tYC.wxVkey=1
}
var eZC=_v()
_(oPC,eZC)
if(_oz(z,10,e,s,gg)){eZC.wxVkey=1
}
var b1C=_v()
_(oPC,b1C)
if(_oz(z,11,e,s,gg)){b1C.wxVkey=1
}
var o2C=_v()
_(oPC,o2C)
if(_oz(z,12,e,s,gg)){o2C.wxVkey=1
}
var x3C=_v()
_(oPC,x3C)
if(_oz(z,13,e,s,gg)){x3C.wxVkey=1
}
var o4C=_v()
_(oPC,o4C)
if(_oz(z,14,e,s,gg)){o4C.wxVkey=1
}
var f5C=_v()
_(oPC,f5C)
if(_oz(z,15,e,s,gg)){f5C.wxVkey=1
}
var c6C=_v()
_(oPC,c6C)
if(_oz(z,16,e,s,gg)){c6C.wxVkey=1
}
var h7C=_v()
_(oPC,h7C)
if(_oz(z,17,e,s,gg)){h7C.wxVkey=1
}
var o8C=_v()
_(oPC,o8C)
if(_oz(z,18,e,s,gg)){o8C.wxVkey=1
}
var c9C=_v()
_(oPC,c9C)
if(_oz(z,19,e,s,gg)){c9C.wxVkey=1
}
var o0C=_v()
_(oPC,o0C)
if(_oz(z,20,e,s,gg)){o0C.wxVkey=1
}
var lAD=_v()
_(oPC,lAD)
if(_oz(z,21,e,s,gg)){lAD.wxVkey=1
}
var aBD=_v()
_(oPC,aBD)
if(_oz(z,22,e,s,gg)){aBD.wxVkey=1
}
var tCD=_v()
_(oPC,tCD)
if(_oz(z,23,e,s,gg)){tCD.wxVkey=1
}
fQC.wxXCkey=1
cRC.wxXCkey=1
hSC.wxXCkey=1
oTC.wxXCkey=1
cUC.wxXCkey=1
oVC.wxXCkey=1
lWC.wxXCkey=1
aXC.wxXCkey=1
tYC.wxXCkey=1
eZC.wxXCkey=1
b1C.wxXCkey=1
o2C.wxXCkey=1
x3C.wxXCkey=1
o4C.wxXCkey=1
f5C.wxXCkey=1
c6C.wxXCkey=1
h7C.wxXCkey=1
o8C.wxXCkey=1
c9C.wxXCkey=1
o0C.wxXCkey=1
lAD.wxXCkey=1
aBD.wxXCkey=1
tCD.wxXCkey=1
_(r,oPC)
return r
}
e_[x[28]]={f:m28,j:[],i:[],ti:[],ic:[]}
d_[x[29]]={}
var m29=function(e,s,r,gg){
var z=gz$gwx_30()
return r
}
e_[x[29]]={f:m29,j:[],i:[],ti:[],ic:[]}
d_[x[30]]={}
var m30=function(e,s,r,gg){
var z=gz$gwx_31()
return r
}
e_[x[30]]={f:m30,j:[],i:[],ti:[],ic:[]}
d_[x[31]]={}
var m31=function(e,s,r,gg){
var z=gz$gwx_32()
return r
}
e_[x[31]]={f:m31,j:[],i:[],ti:[],ic:[]}
d_[x[32]]={}
var m32=function(e,s,r,gg){
var z=gz$gwx_33()
var oHD=_n('view')
_rz(z,oHD,'class',0,e,s,gg)
var fID=_v()
_(oHD,fID)
if(_oz(z,1,e,s,gg)){fID.wxVkey=1
}
var cJD=_v()
_(oHD,cJD)
if(_oz(z,2,e,s,gg)){cJD.wxVkey=1
}
var hKD=_v()
_(oHD,hKD)
if(_oz(z,3,e,s,gg)){hKD.wxVkey=1
}
fID.wxXCkey=1
cJD.wxXCkey=1
hKD.wxXCkey=1
_(r,oHD)
return r
}
e_[x[32]]={f:m32,j:[],i:[],ti:[],ic:[]}
d_[x[33]]={}
var m33=function(e,s,r,gg){
var z=gz$gwx_34()
var cMD=_n('view')
_rz(z,cMD,'class',0,e,s,gg)
var oND=_v()
_(cMD,oND)
if(_oz(z,1,e,s,gg)){oND.wxVkey=1
}
var lOD=_v()
_(cMD,lOD)
if(_oz(z,2,e,s,gg)){lOD.wxVkey=1
}
var eRD=_n('view')
_rz(z,eRD,'class',3,e,s,gg)
var bSD=_v()
_(eRD,bSD)
if(_oz(z,4,e,s,gg)){bSD.wxVkey=1
}
var oTD=_v()
_(eRD,oTD)
if(_oz(z,5,e,s,gg)){oTD.wxVkey=1
}
bSD.wxXCkey=1
oTD.wxXCkey=1
_(cMD,eRD)
var aPD=_v()
_(cMD,aPD)
if(_oz(z,6,e,s,gg)){aPD.wxVkey=1
}
var tQD=_v()
_(cMD,tQD)
if(_oz(z,7,e,s,gg)){tQD.wxVkey=1
}
oND.wxXCkey=1
lOD.wxXCkey=1
aPD.wxXCkey=1
tQD.wxXCkey=1
_(r,cMD)
return r
}
e_[x[33]]={f:m33,j:[],i:[],ti:[],ic:[]}
d_[x[34]]={}
var m34=function(e,s,r,gg){
var z=gz$gwx_35()
return r
}
e_[x[34]]={f:m34,j:[],i:[],ti:[],ic:[]}
d_[x[35]]={}
var m35=function(e,s,r,gg){
var z=gz$gwx_36()
return r
}
e_[x[35]]={f:m35,j:[],i:[],ti:[],ic:[]}
d_[x[36]]={}
var m36=function(e,s,r,gg){
var z=gz$gwx_37()
return r
}
e_[x[36]]={f:m36,j:[],i:[],ti:[],ic:[]}
d_[x[37]]={}
var m37=function(e,s,r,gg){
var z=gz$gwx_38()
return r
}
e_[x[37]]={f:m37,j:[],i:[],ti:[],ic:[]}
d_[x[38]]={}
var m38=function(e,s,r,gg){
var z=gz$gwx_39()
var oZD=_n('view')
_rz(z,oZD,'class',0,e,s,gg)
var c1D=_v()
_(oZD,c1D)
if(_oz(z,1,e,s,gg)){c1D.wxVkey=1
}
var o2D=_v()
_(oZD,o2D)
if(_oz(z,2,e,s,gg)){o2D.wxVkey=1
}
var l3D=_v()
_(oZD,l3D)
if(_oz(z,3,e,s,gg)){l3D.wxVkey=1
}
c1D.wxXCkey=1
o2D.wxXCkey=1
l3D.wxXCkey=1
_(r,oZD)
return r
}
e_[x[38]]={f:m38,j:[],i:[],ti:[],ic:[]}
d_[x[39]]={}
var m39=function(e,s,r,gg){
var z=gz$gwx_40()
var t5D=_n('view')
_rz(z,t5D,'class',0,e,s,gg)
var e6D=_v()
_(t5D,e6D)
if(_oz(z,1,e,s,gg)){e6D.wxVkey=1
}
var o8D=_n('view')
_rz(z,o8D,'class',2,e,s,gg)
var x9D=_v()
_(o8D,x9D)
if(_oz(z,3,e,s,gg)){x9D.wxVkey=1
}
var o0D=_v()
_(o8D,o0D)
if(_oz(z,4,e,s,gg)){o0D.wxVkey=1
}
x9D.wxXCkey=1
o0D.wxXCkey=1
_(t5D,o8D)
var b7D=_v()
_(t5D,b7D)
if(_oz(z,5,e,s,gg)){b7D.wxVkey=1
}
e6D.wxXCkey=1
b7D.wxXCkey=1
_(r,t5D)
return r
}
e_[x[39]]={f:m39,j:[],i:[],ti:[],ic:[]}
d_[x[40]]={}
var m40=function(e,s,r,gg){
var z=gz$gwx_41()
var cBE=_n('view')
_rz(z,cBE,'class',0,e,s,gg)
var hCE=_v()
_(cBE,hCE)
if(_oz(z,1,e,s,gg)){hCE.wxVkey=1
}
var oDE=_v()
_(cBE,oDE)
if(_oz(z,2,e,s,gg)){oDE.wxVkey=1
}
var cEE=_v()
_(cBE,cEE)
if(_oz(z,3,e,s,gg)){cEE.wxVkey=1
}
hCE.wxXCkey=1
oDE.wxXCkey=1
cEE.wxXCkey=1
_(r,cBE)
return r
}
e_[x[40]]={f:m40,j:[],i:[],ti:[],ic:[]}
d_[x[41]]={}
var m41=function(e,s,r,gg){
var z=gz$gwx_42()
return r
}
e_[x[41]]={f:m41,j:[],i:[],ti:[],ic:[]}
d_[x[42]]={}
var m42=function(e,s,r,gg){
var z=gz$gwx_43()
return r
}
e_[x[42]]={f:m42,j:[],i:[],ti:[],ic:[]}
d_[x[43]]={}
var m43=function(e,s,r,gg){
var z=gz$gwx_44()
return r
}
e_[x[43]]={f:m43,j:[],i:[],ti:[],ic:[]}
d_[x[44]]={}
var m44=function(e,s,r,gg){
var z=gz$gwx_45()
return r
}
e_[x[44]]={f:m44,j:[],i:[],ti:[],ic:[]}
d_[x[45]]={}
var m45=function(e,s,r,gg){
var z=gz$gwx_46()
return r
}
e_[x[45]]={f:m45,j:[],i:[],ti:[],ic:[]}
d_[x[46]]={}
var m46=function(e,s,r,gg){
var z=gz$gwx_47()
var oLE=_v()
_(r,oLE)
if(_oz(z,0,e,s,gg)){oLE.wxVkey=1
}
oLE.wxXCkey=1
return r
}
e_[x[46]]={f:m46,j:[],i:[],ti:[],ic:[]}
d_[x[47]]={}
var m47=function(e,s,r,gg){
var z=gz$gwx_48()
var oNE=_v()
_(r,oNE)
if(_oz(z,0,e,s,gg)){oNE.wxVkey=1
}
oNE.wxXCkey=1
return r
}
e_[x[47]]={f:m47,j:[],i:[],ti:[],ic:[]}
d_[x[48]]={}
var m48=function(e,s,r,gg){
var z=gz$gwx_49()
return r
}
e_[x[48]]={f:m48,j:[],i:[],ti:[],ic:[]}
d_[x[49]]={}
var m49=function(e,s,r,gg){
var z=gz$gwx_50()
var hQE=_n('view')
_rz(z,hQE,'class',0,e,s,gg)
var oRE=_v()
_(hQE,oRE)
if(_oz(z,1,e,s,gg)){oRE.wxVkey=1
}
var cSE=_v()
_(hQE,cSE)
if(_oz(z,2,e,s,gg)){cSE.wxVkey=1
}
var oTE=_v()
_(hQE,oTE)
if(_oz(z,3,e,s,gg)){oTE.wxVkey=1
}
var lUE=_v()
_(hQE,lUE)
if(_oz(z,4,e,s,gg)){lUE.wxVkey=1
}
oRE.wxXCkey=1
cSE.wxXCkey=1
oTE.wxXCkey=1
lUE.wxXCkey=1
_(r,hQE)
return r
}
e_[x[49]]={f:m49,j:[],i:[],ti:[],ic:[]}
d_[x[50]]={}
var m50=function(e,s,r,gg){
var z=gz$gwx_51()
var tWE=_v()
_(r,tWE)
if(_oz(z,0,e,s,gg)){tWE.wxVkey=1
}
tWE.wxXCkey=1
return r
}
e_[x[50]]={f:m50,j:[],i:[],ti:[],ic:[]}
d_[x[51]]={}
var m51=function(e,s,r,gg){
var z=gz$gwx_52()
var bYE=_v()
_(r,bYE)
if(_oz(z,0,e,s,gg)){bYE.wxVkey=1
}
bYE.wxXCkey=1
return r
}
e_[x[51]]={f:m51,j:[],i:[],ti:[],ic:[]}
d_[x[52]]={}
var m52=function(e,s,r,gg){
var z=gz$gwx_53()
var x1E=_v()
_(r,x1E)
if(_oz(z,0,e,s,gg)){x1E.wxVkey=1
}
x1E.wxXCkey=1
return r
}
e_[x[52]]={f:m52,j:[],i:[],ti:[],ic:[]}
d_[x[53]]={}
var m53=function(e,s,r,gg){
var z=gz$gwx_54()
return r
}
e_[x[53]]={f:m53,j:[],i:[],ti:[],ic:[]}
d_[x[54]]={}
var m54=function(e,s,r,gg){
var z=gz$gwx_55()
var c4E=_v()
_(r,c4E)
if(_oz(z,0,e,s,gg)){c4E.wxVkey=1
}
var h5E=_v()
_(r,h5E)
if(_oz(z,1,e,s,gg)){h5E.wxVkey=1
}
c4E.wxXCkey=1
h5E.wxXCkey=1
return r
}
e_[x[54]]={f:m54,j:[],i:[],ti:[],ic:[]}
d_[x[55]]={}
var m55=function(e,s,r,gg){
var z=gz$gwx_56()
var c7E=_v()
_(r,c7E)
if(_oz(z,0,e,s,gg)){c7E.wxVkey=1
}
c7E.wxXCkey=1
return r
}
e_[x[55]]={f:m55,j:[],i:[],ti:[],ic:[]}
d_[x[56]]={}
var m56=function(e,s,r,gg){
var z=gz$gwx_57()
var l9E=_n('view')
_rz(z,l9E,'class',0,e,s,gg)
var a0E=_v()
_(l9E,a0E)
if(_oz(z,1,e,s,gg)){a0E.wxVkey=1
}
var tAF=_v()
_(l9E,tAF)
if(_oz(z,2,e,s,gg)){tAF.wxVkey=1
}
var eBF=_v()
_(l9E,eBF)
if(_oz(z,3,e,s,gg)){eBF.wxVkey=1
}
var bCF=_v()
_(l9E,bCF)
if(_oz(z,4,e,s,gg)){bCF.wxVkey=1
}
a0E.wxXCkey=1
tAF.wxXCkey=1
eBF.wxXCkey=1
bCF.wxXCkey=1
_(r,l9E)
return r
}
e_[x[56]]={f:m56,j:[],i:[],ti:[],ic:[]}
d_[x[57]]={}
var m57=function(e,s,r,gg){
var z=gz$gwx_58()
return r
}
e_[x[57]]={f:m57,j:[],i:[],ti:[],ic:[]}
d_[x[58]]={}
var m58=function(e,s,r,gg){
var z=gz$gwx_59()
var oFF=_n('view')
_rz(z,oFF,'class',0,e,s,gg)
var fGF=_v()
_(oFF,fGF)
if(_oz(z,1,e,s,gg)){fGF.wxVkey=1
}
var cHF=_v()
_(oFF,cHF)
if(_oz(z,2,e,s,gg)){cHF.wxVkey=1
}
fGF.wxXCkey=1
cHF.wxXCkey=1
_(r,oFF)
return r
}
e_[x[58]]={f:m58,j:[],i:[],ti:[],ic:[]}
d_[x[59]]={}
var m59=function(e,s,r,gg){
var z=gz$gwx_60()
var oJF=_n('view')
_rz(z,oJF,'class',0,e,s,gg)
var cKF=_v()
_(oJF,cKF)
if(_oz(z,1,e,s,gg)){cKF.wxVkey=1
}
var oLF=_v()
_(oJF,oLF)
if(_oz(z,2,e,s,gg)){oLF.wxVkey=1
}
cKF.wxXCkey=1
oLF.wxXCkey=1
_(r,oJF)
return r
}
e_[x[59]]={f:m59,j:[],i:[],ti:[],ic:[]}
d_[x[60]]={}
var m60=function(e,s,r,gg){
var z=gz$gwx_61()
var aNF=_n('view')
_rz(z,aNF,'class',0,e,s,gg)
var tOF=_v()
_(aNF,tOF)
if(_oz(z,1,e,s,gg)){tOF.wxVkey=1
}
var ePF=_v()
_(aNF,ePF)
if(_oz(z,2,e,s,gg)){ePF.wxVkey=1
}
var bQF=_v()
_(aNF,bQF)
if(_oz(z,3,e,s,gg)){bQF.wxVkey=1
}
tOF.wxXCkey=1
ePF.wxXCkey=1
bQF.wxXCkey=1
_(r,aNF)
return r
}
e_[x[60]]={f:m60,j:[],i:[],ti:[],ic:[]}
d_[x[61]]={}
var m61=function(e,s,r,gg){
var z=gz$gwx_62()
var xSF=_n('view')
_rz(z,xSF,'class',0,e,s,gg)
var oTF=_v()
_(xSF,oTF)
if(_oz(z,1,e,s,gg)){oTF.wxVkey=1
}
var fUF=_v()
_(xSF,fUF)
if(_oz(z,2,e,s,gg)){fUF.wxVkey=1
}
oTF.wxXCkey=1
fUF.wxXCkey=1
_(r,xSF)
return r
}
e_[x[61]]={f:m61,j:[],i:[],ti:[],ic:[]}
d_[x[62]]={}
var m62=function(e,s,r,gg){
var z=gz$gwx_63()
var hWF=_n('view')
_rz(z,hWF,'class',0,e,s,gg)
var oXF=_v()
_(hWF,oXF)
if(_oz(z,1,e,s,gg)){oXF.wxVkey=1
}
var cYF=_v()
_(hWF,cYF)
if(_oz(z,2,e,s,gg)){cYF.wxVkey=1
}
oXF.wxXCkey=1
cYF.wxXCkey=1
_(r,hWF)
return r
}
e_[x[62]]={f:m62,j:[],i:[],ti:[],ic:[]}
d_[x[63]]={}
var m63=function(e,s,r,gg){
var z=gz$gwx_64()
return r
}
e_[x[63]]={f:m63,j:[],i:[],ti:[],ic:[]}
d_[x[64]]={}
var m64=function(e,s,r,gg){
var z=gz$gwx_65()
return r
}
e_[x[64]]={f:m64,j:[],i:[],ti:[],ic:[]}
d_[x[65]]={}
var m65=function(e,s,r,gg){
var z=gz$gwx_66()
return r
}
e_[x[65]]={f:m65,j:[],i:[],ti:[],ic:[]}
d_[x[66]]={}
var m66=function(e,s,r,gg){
var z=gz$gwx_67()
var e4F=_n('view')
_rz(z,e4F,'class',0,e,s,gg)
var b5F=_n('view')
_rz(z,b5F,'class',1,e,s,gg)
var o6F=_v()
_(b5F,o6F)
if(_oz(z,2,e,s,gg)){o6F.wxVkey=1
}
var x7F=_v()
_(b5F,x7F)
if(_oz(z,3,e,s,gg)){x7F.wxVkey=1
var o8F=_v()
_(x7F,o8F)
if(_oz(z,4,e,s,gg)){o8F.wxVkey=1
}
o8F.wxXCkey=1
}
o6F.wxXCkey=1
x7F.wxXCkey=1
_(e4F,b5F)
var f9F=_n('view')
_rz(z,f9F,'class',5,e,s,gg)
var c0F=_v()
_(f9F,c0F)
if(_oz(z,6,e,s,gg)){c0F.wxVkey=1
}
var hAG=_v()
_(f9F,hAG)
if(_oz(z,7,e,s,gg)){hAG.wxVkey=1
var oBG=_v()
_(hAG,oBG)
if(_oz(z,8,e,s,gg)){oBG.wxVkey=1
}
oBG.wxXCkey=1
}
c0F.wxXCkey=1
hAG.wxXCkey=1
_(e4F,f9F)
var cCG=_n('view')
_rz(z,cCG,'class',9,e,s,gg)
var oDG=_v()
_(cCG,oDG)
if(_oz(z,10,e,s,gg)){oDG.wxVkey=1
}
var lEG=_v()
_(cCG,lEG)
if(_oz(z,11,e,s,gg)){lEG.wxVkey=1
var aFG=_v()
_(lEG,aFG)
if(_oz(z,12,e,s,gg)){aFG.wxVkey=1
}
aFG.wxXCkey=1
}
oDG.wxXCkey=1
lEG.wxXCkey=1
_(e4F,cCG)
var tGG=_n('view')
_rz(z,tGG,'class',13,e,s,gg)
var eHG=_v()
_(tGG,eHG)
if(_oz(z,14,e,s,gg)){eHG.wxVkey=1
}
var bIG=_v()
_(tGG,bIG)
if(_oz(z,15,e,s,gg)){bIG.wxVkey=1
var oJG=_v()
_(bIG,oJG)
if(_oz(z,16,e,s,gg)){oJG.wxVkey=1
}
oJG.wxXCkey=1
}
eHG.wxXCkey=1
bIG.wxXCkey=1
_(e4F,tGG)
var xKG=_n('view')
_rz(z,xKG,'class',17,e,s,gg)
var oLG=_v()
_(xKG,oLG)
if(_oz(z,18,e,s,gg)){oLG.wxVkey=1
}
var fMG=_v()
_(xKG,fMG)
if(_oz(z,19,e,s,gg)){fMG.wxVkey=1
var cNG=_v()
_(fMG,cNG)
if(_oz(z,20,e,s,gg)){cNG.wxVkey=1
}
cNG.wxXCkey=1
}
oLG.wxXCkey=1
fMG.wxXCkey=1
_(e4F,xKG)
_(r,e4F)
return r
}
e_[x[66]]={f:m66,j:[],i:[],ti:[],ic:[]}
d_[x[67]]={}
var m67=function(e,s,r,gg){
var z=gz$gwx_68()
var oPG=_v()
_(r,oPG)
if(_oz(z,0,e,s,gg)){oPG.wxVkey=1
}
oPG.wxXCkey=1
return r
}
e_[x[67]]={f:m67,j:[],i:[],ti:[],ic:[]}
d_[x[68]]={}
var m68=function(e,s,r,gg){
var z=gz$gwx_69()
var oRG=_n('view')
_rz(z,oRG,'class',0,e,s,gg)
var lSG=_v()
_(oRG,lSG)
if(_oz(z,1,e,s,gg)){lSG.wxVkey=1
}
var aTG=_v()
_(oRG,aTG)
if(_oz(z,2,e,s,gg)){aTG.wxVkey=1
}
lSG.wxXCkey=1
aTG.wxXCkey=1
_(r,oRG)
return r
}
e_[x[68]]={f:m68,j:[],i:[],ti:[],ic:[]}
d_[x[69]]={}
var m69=function(e,s,r,gg){
var z=gz$gwx_70()
var eVG=_n('view')
_rz(z,eVG,'class',0,e,s,gg)
var oXG=_n('view')
_rz(z,oXG,'class',1,e,s,gg)
var xYG=_v()
_(oXG,xYG)
if(_oz(z,2,e,s,gg)){xYG.wxVkey=1
}
var oZG=_v()
_(oXG,oZG)
if(_oz(z,3,e,s,gg)){oZG.wxVkey=1
}
xYG.wxXCkey=1
oZG.wxXCkey=1
_(eVG,oXG)
var bWG=_v()
_(eVG,bWG)
if(_oz(z,4,e,s,gg)){bWG.wxVkey=1
}
bWG.wxXCkey=1
_(r,eVG)
return r
}
e_[x[69]]={f:m69,j:[],i:[],ti:[],ic:[]}
d_[x[70]]={}
var m70=function(e,s,r,gg){
var z=gz$gwx_71()
var c2G=_n('view')
_rz(z,c2G,'class',0,e,s,gg)
var h3G=_v()
_(c2G,h3G)
if(_oz(z,1,e,s,gg)){h3G.wxVkey=1
}
var o4G=_v()
_(c2G,o4G)
if(_oz(z,2,e,s,gg)){o4G.wxVkey=1
}
h3G.wxXCkey=1
o4G.wxXCkey=1
_(r,c2G)
return r
}
e_[x[70]]={f:m70,j:[],i:[],ti:[],ic:[]}
d_[x[71]]={}
var m71=function(e,s,r,gg){
var z=gz$gwx_72()
var o6G=_v()
_(r,o6G)
if(_oz(z,0,e,s,gg)){o6G.wxVkey=1
}
o6G.wxXCkey=1
return r
}
e_[x[71]]={f:m71,j:[],i:[],ti:[],ic:[]}
d_[x[72]]={}
var m72=function(e,s,r,gg){
var z=gz$gwx_73()
var a8G=_n('view')
_rz(z,a8G,'class',0,e,s,gg)
var t9G=_v()
_(a8G,t9G)
if(_oz(z,1,e,s,gg)){t9G.wxVkey=1
}
var e0G=_v()
_(a8G,e0G)
if(_oz(z,2,e,s,gg)){e0G.wxVkey=1
}
var bAH=_v()
_(a8G,bAH)
if(_oz(z,3,e,s,gg)){bAH.wxVkey=1
}
t9G.wxXCkey=1
e0G.wxXCkey=1
bAH.wxXCkey=1
_(r,a8G)
return r
}
e_[x[72]]={f:m72,j:[],i:[],ti:[],ic:[]}
d_[x[73]]={}
var m73=function(e,s,r,gg){
var z=gz$gwx_74()
var xCH=_n('view')
_rz(z,xCH,'class',0,e,s,gg)
var oDH=_v()
_(xCH,oDH)
if(_oz(z,1,e,s,gg)){oDH.wxVkey=1
}
var fEH=_v()
_(xCH,fEH)
if(_oz(z,2,e,s,gg)){fEH.wxVkey=1
}
var cFH=_v()
_(xCH,cFH)
if(_oz(z,3,e,s,gg)){cFH.wxVkey=1
}
oDH.wxXCkey=1
fEH.wxXCkey=1
cFH.wxXCkey=1
_(r,xCH)
return r
}
e_[x[73]]={f:m73,j:[],i:[],ti:[],ic:[]}
d_[x[74]]={}
var m74=function(e,s,r,gg){
var z=gz$gwx_75()
var oHH=_n('view')
_rz(z,oHH,'class',0,e,s,gg)
var cIH=_v()
_(oHH,cIH)
if(_oz(z,1,e,s,gg)){cIH.wxVkey=1
}
var oJH=_v()
_(oHH,oJH)
if(_oz(z,2,e,s,gg)){oJH.wxVkey=1
}
var lKH=_v()
_(oHH,lKH)
if(_oz(z,3,e,s,gg)){lKH.wxVkey=1
}
cIH.wxXCkey=1
oJH.wxXCkey=1
lKH.wxXCkey=1
_(r,oHH)
return r
}
e_[x[74]]={f:m74,j:[],i:[],ti:[],ic:[]}
d_[x[75]]={}
var m75=function(e,s,r,gg){
var z=gz$gwx_76()
return r
}
e_[x[75]]={f:m75,j:[],i:[],ti:[],ic:[]}
d_[x[76]]={}
d_[x[76]]["head"]=function(e,s,r,gg){
var z=gz$gwx_77()
var b=x[76]+':head'
r.wxVkey=b
gg.f=$gdc(f_["./pages/common/head.wxml"],"",1)
if(p_[b]){_wl(b,x[76]);return}
p_[b]=true
try{
var oB=_n('view')
_rz(z,oB,'class',1,e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,2,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(oB,oD)
if(_oz(z,3,e,s,gg)){oD.wxVkey=1
}
xC.wxXCkey=1
oD.wxXCkey=1
_(r,oB)
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m76=function(e,s,r,gg){
var z=gz$gwx_77()
return r
}
e_[x[76]]={f:m76,j:[],i:[],ti:[],ic:[]}
d_[x[77]]={}
d_[x[77]]["noSupport"]=function(e,s,r,gg){
var z=gz$gwx_78()
var b=x[77]+':noSupport'
r.wxVkey=b
gg.f=$gdc(f_["./pages/common/noSupport.wxml"],"",1)
if(p_[b]){_wl(b,x[77]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
if(_oz(z,1,e,s,gg)){oB.wxVkey=1
}
var xC=_v()
_(r,xC)
if(_oz(z,2,e,s,gg)){xC.wxVkey=1
}
oB.wxXCkey=1
xC.wxXCkey=1
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m77=function(e,s,r,gg){
var z=gz$gwx_78()
return r
}
e_[x[77]]={f:m77,j:[],i:[],ti:[],ic:[]}
d_[x[78]]={}
var m78=function(e,s,r,gg){
var z=gz$gwx_79()
return r
}
e_[x[78]]={f:m78,j:[],i:[],ti:[],ic:[]}
d_[x[79]]={}
var m79=function(e,s,r,gg){
var z=gz$gwx_80()
var xQH=e_[x[79]].i
_ai(xQH,x[80],e_,x[79],1,1)
var oRH=_v()
_(r,oRH)
var fSH=_oz(z,1,e,s,gg)
var cTH=_gd(x[79],fSH,e_,d_)
if(cTH){
var hUH=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
oRH.wxXCkey=3
cTH(hUH,hUH,oRH,gg)
gg.f=cur_globalf
}
else _w(fSH,x[79],4,16)
xQH.pop()
return r
}
e_[x[79]]={f:m79,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[81]]={}
var m80=function(e,s,r,gg){
var z=gz$gwx_81()
var cWH=_mz(z,'ec-canvas',['canvasId',0,'ec',1,'id',1],[],e,s,gg)
_(r,cWH)
return r
}
e_[x[81]]={f:m80,j:[],i:[],ti:[],ic:[]}
d_[x[82]]={}
var m81=function(e,s,r,gg){
var z=gz$gwx_82()
return r
}
e_[x[82]]={f:m81,j:[],i:[],ti:[],ic:[]}
d_[x[83]]={}
var m82=function(e,s,r,gg){
var z=gz$gwx_83()
var aZH=e_[x[83]].i
_ai(aZH,x[80],e_,x[83],1,1)
var t1H=_v()
_(r,t1H)
var e2H=_oz(z,1,e,s,gg)
var b3H=_gd(x[83],e2H,e_,d_)
if(b3H){
var o4H=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
t1H.wxXCkey=3
b3H(o4H,o4H,t1H,gg)
gg.f=cur_globalf
}
else _w(e2H,x[83],4,16)
aZH.pop()
return r
}
e_[x[83]]={f:m82,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[84]]={}
var m83=function(e,s,r,gg){
var z=gz$gwx_84()
var o6H=e_[x[84]].i
_ai(o6H,x[80],e_,x[84],1,1)
var f7H=_v()
_(r,f7H)
var c8H=_oz(z,1,e,s,gg)
var h9H=_gd(x[84],c8H,e_,d_)
if(h9H){
var o0H=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
f7H.wxXCkey=3
h9H(o0H,o0H,f7H,gg)
gg.f=cur_globalf
}
else _w(c8H,x[84],3,16)
o6H.pop()
return r
}
e_[x[84]]={f:m83,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[85]]={}
var m84=function(e,s,r,gg){
var z=gz$gwx_85()
var oBI=_n('view')
_rz(z,oBI,'class',0,e,s,gg)
var lCI=_mz(z,'cg-image',['cgClass',1,'lazyload',1,'src',2],[],e,s,gg)
_(oBI,lCI)
var aDI=_mz(z,'cg-image',['bindload',4,'lazyload',1,'src',2],[],e,s,gg)
_(oBI,aDI)
var tEI=_mz(z,'cg-image',['bindload',7,'lazyload',1,'src',2],[],e,s,gg)
_(oBI,tEI)
var eFI=_mz(z,'cg-image',['lazyload',10,'src',1],[],e,s,gg)
_(oBI,eFI)
var bGI=_mz(z,'cg-image',['bindload',12,'lazyload',1,'src',2],[],e,s,gg)
_(oBI,bGI)
_(r,oBI)
return r
}
e_[x[85]]={f:m84,j:[],i:[],ti:[],ic:[]}
d_[x[86]]={}
var m85=function(e,s,r,gg){
var z=gz$gwx_86()
var xII=e_[x[86]].i
_ai(xII,x[80],e_,x[86],1,1)
var oJI=_n('view')
_rz(z,oJI,'class',0,e,s,gg)
var fKI=_v()
_(oJI,fKI)
var cLI=_oz(z,2,e,s,gg)
var hMI=_gd(x[86],cLI,e_,d_)
if(hMI){
var oNI=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
fKI.wxXCkey=3
hMI(oNI,oNI,fKI,gg)
gg.f=cur_globalf
}
else _w(cLI,x[86],4,16)
var cOI=_v()
_(oJI,cOI)
var oPI=_oz(z,4,e,s,gg)
var lQI=_gd(x[86],oPI,e_,d_)
if(lQI){
var aRI=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
cOI.wxXCkey=3
lQI(aRI,aRI,cOI,gg)
gg.f=cur_globalf
}
else _w(oPI,x[86],5,16)
_(r,oJI)
xII.pop()
return r
}
e_[x[86]]={f:m85,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[87]]={}
var m86=function(e,s,r,gg){
var z=gz$gwx_87()
var eTI=e_[x[87]].i
_ai(eTI,x[80],e_,x[87],1,1)
var bUI=_v()
_(r,bUI)
var oVI=_oz(z,1,e,s,gg)
var xWI=_gd(x[87],oVI,e_,d_)
if(xWI){
var oXI=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
bUI.wxXCkey=3
xWI(oXI,oXI,bUI,gg)
gg.f=cur_globalf
}
else _w(oVI,x[87],4,16)
eTI.pop()
return r
}
e_[x[87]]={f:m86,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[88]]={}
var m87=function(e,s,r,gg){
var z=gz$gwx_88()
var cZI=e_[x[88]].i
_ai(cZI,x[80],e_,x[88],1,1)
var h1I=_v()
_(r,h1I)
var o2I=_oz(z,1,e,s,gg)
var c3I=_gd(x[88],o2I,e_,d_)
if(c3I){
var o4I=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
h1I.wxXCkey=3
c3I(o4I,o4I,h1I,gg)
gg.f=cur_globalf
}
else _w(o2I,x[88],4,16)
cZI.pop()
return r
}
e_[x[88]]={f:m87,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[89]]={}
var m88=function(e,s,r,gg){
var z=gz$gwx_89()
var a6I=e_[x[89]].i
_ai(a6I,x[80],e_,x[89],1,1)
var t7I=_v()
_(r,t7I)
var e8I=_oz(z,1,e,s,gg)
var b9I=_gd(x[89],e8I,e_,d_)
if(b9I){
var o0I=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
t7I.wxXCkey=3
b9I(o0I,o0I,t7I,gg)
gg.f=cur_globalf
}
else _w(e8I,x[89],4,16)
a6I.pop()
return r
}
e_[x[89]]={f:m88,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[90]]={}
var m89=function(e,s,r,gg){
var z=gz$gwx_90()
var oBJ=e_[x[90]].i
_ai(oBJ,x[80],e_,x[90],1,1)
_ai(oBJ,x[91],e_,x[90],2,2)
var fCJ=_n('view')
_rz(z,fCJ,'class',0,e,s,gg)
var cDJ=_v()
_(fCJ,cDJ)
var hEJ=_oz(z,2,e,s,gg)
var oFJ=_gd(x[90],hEJ,e_,d_)
if(oFJ){
var cGJ=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
cDJ.wxXCkey=3
oFJ(cGJ,cGJ,cDJ,gg)
gg.f=cur_globalf
}
else _w(hEJ,x[90],5,16)
var oHJ=_v()
_(fCJ,oHJ)
var lIJ=_oz(z,4,e,s,gg)
var aJJ=_gd(x[90],lIJ,e_,d_)
if(aJJ){
var tKJ=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
oHJ.wxXCkey=3
aJJ(tKJ,tKJ,oHJ,gg)
gg.f=cur_globalf
}
else _w(lIJ,x[90],6,16)
_(r,fCJ)
oBJ.pop()
oBJ.pop()
return r
}
e_[x[90]]={f:m89,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[92]]={}
var m90=function(e,s,r,gg){
var z=gz$gwx_91()
var bMJ=e_[x[92]].i
_ai(bMJ,x[80],e_,x[92],1,1)
var oNJ=_v()
_(r,oNJ)
var xOJ=_oz(z,1,e,s,gg)
var oPJ=_gd(x[92],xOJ,e_,d_)
if(oPJ){
var fQJ=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
oNJ.wxXCkey=3
oPJ(fQJ,fQJ,oNJ,gg)
gg.f=cur_globalf
}
else _w(xOJ,x[92],4,16)
bMJ.pop()
return r
}
e_[x[92]]={f:m90,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[93]]={}
var m91=function(e,s,r,gg){
var z=gz$gwx_92()
var hSJ=e_[x[93]].i
_ai(hSJ,x[80],e_,x[93],1,1)
_ai(hSJ,x[91],e_,x[93],2,2)
var oTJ=_v()
_(r,oTJ)
var cUJ=_oz(z,1,e,s,gg)
var oVJ=_gd(x[93],cUJ,e_,d_)
if(oVJ){
var lWJ=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
oTJ.wxXCkey=3
oVJ(lWJ,lWJ,oTJ,gg)
gg.f=cur_globalf
}
else _w(cUJ,x[93],5,16)
hSJ.pop()
hSJ.pop()
return r
}
e_[x[93]]={f:m91,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[94]]={}
var m92=function(e,s,r,gg){
var z=gz$gwx_93()
return r
}
e_[x[94]]={f:m92,j:[],i:[],ti:[],ic:[]}
d_[x[95]]={}
var m93=function(e,s,r,gg){
var z=gz$gwx_94()
var eZJ=_v()
_(r,eZJ)
if(_oz(z,0,e,s,gg)){eZJ.wxVkey=1
}
eZJ.wxXCkey=1
return r
}
e_[x[95]]={f:m93,j:[],i:[],ti:[],ic:[]}
d_[x[96]]={}
var m94=function(e,s,r,gg){
var z=gz$gwx_95()
return r
}
e_[x[96]]={f:m94,j:[],i:[],ti:[],ic:[]}
d_[x[97]]={}
var m95=function(e,s,r,gg){
var z=gz$gwx_96()
var x3J=e_[x[97]].i
_ai(x3J,x[80],e_,x[97],1,1)
_ai(x3J,x[91],e_,x[97],2,2)
var o4J=_n('view')
_rz(z,o4J,'class',0,e,s,gg)
var f5J=_v()
_(o4J,f5J)
var c6J=_oz(z,2,e,s,gg)
var h7J=_gd(x[97],c6J,e_,d_)
if(h7J){
var o8J=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
f5J.wxXCkey=3
h7J(o8J,o8J,f5J,gg)
gg.f=cur_globalf
}
else _w(c6J,x[97],5,16)
var c9J=_v()
_(o4J,c9J)
var o0J=_oz(z,4,e,s,gg)
var lAK=_gd(x[97],o0J,e_,d_)
if(lAK){
var aBK=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
c9J.wxXCkey=3
lAK(aBK,aBK,c9J,gg)
gg.f=cur_globalf
}
else _w(o0J,x[97],6,16)
_(r,o4J)
x3J.pop()
x3J.pop()
return r
}
e_[x[97]]={f:m95,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[98]]={}
var m96=function(e,s,r,gg){
var z=gz$gwx_97()
var eDK=e_[x[98]].i
_ai(eDK,x[80],e_,x[98],1,1)
var bEK=_v()
_(r,bEK)
var oFK=_oz(z,1,e,s,gg)
var xGK=_gd(x[98],oFK,e_,d_)
if(xGK){
var oHK=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
bEK.wxXCkey=3
xGK(oHK,oHK,bEK,gg)
gg.f=cur_globalf
}
else _w(oFK,x[98],4,16)
eDK.pop()
return r
}
e_[x[98]]={f:m96,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[99]]={}
var m97=function(e,s,r,gg){
var z=gz$gwx_98()
return r
}
e_[x[99]]={f:m97,j:[],i:[],ti:[],ic:[]}
d_[x[100]]={}
var m98=function(e,s,r,gg){
var z=gz$gwx_99()
var hKK=e_[x[100]].i
_ai(hKK,x[80],e_,x[100],1,1)
var oLK=_v()
_(r,oLK)
var cMK=_oz(z,1,e,s,gg)
var oNK=_gd(x[100],cMK,e_,d_)
if(oNK){
var lOK=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
oLK.wxXCkey=3
oNK(lOK,lOK,oLK,gg)
gg.f=cur_globalf
}
else _w(cMK,x[100],4,16)
hKK.pop()
return r
}
e_[x[100]]={f:m98,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[101]]={}
var m99=function(e,s,r,gg){
var z=gz$gwx_100()
return r
}
e_[x[101]]={f:m99,j:[],i:[],ti:[],ic:[]}
d_[x[102]]={}
var m100=function(e,s,r,gg){
var z=gz$gwx_101()
var eRK=e_[x[102]].i
_ai(eRK,x[80],e_,x[102],1,1)
_ai(eRK,x[91],e_,x[102],2,2)
var bSK=_n('view')
_rz(z,bSK,'class',0,e,s,gg)
var oTK=_v()
_(bSK,oTK)
var xUK=_oz(z,2,e,s,gg)
var oVK=_gd(x[102],xUK,e_,d_)
if(oVK){
var fWK=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
oTK.wxXCkey=3
oVK(fWK,fWK,oTK,gg)
gg.f=cur_globalf
}
else _w(xUK,x[102],5,16)
var cXK=_v()
_(bSK,cXK)
var hYK=_oz(z,4,e,s,gg)
var oZK=_gd(x[102],hYK,e_,d_)
if(oZK){
var c1K=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
cXK.wxXCkey=3
oZK(c1K,c1K,cXK,gg)
gg.f=cur_globalf
}
else _w(hYK,x[102],6,16)
var o2K=_n('view')
_rz(z,o2K,'class',5,e,s,gg)
var l3K=_v()
_(o2K,l3K)
if(_oz(z,6,e,s,gg)){l3K.wxVkey=1
}
var a4K=_v()
_(o2K,a4K)
if(_oz(z,7,e,s,gg)){a4K.wxVkey=1
}
l3K.wxXCkey=1
a4K.wxXCkey=1
_(bSK,o2K)
_(r,bSK)
eRK.pop()
eRK.pop()
return r
}
e_[x[102]]={f:m100,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[103]]={}
var m101=function(e,s,r,gg){
var z=gz$gwx_102()
var e6K=e_[x[103]].i
_ai(e6K,x[80],e_,x[103],1,1)
var b7K=_n('view')
_rz(z,b7K,'class',0,e,s,gg)
var o8K=_v()
_(b7K,o8K)
var x9K=_oz(z,2,e,s,gg)
var o0K=_gd(x[103],x9K,e_,d_)
if(o0K){
var fAL=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
o8K.wxXCkey=3
o0K(fAL,fAL,o8K,gg)
gg.f=cur_globalf
}
else _w(x9K,x[103],4,16)
var cBL=_n('view')
_rz(z,cBL,'class',3,e,s,gg)
var hCL=_v()
_(cBL,hCL)
if(_oz(z,4,e,s,gg)){hCL.wxVkey=1
}
var oDL=_v()
_(cBL,oDL)
if(_oz(z,5,e,s,gg)){oDL.wxVkey=1
}
hCL.wxXCkey=1
oDL.wxXCkey=1
_(b7K,cBL)
_(r,b7K)
e6K.pop()
return r
}
e_[x[103]]={f:m101,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[104]]={}
var m102=function(e,s,r,gg){
var z=gz$gwx_103()
var oFL=e_[x[104]].i
_ai(oFL,x[80],e_,x[104],1,1)
_ai(oFL,x[91],e_,x[104],2,2)
var lGL=_n('view')
_rz(z,lGL,'class',0,e,s,gg)
var aHL=_v()
_(lGL,aHL)
var tIL=_oz(z,2,e,s,gg)
var eJL=_gd(x[104],tIL,e_,d_)
if(eJL){
var bKL=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
aHL.wxXCkey=3
eJL(bKL,bKL,aHL,gg)
gg.f=cur_globalf
}
else _w(tIL,x[104],5,16)
var oLL=_v()
_(lGL,oLL)
var xML=_oz(z,4,e,s,gg)
var oNL=_gd(x[104],xML,e_,d_)
if(oNL){
var fOL=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
oLL.wxXCkey=3
oNL(fOL,fOL,oLL,gg)
gg.f=cur_globalf
}
else _w(xML,x[104],6,16)
var cPL=_v()
_(lGL,cPL)
var hQL=_oz(z,6,e,s,gg)
var oRL=_gd(x[104],hQL,e_,d_)
if(oRL){
var cSL=_1z(z,5,e,s,gg) || {}
var cur_globalf=gg.f
cPL.wxXCkey=3
oRL(cSL,cSL,cPL,gg)
gg.f=cur_globalf
}
else _w(hQL,x[104],7,16)
_(r,lGL)
oFL.pop()
oFL.pop()
return r
}
e_[x[104]]={f:m102,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[105]]={}
var m103=function(e,s,r,gg){
var z=gz$gwx_104()
var lUL=e_[x[105]].i
_ai(lUL,x[80],e_,x[105],1,1)
_ai(lUL,x[91],e_,x[105],2,2)
var aVL=_n('view')
_rz(z,aVL,'class',0,e,s,gg)
var tWL=_v()
_(aVL,tWL)
var eXL=_oz(z,2,e,s,gg)
var bYL=_gd(x[105],eXL,e_,d_)
if(bYL){
var oZL=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
tWL.wxXCkey=3
bYL(oZL,oZL,tWL,gg)
gg.f=cur_globalf
}
else _w(eXL,x[105],5,16)
var x1L=_v()
_(aVL,x1L)
var o2L=_oz(z,4,e,s,gg)
var f3L=_gd(x[105],o2L,e_,d_)
if(f3L){
var c4L=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
x1L.wxXCkey=3
f3L(c4L,c4L,x1L,gg)
gg.f=cur_globalf
}
else _w(o2L,x[105],6,16)
var h5L=_n('view')
_rz(z,h5L,'class',5,e,s,gg)
var o6L=_v()
_(h5L,o6L)
if(_oz(z,6,e,s,gg)){o6L.wxVkey=1
}
var c7L=_v()
_(h5L,c7L)
if(_oz(z,7,e,s,gg)){c7L.wxVkey=1
}
var o8L=_v()
_(h5L,o8L)
if(_oz(z,8,e,s,gg)){o8L.wxVkey=1
}
var l9L=_v()
_(h5L,l9L)
if(_oz(z,9,e,s,gg)){l9L.wxVkey=1
}
var a0L=_v()
_(h5L,a0L)
if(_oz(z,10,e,s,gg)){a0L.wxVkey=1
}
o6L.wxXCkey=1
c7L.wxXCkey=1
o8L.wxXCkey=1
l9L.wxXCkey=1
a0L.wxXCkey=1
_(aVL,h5L)
_(r,aVL)
lUL.pop()
lUL.pop()
return r
}
e_[x[105]]={f:m103,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[106]]={}
var m104=function(e,s,r,gg){
var z=gz$gwx_105()
return r
}
e_[x[106]]={f:m104,j:[],i:[],ti:[],ic:[]}
d_[x[107]]={}
var m105=function(e,s,r,gg){
var z=gz$gwx_106()
var bCM=e_[x[107]].i
_ai(bCM,x[80],e_,x[107],1,1)
_ai(bCM,x[91],e_,x[107],2,2)
var oDM=_v()
_(r,oDM)
var xEM=_oz(z,1,e,s,gg)
var oFM=_gd(x[107],xEM,e_,d_)
if(oFM){
var fGM=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
oDM.wxXCkey=3
oFM(fGM,fGM,oDM,gg)
gg.f=cur_globalf
}
else _w(xEM,x[107],5,16)
bCM.pop()
bCM.pop()
return r
}
e_[x[107]]={f:m105,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[108]]={}
var m106=function(e,s,r,gg){
var z=gz$gwx_107()
return r
}
e_[x[108]]={f:m106,j:[],i:[],ti:[],ic:[]}
d_[x[109]]={}
var m107=function(e,s,r,gg){
var z=gz$gwx_108()
var oJM=e_[x[109]].i
_ai(oJM,x[80],e_,x[109],1,1)
var cKM=_n('view')
_rz(z,cKM,'class',0,e,s,gg)
var oLM=_v()
_(cKM,oLM)
var lMM=_oz(z,2,e,s,gg)
var aNM=_gd(x[109],lMM,e_,d_)
if(aNM){
var tOM=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
oLM.wxXCkey=3
aNM(tOM,tOM,oLM,gg)
gg.f=cur_globalf
}
else _w(lMM,x[109],4,16)
var ePM=_v()
_(cKM,ePM)
var bQM=_oz(z,4,e,s,gg)
var oRM=_gd(x[109],bQM,e_,d_)
if(oRM){
var xSM=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
ePM.wxXCkey=3
oRM(xSM,xSM,ePM,gg)
gg.f=cur_globalf
}
else _w(bQM,x[109],5,16)
_(r,cKM)
oJM.pop()
return r
}
e_[x[109]]={f:m107,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[110]]={}
var m108=function(e,s,r,gg){
var z=gz$gwx_109()
var fUM=e_[x[110]].i
_ai(fUM,x[80],e_,x[110],1,1)
_ai(fUM,x[91],e_,x[110],2,2)
var cVM=_v()
_(r,cVM)
var hWM=_oz(z,1,e,s,gg)
var oXM=_gd(x[110],hWM,e_,d_)
if(oXM){
var cYM=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
cVM.wxXCkey=3
oXM(cYM,cYM,cVM,gg)
gg.f=cur_globalf
}
else _w(hWM,x[110],5,16)
fUM.pop()
fUM.pop()
return r
}
e_[x[110]]={f:m108,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[111]]={}
var m109=function(e,s,r,gg){
var z=gz$gwx_110()
return r
}
e_[x[111]]={f:m109,j:[],i:[],ti:[],ic:[]}
d_[x[112]]={}
var m110=function(e,s,r,gg){
var z=gz$gwx_111()
return r
}
e_[x[112]]={f:m110,j:[],i:[],ti:[],ic:[]}
d_[x[113]]={}
var m111=function(e,s,r,gg){
var z=gz$gwx_112()
var t3M=e_[x[113]].i
_ai(t3M,x[80],e_,x[113],1,1)
_ai(t3M,x[91],e_,x[113],2,2)
var e4M=_n('view')
_rz(z,e4M,'class',0,e,s,gg)
var b5M=_v()
_(e4M,b5M)
var o6M=_oz(z,2,e,s,gg)
var x7M=_gd(x[113],o6M,e_,d_)
if(x7M){
var o8M=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
b5M.wxXCkey=3
x7M(o8M,o8M,b5M,gg)
gg.f=cur_globalf
}
else _w(o6M,x[113],5,16)
var f9M=_v()
_(e4M,f9M)
var c0M=_oz(z,4,e,s,gg)
var hAN=_gd(x[113],c0M,e_,d_)
if(hAN){
var oBN=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
f9M.wxXCkey=3
hAN(oBN,oBN,f9M,gg)
gg.f=cur_globalf
}
else _w(c0M,x[113],6,16)
_(r,e4M)
t3M.pop()
t3M.pop()
return r
}
e_[x[113]]={f:m111,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[114]]={}
var m112=function(e,s,r,gg){
var z=gz$gwx_113()
var oDN=e_[x[114]].i
_ai(oDN,x[80],e_,x[114],1,1)
_ai(oDN,x[91],e_,x[114],2,2)
var lEN=_v()
_(r,lEN)
var aFN=_oz(z,1,e,s,gg)
var tGN=_gd(x[114],aFN,e_,d_)
if(tGN){
var eHN=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
lEN.wxXCkey=3
tGN(eHN,eHN,lEN,gg)
gg.f=cur_globalf
}
else _w(aFN,x[114],5,16)
oDN.pop()
oDN.pop()
return r
}
e_[x[114]]={f:m112,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[115]]={}
var m113=function(e,s,r,gg){
var z=gz$gwx_114()
var oJN=_mz(z,'tab',['bindchange',0,'id',1,'scroll',1,'size',2,'tabCur',3,'tabData',4],[],e,s,gg)
_(r,oJN)
var xKN=_mz(z,'swiper',['bindanimationfinish',6,'current',1,'duration',2],[],e,s,gg)
var oLN=_v()
_(xKN,oLN)
var fMN=function(hON,cNN,oPN,gg){
var oRN=_mz(z,'scroll',['bind:more',11,'bind:refresh',1,'emptyShow',2,'end',3,'hasTop',4,'listCount',5,'requesting',6,'topSize',7],[],hON,cNN,gg)
_(oPN,oRN)
return oPN
}
oLN.wxXCkey=4
_2z(z,9,fMN,e,s,gg,oLN,'item','index','index')
_(r,xKN)
return r
}
e_[x[115]]={f:m113,j:[],i:[],ti:[],ic:[]}
d_[x[116]]={}
var m114=function(e,s,r,gg){
var z=gz$gwx_115()
return r
}
e_[x[116]]={f:m114,j:[],i:[],ti:[],ic:[]}
d_[x[117]]={}
var m115=function(e,s,r,gg){
var z=gz$gwx_116()
var tUN=e_[x[117]].i
_ai(tUN,x[80],e_,x[117],1,1)
_ai(tUN,x[91],e_,x[117],2,2)
var eVN=_n('view')
_rz(z,eVN,'class',0,e,s,gg)
var bWN=_v()
_(eVN,bWN)
var oXN=_oz(z,2,e,s,gg)
var xYN=_gd(x[117],oXN,e_,d_)
if(xYN){
var oZN=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
bWN.wxXCkey=3
xYN(oZN,oZN,bWN,gg)
gg.f=cur_globalf
}
else _w(oXN,x[117],5,16)
var f1N=_v()
_(eVN,f1N)
var c2N=_oz(z,4,e,s,gg)
var h3N=_gd(x[117],c2N,e_,d_)
if(h3N){
var o4N=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
f1N.wxXCkey=3
h3N(o4N,o4N,f1N,gg)
gg.f=cur_globalf
}
else _w(c2N,x[117],6,16)
_(r,eVN)
tUN.pop()
tUN.pop()
return r
}
e_[x[117]]={f:m115,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[118]]={}
var m116=function(e,s,r,gg){
var z=gz$gwx_117()
var o6N=e_[x[118]].i
_ai(o6N,x[80],e_,x[118],1,1)
var l7N=_v()
_(r,l7N)
var a8N=_oz(z,1,e,s,gg)
var t9N=_gd(x[118],a8N,e_,d_)
if(t9N){
var e0N=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
l7N.wxXCkey=3
t9N(e0N,e0N,l7N,gg)
gg.f=cur_globalf
}
else _w(a8N,x[118],4,16)
o6N.pop()
return r
}
e_[x[118]]={f:m116,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[119]]={}
var m117=function(e,s,r,gg){
var z=gz$gwx_118()
var oBO=e_[x[119]].i
_ai(oBO,x[80],e_,x[119],1,1)
oBO.pop()
return r
}
e_[x[119]]={f:m117,j:[],i:[],ti:[x[80]],ic:[]}
d_[x[120]]={}
var m118=function(e,s,r,gg){
var z=gz$gwx_119()
var oDO=e_[x[120]].i
_ai(oDO,x[80],e_,x[120],1,1)
_ai(oDO,x[91],e_,x[120],2,2)
var fEO=_n('view')
_rz(z,fEO,'class',0,e,s,gg)
var cFO=_v()
_(fEO,cFO)
var hGO=_oz(z,2,e,s,gg)
var oHO=_gd(x[120],hGO,e_,d_)
if(oHO){
var cIO=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
cFO.wxXCkey=3
oHO(cIO,cIO,cFO,gg)
gg.f=cur_globalf
}
else _w(hGO,x[120],5,16)
var oJO=_v()
_(fEO,oJO)
var lKO=_oz(z,4,e,s,gg)
var aLO=_gd(x[120],lKO,e_,d_)
if(aLO){
var tMO=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
oJO.wxXCkey=3
aLO(tMO,tMO,oJO,gg)
gg.f=cur_globalf
}
else _w(lKO,x[120],6,16)
_(r,fEO)
oDO.pop()
oDO.pop()
return r
}
e_[x[120]]={f:m118,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[121]]={}
var m119=function(e,s,r,gg){
var z=gz$gwx_120()
var bOO=e_[x[121]].i
_ai(bOO,x[80],e_,x[121],1,1)
_ai(bOO,x[91],e_,x[121],2,2)
var oPO=_n('view')
_rz(z,oPO,'class',0,e,s,gg)
var xQO=_v()
_(oPO,xQO)
var oRO=_oz(z,2,e,s,gg)
var fSO=_gd(x[121],oRO,e_,d_)
if(fSO){
var cTO=_1z(z,1,e,s,gg) || {}
var cur_globalf=gg.f
xQO.wxXCkey=3
fSO(cTO,cTO,xQO,gg)
gg.f=cur_globalf
}
else _w(oRO,x[121],5,16)
var hUO=_v()
_(oPO,hUO)
var oVO=_oz(z,4,e,s,gg)
var cWO=_gd(x[121],oVO,e_,d_)
if(cWO){
var oXO=_1z(z,3,e,s,gg) || {}
var cur_globalf=gg.f
hUO.wxXCkey=3
cWO(oXO,oXO,hUO,gg)
gg.f=cur_globalf
}
else _w(oVO,x[121],6,16)
_(r,oPO)
bOO.pop()
bOO.pop()
return r
}
e_[x[121]]={f:m119,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[122]]={}
var m120=function(e,s,r,gg){
var z=gz$gwx_121()
var aZO=e_[x[122]].i
_ai(aZO,x[80],e_,x[122],1,1)
_ai(aZO,x[91],e_,x[122],2,2)
var t1O=_v()
_(r,t1O)
var e2O=_oz(z,1,e,s,gg)
var b3O=_gd(x[122],e2O,e_,d_)
if(b3O){
var o4O=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
t1O.wxXCkey=3
b3O(o4O,o4O,t1O,gg)
gg.f=cur_globalf
}
else _w(e2O,x[122],5,16)
aZO.pop()
aZO.pop()
return r
}
e_[x[122]]={f:m120,j:[],i:[],ti:[x[80],x[91]],ic:[]}
d_[x[123]]={}
var m121=function(e,s,r,gg){
var z=gz$gwx_122()
return r
}
e_[x[123]]={f:m121,j:[],i:[],ti:[],ic:[]}
d_[x[124]]={}
var m122=function(e,s,r,gg){
var z=gz$gwx_123()
var f7O=_mz(z,'i-header',['navHeight',0,'systemHeight',1],[],e,s,gg)
_(r,f7O)
return r
}
e_[x[124]]={f:m122,j:[],i:[],ti:[],ic:[]}
d_[x[125]]={}
var m123=function(e,s,r,gg){
var z=gz$gwx_124()
return r
}
e_[x[125]]={f:m123,j:[],i:[],ti:[],ic:[]}
d_[x[126]]={}
var m124=function(e,s,r,gg){
var z=gz$gwx_125()
return r
}
e_[x[126]]={f:m124,j:[],i:[],ti:[],ic:[]}
d_[x[127]]={}
var m125=function(e,s,r,gg){
var z=gz$gwx_126()
return r
}
e_[x[127]]={f:m125,j:[],i:[],ti:[],ic:[]}
d_[x[128]]={}
var m126=function(e,s,r,gg){
var z=gz$gwx_127()
return r
}
e_[x[128]]={f:m126,j:[],i:[],ti:[],ic:[]}
d_[x[129]]={}
var m127=function(e,s,r,gg){
var z=gz$gwx_128()
return r
}
e_[x[129]]={f:m127,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
return root;
}
}
}


    // appservice.js
    !function(e){var t={};function n(r){if(t[r])return t[r].exports;var o=t[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,n),o.l=!0,o.exports}n.m=e,n.c=t,n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:r})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(n.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)n.d(r,o,function(t){return e[t]}.bind(null,o));return r},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=159)}({159:function(e,t,n){n(63),n(160);var r=n(30),o=n(45),a=o.hasBridge,c=o.isDevtools,i=o.JSCore,s=o.promptForSync,u=o.debug,l=n(161),f=n(165),d=n(173),g=n(174),p=n(50);r.appLaunchInfo&&(__wxConfig.appLaunchInfo=r.appLaunchInfo,u&&console.log("appLaunchInfo: "+JSON.stringify(__wxConfig.appLaunchInfo))),a&&(r.CGBridge={invoke:function(e){p.subscribe(e)}},"undefined"!=typeof window&&(window.CGBridge=r.CGBridge),i&&"function"==typeof i.onReady&&i.onReady(),u&&(console.log("CGBridge created"),c?console.log("sync method: window.sendSync"):s?console.log("sync method: prompt"):r.hasOwnProperty("sendSync")?console.log("sync method: global.sendSync"):i&&i.hasOwnProperty("sendSync")?console.log("sync method: CGJSCore.sendSync"):r.hasOwnProperty("XMLHttpRequest")&&console.log("sync method: XMLHttpRequest")));var h,v,y,k,b,m,S=(h=g(),v=h.subscribe,y=h.triggerSubscribeEvent,k=l(),b=k.on,m=k.triggerOnEvent,{invoke:f(),publish:d(),subscribe:v,on:b,get __triggerOnEvent(){return m},get __triggerSubscribeEvent(){return y}});"undefined"!=typeof window?window.WeixinJSBridge=window.__global.WeixinJSBridge=S:(globalThis.__global=globalThis.__global||{},globalThis.WeixinJSBridge=globalThis.__global.WeixinJSBridge=S)},160:function(e,t,n){var r=n(30);if(void 0===r.atob){var o=function(e){this.message=e};(o.prototype=new Error).name="InvalidCharacterError";var a=function(e){throw new o(e)},c="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",i=/[\t\n\f\r ]/g;r.btoa=function(e){e=String(e),/[^\0-\xFF]/.test(e)&&a("The string to be encoded contains characters outside of the Latin1 range.");for(var t,n,r,o,i=e.length%3,s="",u=-1,l=e.length-i;++u<l;)t=e.charCodeAt(u)<<16,n=e.charCodeAt(++u)<<8,r=e.charCodeAt(++u),s+=c.charAt((o=t+n+r)>>18&63)+c.charAt(o>>12&63)+c.charAt(o>>6&63)+c.charAt(63&o);return 2==i?(t=e.charCodeAt(u)<<8,n=e.charCodeAt(++u),s+=c.charAt((o=t+n)>>10)+c.charAt(o>>4&63)+c.charAt(o<<2&63)+"="):1==i&&(o=e.charCodeAt(u),s+=c.charAt(o>>2)+c.charAt(o<<4&63)+"=="),s},r.atob=function(e){var t=(e=String(e).replace(i,"")).length;t%4==0&&(t=(e=e.replace(/==?$/,"")).length),(t%4==1||/[^+a-zA-Z0-9/]/.test(e))&&a("Invalid character: the string to be decoded is not correctly encoded.");for(var n,r,o=0,s="",u=-1;++u<t;)r=c.indexOf(e.charAt(u)),n=o%4?64*n+r:r,o++%4&&(s+=String.fromCharCode(255&n>>(-2*o&6)));return s}}},161:function(e,t,n){var r=n(50),o=n(64),a=n(65).unpack,c={},i=!1;function s(e,t,n){var r=c[e];"function"==typeof r&&r(a(t),n)}function u(e,t){t&&(c[e]=t)}e.exports=function(){return i||(i=!0,r.registerCallback("APPSERVICE_ON_EVENT",(function(e){var t=e.data,n=e.webviewID;s(t.eventName,a(t.data),n)})),o.on("triggerOnEvent",(function(e,t,n){s(e,t,n)}))),{on:u,triggerOnEvent:s}}},162:function(e,t){function n(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function r(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}var o=0,a=function(){function e(t){var r=this,o=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];n(this,e),this._protocol=t,this._needToken=o,this._ws=null,this._msgQueue=[],this._callbacks={},this.tryTime=0;var a=navigator.userAgent,c=a.match(/port\/(\d*)/);if(!c)throw new Error("port not found in UA");var i=parseInt(c[1]);this.url="ws://127.0.0.1:".concat(i),"complete"==document.readyState?setTimeout((function(){r.connect()})):window.addEventListener("load",(function(){r.connect()}))}var t,a,c;return t=e,(a=[{key:"connect",value:function(){var e=this;if(!(o++>=10)){var t=this._protocol;this._needToken&&(t="".concat(t,"##")),this._ws=new window.__global.WebSocket(this.url,t),this._ws.onopen=function(){var t=[].concat(e._msgQueue);e._msgQueue=[],t.forEach((function(t){e.send(t)}))},this._ws.onclose=function(){e._ws=null,setTimeout((function(){e.tryTime<100&&(e.tryTime++,e.connect())}),150)},this._ws.onmessage=function(t){try{var n=JSON.parse(t.data),r=e._callbacks[n.command];r?r(n):console.error("callback not found for: ".concat(n.command))}catch(t){console.warn("Error: ".concat(t.message))}}}}},{key:"send",value:function(e){this._ws&&this._ws.readyState===window.WebSocket.OPEN?this._ws.send(JSON.stringify(e)):this._msgQueue.push(e)}},{key:"registerCallback",value:function(e,t){this._callbacks[e]?console.error("Callback for ".concat(e," already exists!")):this._callbacks[e]=t}}])&&r(t.prototype,a),c&&r(t,c),e}();e.exports=a},163:function(e,t){function n(e){if(e)return function(e){for(var t in n.prototype)e[t]=n.prototype[t];return e}(e)}n.prototype.on=n.prototype.addEventListener=function(e,t){return this._callbacks=this._callbacks||{},(this._callbacks["$"+e]=this._callbacks["$"+e]||[]).push(t),this},n.prototype.once=function(e,t){function n(){this.off(e,n),t.apply(this,arguments)}return n.fn=t,this.on(e,n),this},n.prototype.off=n.prototype.removeListener=n.prototype.removeAllListeners=n.prototype.removeEventListener=function(e,t){if(this._callbacks=this._callbacks||{},0==arguments.length)return this._callbacks={},this;var n,r=this._callbacks["$"+e];if(!r)return this;if(1==arguments.length)return delete this._callbacks["$"+e],this;for(var o=0;o<r.length;o++)if((n=r[o])===t||n.fn===t){r.splice(o,1);break}return this},n.prototype.emit=function(e){this._callbacks=this._callbacks||{};var t=[].slice.call(arguments,1),n=this._callbacks["$"+e];if(n)for(var r=0,o=(n=n.slice(0)).length;r<o;++r)n[r].apply(this,t);return this},n.prototype.listeners=function(e){return this._callbacks=this._callbacks||{},this._callbacks["$"+e]||[]},n.prototype.hasListeners=function(e){return!!this.listeners(e).length},e.exports=n},164:function(e,t,n){var r=n(30);e.exports={base64ToArrayBuffer:function(e){for(var t=r.atob(e),n=t.length,o=new Uint8Array(n),a=0;a<n;a++)o[a]=t.charCodeAt(a);return o.buffer},arrayBufferToBase64:function(e){for(var t="",n=new Uint8Array(e),o=n.byteLength,a=0;a<o;a++)t+=String.fromCharCode(n[a]);return r.btoa(t)}}},165:function(e,t,n){var r=n(50),o=n(166),a=n(170),c=n(171),i=n(172).sync,s=n(45),u=s.isDevtools,l=s.debug,f=n(63).isSyncSDK,d=n(65),g=d.pack,p=d.unpack,h={},v="undefined"!=typeof window,y=1,k=!1;function b(e,t,n){if("reportKeyValue"===e||"traceEvent"===e||"reportRealtimeAction"===e)return"function"==typeof n?n({errMsg:"".concat(e,":ok")}):void 0;var s=null!=o[e]&&v;s||(t=g(t));var d=f(e),p=m(d,n);if(u&&"function"==typeof a[e]&&!a[e](e,t,n))return p({errMsg:"".concat(e,":fail API check failed")});if(c[e]&&v){l&&console.warn('using api "'.concat(e,'" from appservice.js'));var k=c[e](e,t,n);if(!k)return;t=k}if(s)o[e](e,t,p);else{var b=y++;if(d){l&&console.log("".concat((new Date).toISOString(),"<= send SYNC: ").concat(JSON.stringify({api:e,args:t})));var S=i(e,t);l&&console.log("".concat((new Date).toISOString(),"<= receive SYNC: ").concat(JSON.stringify(S))),p(S)}else h[b]=p,r.send({command:"APPSERVICE_INVOKE",data:{api:e,args:t,callbackID:b}})}}var m=function(e,t){return function(n){var r=p(n);"function"==typeof t&&(e?t(r):setTimeout((function(){t(r)}),0))}};e.exports=function(){return k||(k=!0,r.registerCallback("APPSERVICE_INVOKE_CALLBACK",(function(e){var t=e.data,n=t.callbackID,r=h[n];"function"==typeof r&&(delete h[n],r(t.res))}))),b}},166:function(e,t,n){var r=n(167),o=n(168),a=n(169),c=Object.assign({},r,o,a);e.exports=c},167:function(e,t,n){function r(e){if("undefined"==typeof Symbol||null==e[Symbol.iterator]){if(Array.isArray(e)||(e=function(e,t){if(!e)return;if("string"==typeof e)return o(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);"Object"===n&&e.constructor&&(n=e.constructor.name);if("Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return o(e,t)}(e))){var t=0,n=function(){};return{s:n,n:function(){return t>=e.length?{done:!0}:{done:!1,value:e[t++]}},e:function(e){throw e},f:n}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var r,a,c=!0,i=!1;return{s:function(){r=e[Symbol.iterator]()},n:function(){var e=r.next();return c=e.done,e},e:function(e){i=!0,a=e},f:function(){try{c||null==r.return||r.return()}finally{if(i)throw a}}}}function o(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=new Array(t);n<t;n++)r[n]=e[n];return r}var a=n(64),c=n(63).MaxRequestConcurrent,i=n(30),s=n(45).isDevtools,u={},l=1,f=0,d=__wxConfig.networkTimeout&&__wxConfig.networkTimeout.request||6e4,g=function(e){return function(t){"function"==typeof e&&e(t)}},p=function(e,t,n,r){var o=function(e){setTimeout((function(){f--,"function"==typeof n&&n(e)}))};if(++f>c)return console.error("同时最多发起 ".concat(c," 个 request 请求")),void o({errMsg:"".concat(e,":fail exceed max task count")});var a=t.url,s=t.responseType;s=s||"text";var u=t.method||"POST";if(-1!=["OPTIONS","GET","HEAD","POST","PUT","DELETE","TRACE","CONNECT"].indexOf(u)){var l=t.header||{},g=new i.XMLHttpRequest;for(var p in g.responseType=s,g.timeout=t.timeout||d,g.open(u,a,!0),g.onreadystatechange=function(){if(g.readyState===(g.HEADERS_RECEIVED||2)&&"function"==typeof r)try{var t=y(g.getAllResponseHeaders());r({state:"headersReceived",header:t,cookies:h(t,g.getResponseHeader("cg-cookie"))})}catch(e){console.error(e)}if(4===g.readyState){g.onreadystatechange=null;var n=g.status;if(0==n)return;var a=y(g.getAllResponseHeaders()),c={errMsg:"".concat(e,":ok"),header:a,cookies:h(a||{},g.getResponseHeader("cg-cookie")),statusCode:n};c.data="arraybuffer"===s?g.response:g.responseText,o(c)}},g.onerror=function(){o({errMsg:"".concat(e,":fail")})},g.ontimeout=function(){o({errMsg:"".concat(e,":fail timeout")})},g.onabort=function(){o({errMsg:"".concat(e,":fail abort")})},l){if(l.hasOwnProperty(p))"cookie"===p.toLowerCase()?g.setRequestHeader("_Cookie",l[p]):g.setRequestHeader(p,l[p])}try{"GET"==u?g.send():g.send(t.data)}catch(p){o({errMsg:"".concat(e,":fail ").concat(p.message)})}return g}o({errMsg:"".concat(e,":fail method is invalid")})};function h(e,t){var n=[];for(var o in e)if("set-cookie"===o.toLowerCase()){var a=e[o],c=Object.prototype.toString.call(a);if("[object String]"===c){n.push(a.trim());continue}if("[object Array]"===c){var i,u=r(a);try{for(u.s();!(i=u.n()).done;){var l=i.value;n.push(l.trim())}}catch(e){u.e(e)}finally{u.f()}continue}}return s&&t&&"string"==typeof t&&(n=t.split("||").map((function(e){return e.trim()}))),n}e.exports={request:p,createRequestTask:function(e,t,n){var r=g(n),o={id:l++,url:t.url,data:t.data,header:t.header,method:t.method,callback:function(e,t){var n=0===t.errMsg.indexOf("request:ok")?{requestTaskId:e,state:"success",data:t.data,header:t.header,statusCode:t.statusCode,cookies:t.cookies}:{requestTaskId:e,state:"fail",errMsg:t.errMsg.replace(/^request:fail ?/,"")};delete u[e],a.emit("triggerOnEvent","onRequestTaskStateChange",n)}};r({errMsg:"".concat(e,":ok"),requestTaskId:o.id}),u[o.id]=o,o.xhr=p("request",t,o.callback.bind(void 0,o.id),(function(e){a.emit("triggerOnEvent","onRequestTaskStateChange",Object.assign({},e,{requestTaskId:o.id}))}))},operateRequestTask:function(e,t,n){var r=g(n),o=t.requestTaskId,a=t.operationType,c=u[o];if(!c)return r({errMsg:"".concat(e,":fail task not found")});if("abort"!==a)return r({errMsg:"".concat(e,":fail illegal operationType ").concat(a)});try{c.xhr.abort(),r({errMsg:"".concat(e,":ok")})}catch(t){r({errMsg:"".concat(e,":fail ").concat(t)})}}};var v=function(e){return e.replace(/^\s+|\s+$/g,"")};function y(e){if(!e)return{};for(var t,n={},r=v(e).split("\n"),o=0;o<r.length;o++){var a=r[o],c=a.indexOf(":"),i=v(a.slice(0,c)).toLowerCase(),u=v(a.slice(c+1));s&&"cg-cookie"==i||(void 0===n[i]?n[i]=u:(t=n[i],"[object Array]"===Object.prototype.toString.call(t)?n[i].push(u):n[i]=[n[i],u]))}return n}},168:function(e,t){var n={0:"log",1:"info",2:"warn",3:"error"};e.exports={reportKeyValue:function(e,t,n){n({errMsg:"".concat(e,":ok")})},reportIDKey:function(e,t,n){n({errMsg:"".concat(e,":ok")})},log:function(e,t){(t.dataArray||[]).forEach((function(e){var t=n[e.level];t&&e.msg&&console[t](e.msg)}))}}},169:function(e,t,n){var r,o=n(64),a=n(30),c={},i="未完成操作",s=1,u=a.WebSocket,l=function(e){return function(t){"function"==typeof e&&e(t)}},f={1e3:"normal closure",1001:"going away",1002:"protocol error",1003:"unsupported data",1004:"reserved",1005:"no status rcvd",1006:"abnormal closure",1007:"invalid frame payload data",1008:"policy violation",1009:"message too big",1010:"mandatory ext.",1011:"internal server error",1015:"tls handshake"},d=__wxConfig.networkTimeout&&__wxConfig.networkTimeout.connectSocket||1e4;e.exports={connectSocket:function(e,t,n){var c=t.url,s=l(n);if(!1===a.navigator.onLine)return console.error("无网络状态"),void s({errMsg:"".concat(e,":fail network is down")});if(!r||r.readyState!==u.OPEN&&r.readyState!==u.CONNECTING){try{r=new u(c,t.protocols||[])}catch(e){o.emit("triggerOnEvent","onSocketError",{errMsg:i}),r=null}return r?(r.binaryType="arraybuffer",r.onopen=function(){o.emit("triggerOnEvent","onSocketOpen",{})},r.onmessage=function(e){o.emit("triggerOnEvent","onSocketMessage",{data:e.data})},r.onclose=function(e){o.emit("triggerOnEvent","onSocketClose",{code:e.code,reason:e.reason||f[e.code]||""}),r=null},r.onerror=function(){o.emit("triggerOnEvent","onSocketError",{errMsg:"未完成的操作"}),r=null},void s({errMsg:"connectSocket:ok"})):void s({errMsg:"connectSocket:fail"})}s({errMsg:"connectSocket:fail websocket is connected"})},sendSocketMessage:function(e,t,n){var o=l(n),a=t.data,c="fail";if(r)try{r.readyState===u.OPEN?(r.send(a),c="ok"):c="fail webSocket is not connected"}catch(t){c="fail ".concat(t.message)}o({errMsg:"".concat(e,":").concat(c)})},closeSocket:function(e,t,n){var o=l(n);if(r)try{r.close(t.code,t.reason),o({errMsg:"closeSocket:ok"})}catch(t){o({errMsg:"closeSocket:fail ".concat(t)})}else o({errMsg:"closeSocket:fail"});r=void 0},createSocketTask:function(e,t,n){var r=l(n),a=t.url,g=t.header,p=t.protocols,h=s++,v={socketTaskId:h,url:a,protocols:p,header:g};r({socketTaskId:h,errMsg:"".concat(e,":ok")}),c[h]=v;var y,k=!1;try{y=new u(a,t.protocols||[])}catch(e){if(k)return;o.emit("triggerOnEvent","onSocketTaskStateChange",{socketTaskId:h,state:"error",errMsg:i}),delete c[h]}if(y){var b=setTimeout((function(){k=!0,o.emit("triggerOnEvent","onSocketTaskStateChange",{socketTaskId:h,state:"error",errMsg:"Timed out connecting to server."}),delete c[h],y&&y.close()}),d);y.binaryType="arraybuffer",y.onopen=function(){clearTimeout(b),o.emit("triggerOnEvent","onSocketTaskStateChange",{socketTaskId:h,state:"open"})},y.onmessage=function(e){if(!k){var t=e.data;o.emit("triggerOnEvent","onSocketTaskStateChange",{socketTaskId:h,data:t,state:"message"})}},y.onclose=function(e){k||(o.emit("triggerOnEvent","onSocketTaskStateChange",{socketTaskId:h,state:"close",code:e.code,reason:e.reason||f[e.code]||""}),delete c[h])},y.onerror=function(){k||(o.emit("triggerOnEvent","onSocketTaskStateChange",{socketTaskId:h,state:"error",errMsg:i}),delete c[h])},v.socket=y}},operateSocketTask:function(e,t,n){var r=t.socketTaskId,o=t.operationType,a=t.code,i=t.reason,s=t.data,f=l(n),d=c[r];if(!d)return f({errMsg:"".concat(e,":fail task not found")});if(-1==["send","close"].indexOf(o))return f({errMsg:"".concat(e,":fail illegal operationType ").concat(o)});if("close"==o)try{d.socket.close(a,i),f({errMsg:"".concat(e,":ok")})}catch(n){f({errMsg:"".concat(e,":fail ").concat(n.message)})}else try{d.socket.readyState===u.OPEN?(d.socket.send(s),f({errMsg:"".concat(e,":ok")})):f({errMsg:"".concat(e,":fail webSocket is not connected")})}catch(n){f({errMsg:"".concat(e,":fail ").concat(n.message)})}}}},170:function(e,t,n){var r=n(63).canNotReadFromCodePackage;e.exports={readFile:function(e,t){var n=t.filePath;if(0!==n.indexOf("file:")){var o=n.split("."),a=1<o.length?o[o.length-1]:"";if(a&&r[a])return console.group("".concat(new Date," 读取文件失败")),console.info("无法读取 ".concat(n," 文件，该文件经过编译后在移动设备上不存在")),console.groupEnd(),!1}return!0},operateWXData:function(e,t){return t.data&&"webapi_getuserinfo"===t.data.api_name&&!t.data.from_component&&(console.group("".concat(new Date," 接口调整")),console.warn("获取 wx.getUserInfo 接口后续将不再出现授权弹窗，请注意升级\n参考文档: https://developers.weixin.qq.com/blogdetail?action=get_post_info&lang=zh_CN&token=1650183953&docid=0000a26e1aca6012e896a517556c01"),console.groupEnd()),!0},authorize:function(e,t){return"scope.userInfo"===t.scope&&(console.group("".concat(new Date," 接口调整")),console.error('wx.authorize({scope: "scope.userInfo"}) 不会出现授权弹窗，请使用 <button open-type="getUserInfo />\n参考文档: https://developers.weixin.qq.com/blogdetail?action=get_post_info&lang=zh_CN&token=1650183953&docid=0000a26e1aca6012e896a517556c01'),console.groupEnd()),!0}}},171:function(e,t,n){var r=n(30),o=function(e,t,n){if("undefined"==typeof window)return t;var o=t.canvasId,a=function(){n({errMsg:"".concat(e,":fail canvas not found")})};if(!o)return/Sync$/.test(e)?a():setTimeout(a,10);var c=t.x,i=void 0===c?0:c,s=t.y,u=void 0===s?0:s,l=t.width,f=void 0===l?o.width:l,d=t.height,g=void 0===d?o.height:d,p=t.fileType,h=void 0===p?"png":p,v=r.document.createElement("canvas");Object.setPrototypeOf(v,r.canvasProto);var y=t.destWidth?t.destWidth:f,k=t.destHeight?t.destHeight:g;v.width=y,v.height=k;var b=v.getContext("2d");b&&(Object.setPrototypeOf(b,r.canvas2dContextProto),b.drawImage(o,i,u,f,g,0,0,y,k));var m="jpg"===h?"image/jpeg":"image/png",S=isNaN(t.quality)?1:0<t.quality&&1>=t.quality?t.quality:1;return{dataURL:v.toDataURL(m,S).replace(/^data:image\/(jpg|jpeg|png);base64,/,""),fileType:h}};e.exports={canvasToTempFilePath:o,canvasToTempFilePathSync:o}},172:function(e,t,n){var r=n(30),o=n(45),a=o.JSCore,c=o.isIos,i=o.isDevtools,s=o.promptForSync,u=o.debug,l=r.navigator.userAgent;e.exports={sync:function(e,t){if(i)try{return window.sendSync(e,t)}catch(t){return u&&console.error(t),{errMsg:"".concat(e,":fail ").concat(t.message)}}if(s)try{var n=window.prompt(JSON.stringify({api:e,args:t}));return JSON.parse(n)}catch(t){return u&&console.error(t),{errMsg:"".concat(e,":fail ").concat(t.message)}}if(r.hasOwnProperty("sendSync"))try{return r.sendSync(JSON.stringify({api:e,args:t}))}catch(t){return u&&console.error(t),{errMsg:"".concat(e,":fail ").concat(t.message)}}if(a&&a.hasOwnProperty("sendSync"))try{var o=a.sendSync(JSON.stringify({api:e,args:t}));return JSON.parse(o)}catch(t){return u&&console.error(t),{errMsg:"".concat(e,":fail ").concat(t.message)}}if(!r.hasOwnProperty("XMLHttpRequest"))throw new Error("XMLHttpRequest method not exists");var f=new r.XMLHttpRequest,d={api:e,args:t,t:Date.now(),cg_oauth_client_id:r.cg_oauth_client_id||"",userAgent:l||""},g=encodeURIComponent(JSON.stringify(d));return f.open("POST","/apihelper/assdk?t=".concat(g),!1),c?f.send():f.send(JSON.stringify({api:e,args:t})),200===f.status?JSON.parse(f.responseText):{errMsg:"".concat(e,":fail")}}}},173:function(e,t,n){var r=n(50),o=n(45),a=o.isDevtools,c=o.isGame,i=n(65).pack;function s(e,t,n,o){a&&!c&&("appDataChange"===e||"pageInitData"===e||"__updateAppData"===e||o?"invokeWebviewMethod"===e&&t&&t.data&&"appDataChange"===t.data.name?(u&&r.send({command:"SEND_APP_DATA",data:__wxAppData}),u=!0):"vdSync"!==e&&"vdSyncBatch"!==e||(u&&r.send({command:"SEND_APP_DATA",data:__wxAppData}),u=!0):r.send({command:"SEND_APP_DATA",data:__wxAppData})),r.send({command:"APPSERVICE_PUBLISH",data:{eventName:e,data:i(t),webviewIds:n}})}var u=!0,l=!1;e.exports=function(){return l||(l=!0,a&&!c&&(r.registerCallback("WRITE_APP_DATA",(function(e){var t=e.data,n={},r=getCurrentPages();for(var o in r.forEach((function(e){n[e.__route__||e.route]=e})),t){var a=t[o],c=a.__webviewId__;for(var i in n[o]&&"function"==typeof n[o].setData?(u=!1,n[o].setData(a)):s("appDataChange",{data:{data:a}},[c],!0),Object.assign(__wxAppData[o],a),__wxAppData[o])void 0===a[i]&&delete __wxAppData[o][i]}})),r.registerCallback("GET_APP_DATA",(function(){r.send({command:"SEND_APP_DATA",data:__wxAppData})})))),s}},174:function(e,t,n){var r=n(64),o=n(50),a={},c=n(65).unpack;function i(e,t,n){var r=a[e];"function"==typeof r&&r(c(t),n)}function s(e,t){a[e]=t}var u=!1;e.exports=function(){return u||(u=!0,o.registerCallback("WEBVIEW_PUBLISH",(function(e){var t=e.data,n=e.fromWebviewID;i(t.eventName,t.data,n)})),r.on("triggerSubscribeEvent",(function(e,t,n){i(e,t,n)}))),{subscribe:s,triggerSubscribeEvent:i}}},30:function(e,t){e.exports="undefined"==typeof window?globalThis:window.__global},45:function(e,t,n){var r=n(30),o=r.navigator.userAgent;t.isIos=-1===o.indexOf("CG-Devtools")&&/(iPhone|iPad)/.test(o),t.isDevtools=-1!==o.indexOf("CG-Devtools"),t.isGame=-1!==o.indexOf("gameservice"),t.hasBridge=-1!==o.indexOf("CGBRIDGE"),t.JSCore=r.CGJSCore||null,t.debug=-1!==o.indexOf(" DEBUG"),t.development=-1!==o.indexOf("DEVELOPMENT"),t.promptForSync=-1!==o.indexOf(" PROMPT")&&"undefined"!=typeof window,t.useBundle="undefined"==typeof window},50:function(e,t,n){var r,o=n(30),a=n(45),c=a.JSCore,i=a.isDevtools,s=a.isGame,u=a.debug,l=a.hasBridge,f={};if(l)r={send:function(e){if(u&&console.log("".concat((new Date).toISOString(),"<= send: ").concat(JSON.stringify(e))),c)c.handle(JSON.stringify(e));else{if(!o.webkit)throw new Error("CGJSCore and webkit not found");o.webkit.messageHandlers.handle.postMessage(JSON.stringify(e))}},registerCallback:function(e,t){f[e]?console.error('callback for "'.concat(e,'" already exists.')):f[e]=t},subscribe:function(e){u&&console.log("".concat((new Date).toISOString(),"=> handle: ").concat(JSON.stringify(e)));var t=f[e.command];t?t(e):console.warn('callback for "'.concat(e.command,'" not registed!'))}};else{var d=new(n(162))(s?"GAMESERVICE":"APPSERVICE");r={send:function(e){d.send(e)},registerCallback:function(e,t){d.registerCallback(e,t)},subscribe:function(){throw new Error("should not call subscribe when using socket")}},i&&(o.handler=r)}e.exports=r},63:function(e,t){var n={measureText:!0,getSystemInfo:!0,getBatteryInfo:!0,getBackgroundAudioState:!0,setBackgroundAudioState:!0,operateBackgroundAudio:!0,createRequestTask:!0,createUploadTask:!0,createDownloadTask:!0,createSocketTask:!0,operateSocketTask:!0,createAudioInstance:!0,unlink:!0,createLoadSubPackageTask:!0,getMenuButtonBoundingClientRect:!0,getPermissionBytes:!0,createUDPSocket:!0,bindUDPSocket:!0,createLockStep:!0};e.exports={syncSDKList:n,isDebug:!1,isSyncSDK:function(e){return!!n[e]||/Sync$/.test(e)},MaxRequestConcurrent:10,MaxWebsocketConnect:20,canNotReadFromCodePackage:{js:!0,wxss:!0,wxml:!0}}},64:function(e,t,n){var r=n(163);e.exports=new r},65:function(e,t,n){function r(e){if("undefined"==typeof Symbol||null==e[Symbol.iterator]){if(Array.isArray(e)||(e=function(e,t){if(!e)return;if("string"==typeof e)return o(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);"Object"===n&&e.constructor&&(n=e.constructor.name);if("Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return o(e,t)}(e))){var t=0,n=function(){};return{s:n,n:function(){return t>=e.length?{done:!0}:{done:!1,value:e[t++]}},e:function(e){throw e},f:n}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var r,a,c=!0,i=!1;return{s:function(){r=e[Symbol.iterator]()},n:function(){var e=r.next();return c=e.done,e},e:function(e){i=!0,a=e},f:function(){try{c||null==r.return||r.return()}finally{if(i)throw a}}}}function o(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=new Array(t);n<t;n++)r[n]=e[n];return r}var a=n(164),c=a.arrayBufferToBase64,i=a.base64ToArrayBuffer;function s(e){return Object.prototype.toString.call(e).split(" ")[1].split("]")[0]}t.pack=function(e){if(null==e)return e;var t=[];for(var n in e){var r=e[n];null!=r&&"ArrayBuffer"===s(r)&&0!=r.byteLength&&t.push({key:n,base64:c(r)})}if(t.length>0){for(var o=0;o<t.length;o++){delete e[t[o].key]}e.__nativeBuffers__=t}return e},t.unpack=function(e){if(null==e)return e;var t=e.__nativeBuffers__;if(t&&t.length){delete e.__nativeBuffers__;var n,o=r(t);try{for(o.s();!(n=o.n()).done;){var a=n.value;if(null!=a){var c=i(a.base64);c&&s(c);var u=a.base64;e[a.key]=i(u)}}}catch(e){o.e(e)}finally{o.f()}}return e}}});