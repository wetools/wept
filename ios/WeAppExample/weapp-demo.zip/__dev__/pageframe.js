"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

!function (e) {
  function t(o) {
    if (n[o]) return n[o].exports;
    var i = n[o] = {
      i: o,
      l: !1,
      exports: {}
    };
    return e[o].call(i.exports, i, i.exports, t), i.l = !0, i.exports;
  }

  var n = {};
  t.m = e, t.c = n, t.d = function (e, n, o) {
    t.o(e, n) || Object.defineProperty(e, n, {
      enumerable: !0,
      get: o
    });
  }, t.r = function (e) {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
      value: "Module"
    }), Object.defineProperty(e, "__esModule", {
      value: !0
    });
  }, t.t = function (e, n) {
    if (1 & n && (e = t(e)), 8 & n) return e;
    if (4 & n && "object" == _typeof(e) && e && e.__esModule) return e;
    var o = Object.create(null);
    if (t.r(o), Object.defineProperty(o, "default", {
      enumerable: !0,
      value: e
    }), 2 & n && "string" != typeof e) for (var i in e) {
      t.d(o, i, function (t) {
        return e[t];
      }.bind(null, i));
    }
    return o;
  }, t.n = function (e) {
    var n = e && e.__esModule ? function () {
      return e.default;
    } : function () {
      return e;
    };
    return t.d(n, "a", n), n;
  }, t.o = function (e, t) {
    return Object.prototype.hasOwnProperty.call(e, t);
  }, t.p = "", t(t.s = 221);
}({
  21: function _(e) {
    var t = window.navigator || window.__global.navigator,
        n = window.WebSocket || window.__global.WebSocket,
        o = window.prompt || window.__global.prompt,
        i = t.userAgent.match(/port\/(\d*)/),
        s = "ws://127.0.0.1:".concat(i ? parseInt(i[1]) : 9974);
    var c = 0;

    e.exports =
    /*#__PURE__*/
    function () {
      function _class(e) {
        var _this = this;

        var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !0;

        _classCallCheck(this, _class);

        this._protocol = e, this._needToken = t, this._ws = null, this._msgQueue = [], this._callback = [], "complete" == document.readyState ? setTimeout(function () {
          _this.connect();
        }) : window.addEventListener("load", function () {
          _this.connect();
        });
      }

      _createClass(_class, [{
        key: "connect",
        value: function connect() {
          var _this2 = this;

          if (c++ >= 10) return;
          var e = this._protocol;

          if (this._needToken) {
            e = "".concat(e, "#").concat(o("GET_MESSAGE_TOKEN"), "#");
          }

          this._ws = new n(s, e), this._ws.onopen = function () {
            var e = [].concat(_this2._msgQueue);
            _this2._msgQueue = [], e.forEach(function (e) {
              _this2.send(e);
            });
          }, this._ws.onclose = function () {
            _this2._ws = null, setTimeout(function () {
              _this2.connect();
            }, 100);
          }, this._ws.onmessage = function (e) {
            try {
              var _t = JSON.parse(e.data);

              _this2._callback.forEach(function (e) {
                try {
                  e.call(_this2, _t);
                } catch (e) {}
              });
            } catch (e) {}
          };
        }
      }, {
        key: "send",
        value: function send(e) {
          this._ws && this._ws.readyState === n.OPEN ? this._ws.send(JSON.stringify(e)) : this._msgQueue.push(e);
        }
      }, {
        key: "registerCallback",
        value: function registerCallback(e) {
          "function" == typeof e && this._callback.push(e);
        }
      }]);

      return _class;
    }();
  },
  221: function _(e, t, n) {
    "use strict";

    function o() {
      window.WeixinJSBridge = {
        on: i.default(),
        invoke: s.default(),
        publish: c.default,
        subscribe: l.default()
      }, u.default.init();
      var e = document.createEvent("UIEvent");
      e.initEvent("WeixinJSBridgeReady", !1, !1), document.dispatchEvent(e), a.default.init();
    }

    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var i = n(222),
        s = n(223),
        c = n(226),
        l = n(227),
        u = n(228),
        a = n(60);
    "complete" === document.readyState ? o() : window.addEventListener("load", function () {
      o();
    });
  },
  222: function _(e, t, n) {
    "use strict";

    function o(e, t) {
      t && (c[e] = t);
    }

    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var i = n(32),
        s = n(45),
        c = {};
    var l = !1;

    var u = function u() {
      l || (l = !0, i.default.registerCallback(function (e) {
        var t = e.command,
            n = e.data;
        "WEBVIEW_ON_EVENT" === t && function (e, t) {
          var n = c[e];
          "function" == typeof n && n(t, s.default.webviewID);
        }(n.eventName, n.data);
      }));
    };

    t.default = function () {
      return u(), o;
    };
  },
  223: function _(e, t, n) {
    "use strict";

    function o(e, t, n) {
      if ("disableScrollBounce" === e) return void s.default.togglePullDownRefresh(t.disable);
      var o = l++;
      c[o] = n, i.default.send({
        command: "WEBVIEW_INVOKE",
        data: {
          api: e,
          args: t,
          callbackID: o
        }
      });
    }

    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var i = n(32),
        s = n(60),
        c = {};
    var l = 1,
        u = !1;

    t.default = function () {
      return u || (u = !0, i.default.registerCallback(function (e) {
        var t = e.command,
            n = e.data;

        if ("WEBVIEW_INVOKE_CALLBACK" === t) {
          var _e = n.callbackID,
              _t2 = c[_e];
          "function" == typeof _t2 && _t2(n.res), delete c[_e];
        }
      })), o;
    };
  },
  224: function _(e, t) {
    "use strict";

    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = "data:image/gif;base64,R0lGODlhQAAMAMQZAPT09Orq6ubm5unp6dPT06ysrPz8/NbW1q+vr9fX1+vr687Ozv39/fr6+tXV1Z6ens3NzZ2dnZubm66urpycnKurq+Xl5czMzJmZmf///wAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NTc3MiwgMjAxNC8wMS8xMy0xOTo0NDowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDphODFiMWQ5My0wMDIwLTRiYmItYjVlMS04YjI4NTFkMzMzMjIiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MjFEQzRGRkU4NkU4MTFFNjkwOTg4NjNGN0JEMzY0OTUiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MjFEQzRGRkQ4NkU4MTFFNjkwOTg4NjNGN0JEMzY0OTUiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDplY2RjM2MyNC03NDBkLTQ1NzMtOTc0Ni1iZGQ2MzhlMjEyYjUiIHN0UmVmOmRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo3MGUzZDU2Ny1jZTk1LTExNzktYWFmZC04MmQ1NzRhYmI2YzIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvKycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KRkI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllYV1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAfHh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQJFAAZACwAAAAAQAAMAAAFvmCWMQTyPAjBiGzrukOyLMnw3jegCIICtIACZkgs/HC3xuHCbB4ayJshYKlaA4aRkMgtZKOtZXPsALuo1nQgQ+C6MQSzaDCuX2xyQHpvASDeXAhyGQl2YwmDCnxpChKARBSDEIZNEIMCi1YCjo8YD5KUTAuXmVUCf52CcoWhiHKKpQptnXFydKF4ZnqlAAZbbxVfcg6UZYMZaHxrGUFvRscZSnYOUMdTysIkExEREyrQLAMHMwe54AABPAFHGSEAIfkECRQAGQAsAAAAAEAADAAABb9gJgKKICiAqK4syxDI8yAE097tkCxLMqyGgGVIDBhwOEABw2wWUshW43CpWg8NkZDIDURdy6a4cPyqqNa0IwPgui1QM0FMxxDMokF6fxko3lwKeBkIdWIIgwl8aQkCgEQCgxKGTRSDEItWEI6PFpF4k5QYD5eZVQt/nYJ4haKIeIqmCW2dcV9zond4eqY/W29egwZhdRVleA6ZaxlBwMd4SnVPgyJTfA5ZKgABJgG21C8TERETNdQrAwc8Bz8iIQAh+QQFFAAZACwAAAAAQAAMAAAFv2AmDsmyJIOormwLKIKgAG3dMgTyPAjBqI3DZUg8NGw2Q8DCbAYMyBqggKlaC7SMkMh1RFvLpjjwXTGo1nTBMOC6L6lyBiCuW7JlQnqPISTeXAlyGQp2YgqDCHxpCBCARBCDAoZNAoMSi1YUjo8XC5KUTJZymJkYD3+dgnKFoYhyiqYIbZ1xZXSheF96pgQZDo9egxlhdmSDBmh8FVBBbw5Hw0rGUMNTfFgrAwcmB7bDIgABMQG6wzgTERETPiIhADs=";
  },
  225: function _(e, t) {
    "use strict";

    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = "data:image/gif;base64,R0lGODlhQAAMAIABAP///////yH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NTc3MiwgMjAxNC8wMS8xMy0xOTo0NDowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDphODFiMWQ5My0wMDIwLTRiYmItYjVlMS04YjI4NTFkMzMzMjIiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6M0Q5MjI2RkE4NkU1MTFFNkFDRDc5Mjc3OTE2NjVFRTMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6M0Q5MjI2Rjk4NkU1MTFFNkFDRDc5Mjc3OTE2NjVFRTMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDphODFiMWQ5My0wMDIwLTRiYmItYjVlMS04YjI4NTFkMzMzMjIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6YTgxYjFkOTMtMDAyMC00YmJiLWI1ZTEtOGIyODUxZDMzMzIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Af/+/fz7+vn49/b19PPy8fDv7u3s6+rp6Ofm5eTj4uHg397d3Nva2djX1tXU09LR0M/OzczLysnIx8bFxMPCwcC/vr28u7q5uLe2tbSzsrGwr66trKuqqainpqWko6KhoJ+enZybmpmYl5aVlJOSkZCPjo2Mi4qJiIeGhYSDgoGAf359fHt6eXh3dnV0c3JxcG9ubWxramloZ2ZlZGNiYWBfXl1cW1pZWFdWVVRTUlFQT05NTEtKSUhHRkVEQ0JBQD8+PTw7Ojk4NzY1NDMyMTAvLi0sKyopKCcmJSQjIiEgHx4dHBsaGRgXFhUUExIREA8ODQwLCgkIBwYFBAMCAQAAIfkECRQAAQAsAAAAAEAADAAAAkVMgInG7a7Wmy+CZhWlOe3ZLaH3YWEJnaOErhd6uCscj7Q8w+6Nn3re6nV4tp/QQvQFjxFaLeN8IqVNZzE5pbKi2SiVUQAAIfkECRQAAQAsAAAAAEAADAAAAkWMgWnL3QmBmy7KZSGlWe3aXeH1YSNZBqN6pkfrnjL6yS47h7cd53q/AvosO1hq2CkGj60l01kKQqM/ZYZBvGGvWpPGUAAAIfkEBRQAAQAsAAAAAEAADAAAAkWMgWnL7amcbBCuWufEVj+OHCDgfWDJjGqGBivZvm/rrrRsxzmKq/de6o1+Pp0QQxwah8Uk0smpnWjSKLVZDVFTrG02UgAAOw==";
  },
  226: function _(e, t, n) {
    "use strict";

    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var o = n(32);

    t.default = function (e, t) {
      o.default.send({
        command: "WEBVIEW_PUBLISH",
        data: {
          eventName: e,
          data: t
        }
      });
    };
  },
  227: function _(e, t, n) {
    "use strict";

    function o(e, t) {
      s[e] = t;
    }

    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var i = n(32),
        s = {};
    var c = !1;

    var l = function l() {
      c || (c = !0, i.default.registerCallback(function (e) {
        var t = e.command,
            n = e.data,
            o = e.webviewID;
        "APPSERVICE_PUBLISH" === t && function (e, t, n) {
          var o = s[e];
          "function" == typeof o && o(t, n);
        }(n.eventName, n.data, o);
      }));
    };

    t.default = function () {
      return l(), o;
    };
  },
  228: function _(e, t, n) {
    "use strict";

    Object.defineProperty(t, "__esModule", {
      value: !0
    });

    var o = n(32),
        i = n(45),
        s = 0,
        c = 7,
        l = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver,
        u = function () {
      var e = {},
          t = new WeakMap(),
          n = function n(_n) {
        var o = t.get(_n);
        return o && (delete e[o], t.delete(_n)), o;
      };

      return new l(function (e) {
        e.forEach(function (e) {
          0 < e.removedNodes.length && e.removedNodes.forEach(function (e) {
            e && n(e);
          });
        });
      }).observe(document, {
        childList: !0
      }), {
        getElementId: function getElementId(n) {
          var o = t.get(n);
          return o || (o = "".concat(i.default.webviewID, "_").concat(Math.random()).concat(Date.now()), e[o] = n, t.set(n, o)), o;
        },
        getDOM: function getDOM(t) {
          return e[t];
        }
      };
    }();

    var a,
        r = 0,
        d = 0;

    var m = function m(e, t) {
      var n = a = u.getDOM(e);
      if (!n) return {
        status: c,
        value: {
          message: "no such element"
        }
      };
      var o = n.getBoundingClientRect(),
          i = o.left + o.width / 2,
          l = o.top + o.height / 2,
          r = new Touch({
        identifier: 1,
        target: n,
        clientX: i,
        clientY: l,
        pageX: i,
        pageY: l
      }),
          d = new TouchEvent("touchstart", {
        bubbles: !0,
        touches: [r],
        targetTouches: [r],
        changedTouches: [r]
      }),
          m = new TouchEvent("touchend", {
        bubbles: !0,
        changedTouches: [r]
      });
      return n.dispatchEvent(d), t ? setTimeout(function () {
        return n.dispatchEvent(m);
      }, 500) : n.dispatchEvent(m), {
        status: s
      };
    };

    t.default = {
      init: function init() {
        o.default.registerCallback(function (e) {
          var t = e.command,
              n = e.data;
          var i;

          switch (t) {
            case "Driver.findElement":
              i = function (e, t) {
                if ("css selector" === e) {
                  var _e2 = document.querySelector(t);

                  if (_e2) return {
                    status: s,
                    value: {
                      WEBVIEW_ELEMENT: u.getElementId(_e2)
                    }
                  };
                }

                return {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
              }(n.using, n.value);

              break;

            case "Driver.findElements":
              i = function (e, t) {
                if ("css selector" === e) {
                  var _e3 = document.querySelectorAll(t),
                      _n2 = [];

                  return _e3.forEach(function (e) {
                    _n2.push(u.getElementId(e));
                  }), {
                    status: s,
                    value: _n2
                  };
                }

                return {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
              }(n.using, n.value);

              break;

            case "Driver.tapElement":
              i = m(n.ELEMENT);
              break;

            case "Driver.longtapElement":
              i = m(n.ELEMENT, !0);
              break;

            case "Driver.touchDown":
              i = function (e, t) {
                var n = a = document.elementFromPoint(e, t);
                r = e, d = t;
                var o = new Touch({
                  identifier: 1,
                  target: n,
                  clientX: e,
                  clientY: t,
                  pageX: e,
                  pageY: t
                }),
                    i = new TouchEvent("touchstart", {
                  bubbles: !0,
                  touches: [o],
                  targetTouches: [o],
                  changedTouches: [o]
                });
                return n.dispatchEvent(i), {
                  status: s
                };
              }(n.x, n.y);

              break;

            case "Driver.touchUp":
              i = function (e, t) {
                var n = a || document.elementFromPoint(e, t),
                    o = new Touch({
                  identifier: 1,
                  target: n,
                  clientX: e,
                  clientY: t,
                  pageX: e,
                  pageY: t
                });
                a = null, r = 0, d = 0;
                var i = new TouchEvent("touchend", {
                  bubbles: !0,
                  changedTouches: [o]
                });
                return n.dispatchEvent(i), {
                  status: s
                };
              }(n.x, n.y);

              break;

            case "Driver.touchMove":
              i = function (e, t) {
                var n = a || document.elementFromPoint(e, t),
                    o = new Touch({
                  identifier: 1,
                  target: n,
                  clientX: e,
                  clientY: t,
                  pageX: e,
                  pageY: t
                }),
                    i = new TouchEvent("touchmove", {
                  bubbles: !0,
                  touches: [o],
                  targetTouches: [o],
                  changedTouches: [o]
                });
                return !n.dispatchEvent(i) || (document.documentElement.scrollLeft += r - e, document.documentElement.scrollTop += d - t), r = e, d = t, {
                  status: s
                };
              }(n.x, n.y);

              break;

            case "Driver.scroll":
              i = function (e, t) {
                return document.documentElement && (document.documentElement.scrollLeft += e, document.documentElement.scrollTop += t), document.body.scrollLeft += e, document.body.scrollTop += t, {
                  status: s
                };
              }(n.xoffset, n.yoffset);

              break;

            case "Driver.sendKeys":
              i = function (e, t) {
                var n = u.getDOM(e);
                if (!n) return {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
                var o = n.querySelector("input");

                if (o) {
                  var _e4 = exparser.addListenerToElement(document, "setKeyboardValue", function (e) {
                    o.value = e.detail.value;
                  });

                  o.focus();

                  var _n3 = new KeyboardEvent("input");

                  for (var _e5 = 0, _i = t.length; _e5 < _i; _e5++) {
                    var _i2 = t[_e5];
                    o.value += _i2, o.dispatchEvent(_n3);
                  }

                  o.blur(), setTimeout(function () {
                    exparser.removeListenerFromElement(document, "setKeyboardValue", _e4);
                  }, 100);
                }

                return {
                  status: s
                };
              }(n.ELEMENT, n.value);

              break;

            case "Driver.getTagName":
              i = function (e) {
                var t = u.getDOM(e);
                return t ? {
                  status: s,
                  value: t.tagName.toLowerCase()
                } : {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
              }(n.ELEMENT);

              break;

            case "Driver.getAttribute":
              i = function (e, t) {
                var n = u.getDOM(e);
                return n ? {
                  status: s,
                  value: n.getAttribute(t)
                } : {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
              }(n.ELEMENT, n.name);

              break;

            case "Driver.getCssValue":
              i = function (e, t) {
                var n = u.getDOM(e);
                if (!n) return {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
                var o = window.getComputedStyle(n);
                return {
                  status: s,
                  value: o[t]
                };
              }(n.ELEMENT, n.propertyName);

              break;

            case "Driver.getSize":
              i = function (e) {
                var t = u.getDOM(e);
                if (!t) return {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
                var n = t.getBoundingClientRect();
                return {
                  status: s,
                  value: {
                    width: n.width,
                    height: n.height
                  }
                };
              }(n.ELEMENT);

              break;

            case "Driver.getRect":
              i = function (e) {
                var t = u.getDOM(e);
                if (!t) return {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
                var n = t.getBoundingClientRect();
                var o = t;
                return "wx-scroll-view" === t.localName && (o = t.querySelector("div div") || t), {
                  status: s,
                  value: {
                    x: n.left,
                    y: n.top,
                    width: n.width,
                    height: n.height,
                    scrollTop: o.scrollTop,
                    scrollLeft: o.scrollLeft,
                    scrollHeight: o.scrollHeight,
                    scrollWidth: o.scrollWidth
                  }
                };
              }(n.ELEMENT);

              break;

            case "Driver.getLocation":
              i = function (e) {
                var t = u.getDOM(e);
                if (!t) return {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
                var n = t.getBoundingClientRect();
                return {
                  status: s,
                  value: {
                    x: n.left,
                    y: n.top
                  }
                };
              }(n.ELEMENT);

              break;

            case "Driver.elementFromPoint":
              i = function (e, t) {
                var n = document.elementFromPoint(e, t);
                return n ? {
                  status: s,
                  value: {
                    WEBVIEW_ELEMENT: u.getElementId(n)
                  }
                } : {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
              }(n.x, n.y);

              break;

            case "Driver.getContentSize":
              i = function () {
                return {
                  status: s,
                  value: {
                    windowHeight: window.innerHeight,
                    windowWidth: window.innerWidth,
                    scrollTop: document.body.scrollTop || document.documentElement.scrollTop,
                    scrollLeft: document.body.scrollLeft || document.documentElement.scrollLeft,
                    scrollHeight: document.body.scrollHeight || document.documentElement.scrollHeight,
                    scrollWidth: document.body.scrollWidth || document.documentElement.scrollWidth
                  }
                };
              }();

              break;

            case "Driver.actionElementFromPoint":
              i = function (e, t) {
                var n = document.elementFromPoint(e, t);
                if (!n) return {
                  status: c,
                  value: {
                    message: "no such element"
                  }
                };
                var o = n;

                for (; !o.getAttribute("t_action");) {
                  if (!(o = o.parentElement) || o === document.body) {
                    o = n;
                    break;
                  }
                }

                return {
                  status: s,
                  value: {
                    WEBVIEW_ELEMENT: u.getElementId(o)
                  }
                };
              }(n.x, n.y);

              break;

            default:
              return;
          }

          o.default.send({
            command: "".concat(t, ".callback"),
            data: {
              callbackID: n.callbackID,
              res: i
            }
          });
        });
      }
    };
  },
  32: function _(e, t, n) {
    "use strict";

    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var o = n(21),
        i = n(45);
    var s;

    var c = function c() {
      if (s) return s;
      var e = "WEBVIEW_".concat(i.default.webviewID);
      return s = new o(e);
    };

    t.default = {
      send: function send(e) {
        e.fromWebviewID = i.default.webviewID, c().send(e);
      },
      registerCallback: function registerCallback(e) {
        c().registerCallback(e);
      }
    };
  },
  45: function _(e, t) {
    "use strict";

    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var n = navigator.userAgent,
        o = n.match(/webview\/(\d*)/),
        i = o ? parseInt(o[1], 10) : 0,
        s = -1 !== n.indexOf("Android"),
        c = -1 !== n.indexOf("iPhone"),
        l = -1 !== n.indexOf("weapp");
    t.default = {
      isAndroid: s,
      isiPhone: c,
      webviewID: i,
      isWeapp: l
    };
  },
  60: function _(e, t, n) {
    "use strict";

    function o() {
      g || (g = document.createElement("div"), (w = document.createElement("i")).style.backgroundImage = "light" === __wxConfig.window.backgroundTextStyle ? "url(".concat(l.default, ")") : "url(".concat(c.default, ")"), w.style.width = "32px", w.style.position = "absolute", w.style.height = "6px", w.style.left = "50%", w.style.bottom = "20px", w.style.backgroundRepeat = "no-repeat", w.style.marginLeft = "-16px", w.style.backgroundSize = "cover", g.appendChild(w), g.style.height = "0px", g.style.width = "100%", g.style.position = "fixed", g.style.top = "0px", g.style.backgroundColor = __wxConfig.window.backgroundColor, document.body.insertBefore(g, document.body.firstChild));
    }

    function i() {
      window.document.body.style.transition = "all linear 0.3s", window.document.body.style.marginTop = "0px", g && (g.style.transition = "all linear 0.3s", window.document.body.style.marginTop = "0px", g.style.height = "0px");
    }

    function s() {
      u.default.send({
        command: "PULLDOWN_REFRESH"
      });
    }

    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var c = n(224),
        l = n(225),
        u = n(32),
        a = 100,
        r = 50;
    var d = !1,
        m = 0,
        h = 0,
        g = null,
        w = null,
        A = !1,
        b = !1;
    window.enablePullDownRefresh = function () {
      b || (window.addEventListener("touchstart", function (e) {
        0 === window.scrollY && (o(), d = !0, m = e.touches[0].pageY, window.document.body.style.transition = "all linear 0", g.style.transition = "all linear 0");
      }, !0), window.addEventListener("touchmove", function (e) {
        d && __wxConfig.window.enablePullDownRefresh && !A && (h = e.touches[0].pageY - m, h = Math.max(0, h), h = Math.min(a, h), window.document.body.style.marginTop = "".concat(h, "px"), g.style.height = "".concat(h, "px"));
      }), window.addEventListener("touchend", function () {
        d = !1, h > r ? (s(), h = r, window.document.body.style.marginTop = "".concat(h, "px"), g.style.height = "".concat(h, "px"), setTimeout(i, 3e3)) : i();
      }), b = !0);
    }, t.default = {
      init: function init() {
        u.default.registerCallback(function (e) {
          var t = e.command,
              n = e.data;

          if ("STOP_PULLDOWN_REFRESH" === t && i(), "START_PULLDOWN_REFRESH" === t) {
            if (!__wxConfig.window.enablePullDownRefresh || A) return;
            o(), g.style.height = "".concat(r, "px"), window.document.body.style.transition = "all linear 0", window.document.body.style.marginTop = "".concat(r, "px"), s();
          }

          "SET_BACKGROUND_COLOR" === t && (o(), g.style.backgroundColor = n.backgroundColorTop || n.backgroundColor), "SET_BACKGROUND_TEXT_STYLE" === t && (o(), w.style.backgroundImage = "light" === n.textStyle ? "url(".concat(l.default, ")") : "url(".concat(c.default, ")"));
        });
      },
      reset: i,
      togglePullDownRefresh: function togglePullDownRefresh(e) {
        A = e;
      }
    };
  }
});

