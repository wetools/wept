define("app.js", function(require, module, exports, window, document, frames, self, location, navigator, localStorage, history, Caches, screen, alert, confirm, prompt, fetch, XMLHttpRequest, WebSocket, webkit, WeixinJSCore, Reporter, print, URL, DOMParser, upload, preview, build, showDecryptedInfo, syncMessage, checkProxy, showSystemInfo, openVendor, openToolsLog, showRequestInfo, help, showDebugInfoTable, closeDebug, showDebugInfo, __global, WeixinJSBridge) {
    'use strict';

    //app.js
    App({
        onLaunch: function onLaunch(options) {
            console.log('小程序初始化完成时触发，全局只触发一次。App onLaunch:' + JSON.stringify(options));
            // if (options.query.sID) {
            //   this.globalData.sID = options.query.sID
            //   console.log(this.globalData.sID)
            // }
            // wx.onPageNotFound((res) => {
            //   console.log('wx.onPageNotFound:' + JSON.stringify(res))
            // })
            // wx.onError(() => {
            //   console.log('wx.onError')
            // })
            // wx.onAudioInterruptionEnd(() => {
            //   console.log('wx.onAudioInterruptionEnd')
            // })
            // wx.onAudioInterruptionBegin(() => {
            //   console.log('wx.onAudioInterruptionBegin')
            // })
            // wx.onAppShow((res) => {
            //   console.log('wx.onAppShow' + JSON.stringify(res))
            // })
            // wx.onAppHide(() => {
            //   console.log('wx.onAppHide')
            // })
        },
        onShow: function onShow(options) {
            console.log('小程序启动，或从后台进入前台显示时触发。App onShow: ' + JSON.stringify(options));
            if (options && options.shareTicket) {
                this.globalData.shareTicket = options.shareTicket;
            }
        },
        onPageNotFound: function onPageNotFound(res) {
            console.log('onPageNotFound:' + JSON.stringify(res));
        },

        globalData: {
            userInfo: null,
            shareTicket: '',
            sID: ''
        }
    });
});